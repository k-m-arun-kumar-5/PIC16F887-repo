/**************************************************************************
   FILE          :    uart.h
 
   PURPOSE       :    UART Header
 
   AUTHOR        :     K.M.Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _UART_H
 #define _UART_H

 /* -------------------- public prototype declaration --------------------------------------- */
void Init_UART();
void Transmit_UART(const char transmit_char);
char Receive_UART();

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
