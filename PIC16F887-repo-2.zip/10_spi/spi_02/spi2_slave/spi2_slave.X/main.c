/* ********************************************************************
   FILE                   : main.c

   PROGRAM DESCRIPTION    :  by using SPI, first receive a data string 1 terminated by '\r' in SPI_SLAVE and data string 1 was transmitted by SPI_MASTER and receive it by SPI in SPI_SLAVE and display it in LCD_SLAVE connected to SPI_SLAVE.
                      									 
	 
   AUTHOR                :  K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
   KNOWN BUGS            : 

   NOTE                  :  this is a SPI_SLAVE code and software flow control and error checking are not implemented									
                                    
   CHANGE LOGS           : 

*****************************************************************************/
// 'C' source line config statements

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.


#include "main.h"
#include "port.h"
#include "lcd.h"
#include "spi.h"

void main()
{
   char spi_rcvd_data_str[30];
   unsigned int spi_num_chars_received = 0, spi_num_chars_transmitted = 0;
   const char lcd_data_to_master_str[] = "RCVD FROM SLAVE \r";
   char lcd_disp_enable_flag = STATE_YES, spi_rcv_enable_flag = STATE_YES, spi_tx_enable_flag = STATE_YES;
   
   TRISE = 0x00;
   PORTE = 0x00;
   LCD_PORT_GPIO = 0x00;        
   LCD_PORT = 0x00;   
   ANSEL = 0x00;
   ANSELH = 0x00;  
   LCD_Init();
   SPI_Init(SPI_SLAVE_SS_EN, SPI_DATA_SAMPLE_MIDDLE, SPI_CLOCK_IDLE_LOW, SPI_IDLE_2_ACTIVE);
   Goto_XY_LCD_Disp(1,1);
   while(1)	   
   {
	   //SLAVE has been selected
	   while(MSSP_SLAVE_SELECT_PIN == 0) 
	   {
		   while(spi_rcv_enable_flag == STATE_YES)
		   {
               spi_rcvd_data_str[spi_num_chars_received] = SPI_Data_Read_Char();
			   if( spi_rcvd_data_str[spi_num_chars_received] != '\r' )
	           {
	               ++spi_num_chars_received;
	           }
	           else 
	           {
			       spi_rcvd_data_str[spi_num_chars_received] = '\0';
                   spi_num_chars_received = 0 ; 
                   spi_rcv_enable_flag = STATE_NO;	
				   Data_Str_Disp_LCD(spi_rcvd_data_str);
	           }
		   }	
            while(spi_tx_enable_flag == STATE_YES)
	       {
	           SPI_Data_Write_Char(lcd_data_to_master_str[spi_num_chars_transmitted]);
		       if( lcd_data_to_master_str[spi_num_chars_transmitted] != '\r')
               {				
		          ++spi_num_chars_transmitted;
		       }
               else
		       {
		         spi_num_chars_transmitted = 0;
                 spi_tx_enable_flag = STATE_NO;		
				
		       }
	       } 	             
		    // __delay_ms(100);
        }
    }
}   
