/**************************************************************************
   FILE          :    spi.h
 
   PURPOSE       :    SPI library Header
 
   AUTHOR        :   K.M.Arun Kumar alias Arunkumar Murugeswaran
 
   
  KNOWN BUGS     :
	
  NOTE           :    
	
  CHANGE LOGS     :  
	   
 **************************************************************************/
 
 
#ifndef SPI_H
#define	SPI_H

#include <xc.h> 

typedef enum 
{
    SPI_MASTER_OSC_DIV4  = 0b00100000, //In SSPCON, SSPM<3:0> - MSSP enabled and SPI Master mode, clock = FOSC/4
    SPI_MASTER_OSC_DIV16 = 0b00100001, //In SSPCON, SSPM<3:0> - MSSP enabled and SPI Master mode, clock = FOSC/16
    SPI_MASTER_OSC_DIV64 = 0b00100010, //In SSPCON, SSPM<3:0> - MSSP enabled and SPI Master mode, clock = FOSC/64 
    SPI_MASTER_TMR2      = 0b00100011, //In SSPCON, SSPM<3:0> - MSSP enabled and SPI Master mode, clock = TMR2 output/2
    SPI_SLAVE_SS_EN      = 0b00100100, //In SSPCON, SSPM<3:0> - MSSP enabled and SPI Slave mode, clock = SCK pin, SS pin control enabled
    SPI_SLAVE_SS_DIS     = 0b00100101  //In SSPCON, SSPM<3:0> - MSSP enabled and SPI Slave mode, clock = SCK pin, SS pin control disabled
} Spi_Type;

typedef enum
{
    SPI_DATA_SAMPLE_MIDDLE   = 0b00000000, // In SSPSTAT, SMP: Sample bit- Input data sampled at middle of data output time
    SPI_DATA_SAMPLE_END      = 0b10000000  // In SSPSTAT, SMP: Sample bit- Input data sampled at end of data output time
} Spi_Data_Sample;

typedef enum
{
    SPI_CLOCK_IDLE_HIGH  = 0b00010000,  // In SSPCON, CKP: Clock Polarity Select bit - Idle state for clock is a high level
    SPI_CLOCK_IDLE_LOW   = 0b00000000   // In SSPCON, CKP: Clock Polarity Select bit - Idle state for clock is a low  level     
} Spi_Clock_Idle;

typedef enum
{
    SPI_IDLE_2_ACTIVE    = 0b00000000, // In SSPSTAT, CKE: SPI Clock Edge Select bit - if CKP = 0: Data transmitted on falling edge of SCK, else, if CKP = 1: Data transmitted on rising edge of SCK 
    SPI_ACTIVE_2_IDLE    = 0b01000000  // In SSPSTAT, CKE: SPI Clock Edge Select bit - if CKP = 0: Data transmitted on rising edge of SCK, else, if CKP = 1: Data transmitted on falling edge of SCK 
} Spi_Transmit_Edge;


void SPI_Init(Spi_Type, Spi_Data_Sample, Spi_Clock_Idle, Spi_Transmit_Edge);
void SPI_Data_Write_Char(const char);
void SPI_Data_Write_Str(const char *lcd_data_from_master_str);
unsigned int SPI_Data_Ready();
char SPI_Data_Read_Char();
unsigned int SPI_Ready_Tx_Data();
char SPI_Exchange_Char(const char spi_transmit_char);

#endif	/* SPI_H */

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
