/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : use external interrupt, use 2 LEDs, NORMAL_LED and EXTR_INTP_LED. When no external interrupt ie EXTR_INTP_SW is not pressed ,
  NORMAL_LED blinks and when EXTR_INTP_SW is pressed on, NORMAL_LED should hold in the state, just when  EXTR_INTP_SW is pressed on.
  and EXTR_INTP_LED should ON for specific time duration and then NORMAL_LED should resume blinking
                      									 
	 
AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran  
	 
KNOWN BUGS            : 

NOTE                  : tested on HW												
                       
                       
CHANGE LOGS           : 

*****************************************************************************/
  
// PIC16F887 Configuration Bit Settings
// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.
// 'C' source line config statements

// CONFIG1
//#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config FOSC = HS        // Oscillator Selection bits (HS oscillator: High-speed crystal/resonator on RA6/OSC2/CLKOUT and RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = ON       // Power-up Timer Enable bit (PWRT enabled)
#pragma config MCLRE = ON       // RE3/MCLR pin function select bit (RE3/MCLR pin function is MCLR)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = ON        // Internal External Switchover bit (Internal/External Switchover mode is enabled)
#pragma config FCMEN = ON       // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is enabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

#include "main.h"
#include "port.h"
#include "uart.h"
#include "lcd.h"



#define REQ_TIME_LED_CHANGE_STATE   (5000UL)

void Normal_Led_Proc();
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void main()
{
		
   TRISA = 0x00;
   PORTA = 0x00;
   
   LCD_PORT_GPIO = 0x00;
   LCD_PORT = 0x00;
   TRISE = 0x00;
   PORTE = 0x00;
   
   ANSEL = 0x00;
   ANSELH = 0x00; 
   
   UART_Init();
   LCD_Init();    
   INTF = 0;
   OPTION_REGbits.INTEDG = 1; // external Interrupt on rising edge of INT pin
   INTCONbits.INTE = 1; //Enables the INT pin external interrupt
   INTCONbits.GIE = 1;  //Enables all unmasked interrupts  
   
   while(1)
   {
       Normal_Led_Proc();	   
   }   
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void Normal_Led_Proc()
{
	#ifdef TRACE
	   UART_Transmit_Str("NORMAL LED ON \r");
	#endif
	NORMAL_LED = LED_ON;
	__delay_ms(REQ_TIME_LED_CHANGE_STATE);
	#ifdef TRACE
	   UART_Transmit_Str("NORMAL LED OFF \r");
	#endif
	NORMAL_LED = LED_OFF;
	__delay_ms(REQ_TIME_LED_CHANGE_STATE);
	
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void interrupt External_Interrupt_ISR() 
{
	EXTR_ISR_LED  = LED_ON;
	if(INTCONbits.INTE == 1 && INTF == 1)  
	{
		INTCONbits.INTE = 0; //disable the INT pin external interrupt
		/*if INTF is not cleared in software, and when EXTR_INTP_SW is pressed on and after execution of External Interrupt ISR,   
		 and even when EXTR_INTP_SW is released, External Interrupt ISR keeps on been executed, until INTF, which was set, 
		 when EXTR_INTP_SW was pressed on, is cleared in software */
		 #ifdef TRACE
		   UART_Transmit_Str("External interrupt occured \r");
		   UART_Transmit_Str("INTE is disabled \r");
		 #endif
		
		EXTR_INTP_LED = LED_ON;
		/*__delay_ms() consumes instruction cycles, which means during time in specific delay(REQ_TIME_LED_CHANGE_STATE), 
		 uC will not execute any other instruction(other than __delay_ms()) */ 
		__delay_ms(REQ_TIME_LED_CHANGE_STATE );	
        EXTR_INTP_LED = LED_OFF;
        /* user should clear interrupt flag in software before enabling corresponding interrupt.
           In this case, INTF(External interrupt flag) INTF = 0  in software, before enabling (INTE) external interrupt */		
		INTF = 0;
		#ifdef TRACE
		  UART_Transmit_Str("INTE is enabled \r");
		  UART_Transmit_Str("External interrupt is exited \r");
		#endif
		OPTION_REGbits.INTEDG = 1; // external Interrupt on rising edge of INT pin
		INTCONbits.INTE = 1; //enable the INT pin external interrupt
		INTF = 0;
	}
	
	EXTR_ISR_LED  = LED_OFF;
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
