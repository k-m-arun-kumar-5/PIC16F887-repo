

int i;
void UART_init()
{
	SCON=0X50;
	TMOD=0X20;
	TH1=0XFD;
	TR1=1;
}
void gsm_tx(const char *g)
{
	while(*g)
	{
		SBUF=*g;
		while(TI==0);
		g++;
		TI=0;
	}
}
void tx(unsigned int a)
{
	SBUF=a;
	while(TI==0);
	TI=0;
}
void rx(int l)
{
	char b;
	for(i=0;i<=l;i++)
	{
	while(RI==0);
  b=SBUF;
	c[i]=b;
	tx(c[i]);
	RI=0;
	}
}
void gsm_on()
{
	gsm_tx("AT");
	tx(0X0d);
	tx(0X0a);
	gsm_tx("AT+CMGF=1");
	tx(0X0d);
	tx(0X0a);
	gsm_tx("AT+CMGS=");
	tx('"');
	gsm_tx("+919788094958");
	tx('"');
	tx(0X0d);
	tx(0X0a);
	gsm_tx(">LED ON");
	tx(0X0d);
	tx(0X1a);
}
void gsm_off()
{
	gsm_tx("AT");
	tx(0X0d);
	tx(0X0a);
	gsm_tx("AT+CMGF=1");
	tx(0X0d);
	tx(0X0a);
	gsm_tx("AT+CMGS=");
	tx('"');
	gsm_tx("+919788094958");
	tx('"');
	tx(0X0d);
	tx(0X0a);
	gsm_tx(">LED OFF");
	tx(0X0d);
	tx(0X1a);
}