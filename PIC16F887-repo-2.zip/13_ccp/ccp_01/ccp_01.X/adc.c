/**************************************************************************
   FILE          :    adc.c
 
   PURPOSE       :   Analog to Digital Library
 
   AUTHOR        :     K.M. Arun Kumar alias Arunkumar Murugeswaran  
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #include "main.h"
 #include "adc.h"
 #include "uart.h"
 #include "io_conf.h"
 #include "appl_conf.h"
 
adc_channels adc_cur_channel;
unsigned long analog_val_in_digital_ch[2]; 
adc_service_types adc_cur_service_type;

 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
 void ADC_Start_Conv(const adc_service_types set_adc_service_type, const adc_clk_src_types  set_adc_clk_src_type, const adc_channel_types set_adc_channel_type, const adc_channels set_adc_channel,\
  const adc_result_format_justfied_types set_adc_result_format_justfied_type, const adc_vref_neg_src_types set_adc_vref_neg_src_type, const adc_vref_plus_src_types set_adc_vref_plus_src_type)
{
	unsigned int adc_channel_reg;
	char rcvd_status;
	value_types to_disp;
	
	rcvd_status = Is_ADC_Converting();	
	switch(rcvd_status)
	{
		//A/D conversion completed/not in progress
        case STATE_NO:
		   if(set_adc_channel_type == ADC_CHANNEL_SEL)
	       {
              if(set_adc_channel < 14) //max of 14 ADC channels in pic16f887
	          {
	              adc_channel_reg = (set_adc_channel << 2) ;
		  		         
                  ADCON0 = set_adc_clk_src_type| adc_channel_reg ;
	              ADCON1 = set_adc_result_format_justfied_type | set_adc_vref_neg_src_type | set_adc_vref_plus_src_type;	
				   /*  ADC is Enabled and not yet start ADC conversion */	
                  ADCON0bits.ADON = 1; 
				  ADIF = 0;
				  adc_cur_service_type = set_adc_service_type;
				  adc_cur_channel = set_adc_channel; 
				  switch(adc_cur_service_type)
				  {
					  case ADC_INTP_SERVICE:
					     PIE1bits.ADIE = 1;   // Enables A/D Converter (ADC) Interrupt 
				         INTCONbits.PEIE = 1;  //Enables all unmasked peripherals interrupts   
                         INTCONbits.GIE = 1;  //Enables all unmasked interrupts 
				  
				         #ifdef TRACE
                            UART_Transmit_Str("ADIE, PEIE & GIE are enabled, interrupt service \r");
					     #endif
						 
					  break;
                      case ADC_POLLING_SERVICE:
                          PIE1bits.ADIE = 0;   // disable A/D Converter (ADC) Interrupt 
						  
      					  #ifdef TRACE
                            UART_Transmit_Str("ADIE, is disabled, polling service \r");
					      #endif 
                       break;
				  }
				  
                  #ifdef TRACE		
				     to_disp.unsigned_val.value_long = ADCON0;
                     UART_Transmit_Str("ADCON0 config : 0x");	
					 UART_Transmit_Num(DISP_HEX_DIGIT2, to_disp);
					 UART_Transmit_Char('\r');
					 to_disp.unsigned_val.value_long = ADCON1;
					 UART_Transmit_Str("ADCON1 config : 0x");	
					 UART_Transmit_Num(DISP_HEX_DIGIT2, to_disp );
					 UART_Transmit_Char('\r');
					 to_disp.unsigned_val.value_long = adc_cur_channel;
                     UART_Transmit_Str("Start ADC conv for channel : ");
	                 UART_Transmit_Num(DISP_UNSIGN_NUM_DIGIT2, to_disp);
	                 UART_Transmit_Char('\r');
                   #endif 
				   
                  /* After the analog input channel is selected (or changed), an A/D acquisition must be done before the conversion
		             can be started, minimum A/D acquisition time = 5us. For safe reason,  A/D acquisition time = 500 milli sec is used */
					 
			      __delay_ms(500);
		          /* Start ADC conversion cycle for set_adc_channel.  
		            GO bit will automatically cleared by hardware when the A/D conversion has completed */
		            ADCON0bits.GO = 1; 				  
	          }
	          else
	          {
		          #ifdef TRACE_ERROR
				    to_disp.unsigned_val.value_long = set_adc_channel;
		            UART_Transmit_Str("ERR: invalid ADC channel select : ");
		            UART_Transmit_Num(DISP_UNSIGN_NUM_DIGIT2, to_disp );
		            UART_Transmit_Char('\r');
		          #endif	 
	          }
	       }
           else
	       {
		       adc_channel_reg = set_adc_channel_type;
			   ADCON0 = set_adc_clk_src_type| adc_channel_reg;
	       }         
		  
		break;
        default: 
           //error: ADC conversion in progress
	    	#ifdef TRACE_ERROR
		       UART_Transmit_Str("ERR: try to start ADC while ADC Converting \r");
		    #endif  		
	}
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
 void ADC_Disable()
{
	char rcvd_status;
	
	rcvd_status = Is_ADC_Converting();	
	switch(rcvd_status)
	{
		//A/D conversion completed/not in progress
        case STATE_NO:
		   //ADC is disabled and consumes no operating current
           ADCON0bits.ADON = 0; 
		   PIE1bits.ADIE = 0;   // disable A/D Converter (ADC) Interrupt 
		   adc_cur_service_type = ADC_INVALID_SERVICE;
		   
		   #ifdef TRACE
             UART_Transmit_Str("ADC is disabled \r");
             UART_Transmit_Str("ADIE is disabled \r");
           #endif  
		   
		break;
        default: 
           //error: ADC conversion in progress
	    	#ifdef TRACE_ERROR
		       UART_Transmit_Str("ERR: try to disable ADC while ADC Converting \r");
		    #endif  		
	}		
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
 char Is_ADC_Converting()
{
	//A/D conversion completed/not in progress
	if(ADCON0bits.GO == 0)
	   return STATE_NO;
    //A/D conversion cycle is in progress.
	return STATE_YES;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Encoded_To_Actual_Analog_Val_Calc(const unsigned long adc_value, unsigned long int full_scale_analog_val, \
   unsigned long int min_analog_val, unsigned long *const analog_val_in_digital_int, unsigned long *const analog_val_in_digital_frac )
{
	unsigned long remainder_val;	
	*analog_val_in_digital_int = ((full_scale_analog_val * adc_value) / (1024ul -1))  + min_analog_val;
	remainder_val = (full_scale_analog_val * adc_value) %(1024ul - 1);
	*analog_val_in_digital_frac = ((remainder_val * 10) /(1024ul - 1));
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Encoded_To_Percent_Calc(const unsigned long adc_value, unsigned int *const percent_int, unsigned int *const percent_frac )
{
	unsigned int remainder_val;
	unsigned long temp_percent_int;
	temp_percent_int =  (100 * adc_value); 
	*percent_int = (100 * adc_value) / (1024ul - 1);
	remainder_val = temp_percent_int % (1024ul - 1 );
	*percent_frac = (remainder_val * 10) /(1024ul - 1);
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
