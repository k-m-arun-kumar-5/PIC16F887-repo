/**************************************************************************
   FILE          :    isr.c
 
   PURPOSE       :   Interrupt Service Routine Library
 
   AUTHOR        :     K.M. Arun Kumar alias Arunkumar Murugeswaran  
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #include "main.h"
 #include "port.h"
 #include "io_conf.h"
 #include "timer.h"
 #include "uart.h"
 #include "intp_event_handle.h"  
 
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void interrupt Interrupt_ISR() 
{
	value_types to_disp;
	
	if( INTCONbits.INTE == 1 && INTF == 1)           // external interrupt ISR - higher priority
	{	
	     INTCONbits.INTE = 0; //disable the INT pin external interrupt
		/*if INTF is not cleared in software, and when EXTR_INTP_SW is pressed on and after execution of External Interrupt ISR,   
		 and even when EXTR_INTP_SW is released, External Interrupt ISR keeps on been executed, until INTF, which was set, 
		 when EXTR_INTP_SW was pressed on, is cleared in software */			
        			
	    #ifdef TRACE
	       UART_Transmit_Str("External Interrupt is occurred \r");
		   UART_Transmit_Str("INTE is disabled \r"); 
	    #endif 	
		
		External_Interrupt_Occured_Appl_Proc();	
		INTF = 0;
	}
	#ifdef TIMER1_MOD_ENABLE
	if(TMR1IF == 1)     // timer1 overflow interrupt ISR - lower prority
	{
		 if(timer1_cur_service_type & 0x02)
	     {
			 //timer1 is in timer mode
		 	  TMR1H = timer1_init_val / 256UL;
              TMR1L = timer1_init_val % 256UL; 
		      //timer1 overflow for every TIMER1_TICK_IN_MILLI_SEC ie timer1_elapsed_num_overflow_1_update var is incremented for every TIMER1_TICK_IN_MILLI_SEC elapsed
              if(++timer1_elapsed_num_overflow_1_update >= timer1_1_update) 
              {
			    if(++timer1_elapsed_num_update >= timer1_req_time_max_update)
			    {
				    Timer1_Stop();
				    #ifdef TRACE
	                   UART_Transmit_Str("Timer1 is expired \r");			 
                     #endif 				  
				     timer1_elapsed_num_update = 0;
                     timer1_elapsed_num_overflow_1_update = 0; 				  
                     Timer1_Req_Time_Expiry_Appl_Proc();  
			    }
                timer1_elapsed_num_overflow_1_update = 0;  			  
             }
		 }
		 else
		 {
			 //timer1 is in counter mode
			 ++tmr1_measure_pulse_upper_count;
			 
            /*  #ifdef TRACE
			        to_disp.unsigned_val.value_long = measure_pulse_upper_count;
	                UART_Transmit_Str("Timer1 overflow : 0x");
					
					UART_Transmit_Num(DISP_HEX_DIGIT4, to_disp);
					to_disp.unsigned_val.value_long = TMR1;
                    UART_Transmit_Num(DISP_HEX_DIGIT4, to_disp);
                    UART_Transmit_Char('\r');
              #endif */			 
		 }
		 TMR1IF = 0;
	}
	#endif
	#ifdef TIMER2_MOD_ENABLE
    if(TMR2IF == 1)
	{
		/* #ifdef TRACE 
		    UART_Transmit_Str("TMR2IF overflow \r");
		#endif */
	    TMR2IF = 0;	
	}
	#endif
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
