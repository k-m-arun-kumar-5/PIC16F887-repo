/**************************************************************************
   FILE          :    timer.h
 
   PURPOSE       :    timer library Header
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran  
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _TIMER_H
 #define _TIMER_H
 
/* ---------------------- macro defination ------------------------------------------------ */ 

#define TMR0_STOP_STATE                    (0xFF)

#define TMR0_INVALID_SERVICE         (4)
#define TMR0_TIMER_INTP_SERVICE      (3)
#define TMR0_TIMER_POLLING_SERVICE   (2)
#define TMR0_COUNTER_INTP_SERVICE    (1)
#define TMR0_COUNTER_POLLING_SERVICE (0)
 
#define TMR0_CLK_SRC_INTR_OSC        (0)
#define TMR0_CLOCK_SOURCE_EXTR_FALLING_EDGE      (3)
#define TMR0_CLOCK_SOURCE_EXTR_RISING_EDGE       (2)

#define TIMER0_PRESET_TIME_DELAY_IN_MULTIPLE                    (1U)
#define TIMER0_POSTSET_TIME_DELAY_IN_MULTIPLE                   (2U) 
 
#define TMR1_STOP_STATE                    (0xFF)

#define TMR1_INVALID_SERVICE         (4)
#define TMR1_TIMER_INTP_SERVICE      (3)
#define TMR1_TIMER_POLLING_SERVICE   (2)
#define TMR1_COUNTER_INTP_SERVICE    (1)
#define TMR1_COUNTER_POLLING_SERVICE (0)
 
#define	 TMR1_GATE_CTRL_DISABLE       (0)     //Timer1 Gate control disable
#define  TMR1_GATE_CTRL_ACTIVE_HIGH   (3)     // Timer1 Gate control enabled, as Timer1 counting is controlled by the Timer1 Gate function and Timer1 gate is active-high (Timer1 counts when gate is high and timer 1 pauses when gate is low)
#define  TMR1_GATE_CTRL_ACTIVE_LOW    (1)     //Timer1 Gate control enabled, and Timer1 gate is active-high (Timer1 counts when gate is high and timer 1 pauses when gate is low)

#define  TMR1_CLK_SRC_INTR_OSC          (0)     // Timer1 Clock Source as Internal clock (FOSC/4)
#define  TMR1_CLK_SRC_EXTR_CLK_NO_SYNC  (3)     // Timer1 Clock Source as External clock from T1CKI pin (on the rising edge) and dont Synchronize external clock input     
#define  TMR1_CLK_SRC_EXTR_CLK_SYNC     (1)     // Timer1 Clock Source as External clock from T1CKI pin (on the rising edge) and Synchronize external clock input 
   

#define  TMR1_LP_OSC_ENABLE   (1)     // LP(low power) oscillator is enabled for Timer1 clock
#define  TMR1_LP_OSC_DISABLE   (0)    // LP(low power) oscillator is off for Timer1 clock
 
#define TIMER1_PRESET_TIME_DELAY_IN_MULTIPLE                    (1U)
#define TIMER1_POSTSET_TIME_DELAY_IN_MULTIPLE                   (2U) 

#define TMR2_STOP_STATE                    (0xFF)

#define	TMR2_INVALID_SERVICE         (4) 
#define TMR2_PWM_INTP_SERVICE        (3)
#define TMR2_PWM_POLLING_SERVICE     (2)

#define TMR2_PRESCALE_16               (2) //Timer2 Input Clock 1:16 Prescale Value from Timer1 internal Clock  
#define TMR2_PRESCALE_4                (1) //Timer2 Input Clock 1:4 Prescale Value from Timer1 internal Clock 
#define TMR2_PRESCALE_1                (0) //Timer2 Input Clock 1:1 Prescale Value from Timer1 internal Clock 

#define TIMER2_PRESET_TIME_DELAY_IN_MULTIPLE                    (1U)
#define TIMER2_POSTSET_TIME_DELAY_IN_MULTIPLE                   (2U) 

/* ---------------------- data type defination --------------------------------------------- */
typedef struct {
	unsigned int wdt_prescaler: 3;    	
} watchdog_timer_data_types;

typedef struct {
	unsigned long int timer0_req_time_delay_in_milli_sec;
    unsigned int timer0_service_type: 3;
	unsigned int timer0_input_clk_type: 2;
	unsigned int timer0_input_clk_prescaler: 3;    	
} tmr0_data_types;

typedef struct {
	unsigned long int timer1_req_time_delay_in_milli_sec;
    unsigned int timer1_service_type: 3;
	unsigned int timer1_gate_ctrl_type: 2;
	unsigned int timer1_input_clk_type: 2;
	unsigned int timer1_lp_osc_enable_ctrl: 1;
	unsigned int timer1_input_clk_prescaler: 2;    	
} tmr1_data_types;


typedef struct {
	unsigned long int timer2_req_time_delay_in_milli_sec;
	unsigned int timer2_service_type: 2;
	unsigned int timer2_clk_prescale: 2;
	unsigned int timer2_output_postscale: 4; 
} tmr2_data_types;

 /* -------------------- public variable declaration --------------------------------------- */

extern unsigned int timer0_prescale_shift, timer0_elapsed_num_update,  timer0_init_val;
extern unsigned long int timer0_prescale,timer0_elapsed_num_overflow_1_update, timer0_1_update, timer0_max_num_overflow, timer0_req_time_max_update;
extern unsigned int  timer0_cur_run_state, timer0_last_run_state_before_stop, timer0_cur_service_type;
extern tmr0_data_types  tmr0_datas[];
extern char timer0_timeout_occured_flag;
extern volatile unsigned int tmr0_measure_pulse_lower_count, tmr0_measure_pulse_upper_count;


extern unsigned int timer1_prescale, timer1_prescale_shift, timer1_elapsed_num_update;
extern unsigned long int  timer1_init_val, timer1_elapsed_num_overflow_1_update, timer1_1_update, timer1_max_num_overflow, timer1_req_time_max_update;
extern unsigned int  timer1_cur_run_state, timer1_last_run_state_before_stop;
extern unsigned int timer1_cur_service_type;
extern volatile unsigned long tmr1_measure_pulse_lower_count, tmr1_measure_pulse_upper_count;
extern char timer1_timeout_occured_flag;
extern tmr1_data_types  tmr1_datas[];


extern unsigned int timer2_prescale, timer2_prescale_shift, timer2_elapsed_num_update, timer2_postscale;
extern unsigned long int  timer2_init_val, timer2_elapsed_num_overflow_1_update, timer2_1_update, timer2_max_num_overflow, timer2_req_time_max_update;
extern unsigned int timer2_cur_run_state, timer2_last_run_state_before_stop;
extern unsigned int timer2_cur_service_type;
extern tmr2_data_types  tmr2_datas[];


 /* -------------------- public prototype declaration --------------------------------------- */
 
void Timer0_Run(const unsigned int set_timer0_run_state, const unsigned long int set_timer0_req_time_delay_in_milli_sec );
void Timer0_Conf_Parameters(unsigned int set_timer0_run_state );
void Timer0_Prescale();
void Timer0_Load_Init_Val_Calc(const unsigned long int set_timer0_req_time_delay_in_milli_sec);

void Timer1_Run(const unsigned int set_timer1_run_state, const unsigned long int set_timer1_req_time_delay_in_milli_sec );
void Timer1_Conf_Parameters(unsigned int set_timer1_run_state );
void Timer1_Stop();
void Timer1_Prescale();
void Timer1_Load_Init_Val_Calc(const unsigned long int set_timer1_req_time_delay_in_milli_sec);

void Timer2_Run(const unsigned int set_timer2_run_mode, const unsigned long int set_timer2_req_time_delay_in_milli_sec );
void Timer2_Conf_Parameters(unsigned int set_timer2_run_state );
void Timer2_Stop();
void Timer2_Prescale();
void Timer2_Postscale();
void Timer2_Load_Init_Val_Calc(const unsigned long int set_timer2_req_time_delay_in_milli_sec);

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
