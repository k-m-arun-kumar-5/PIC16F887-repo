/**************************************************************************
   FILE          :    rcvd_data_proc.h
 
   PURPOSE       :   rcvd datas Procedure Header
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran  
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/ 
#ifndef _RCVD_DATA_PROC_H
#define	_RCVD_DATA_PROC_H


extern unsigned int slave_rcv_str_index;

#endif	

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
