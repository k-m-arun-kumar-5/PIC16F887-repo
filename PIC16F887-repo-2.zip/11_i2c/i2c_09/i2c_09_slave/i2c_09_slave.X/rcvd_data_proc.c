/**************************************************************************
   FILE          :    rcvd_data_proc.c
 
   PURPOSE       :   rcvd data Procedure 
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran  
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
#include "main.h" 
#include "port.h"
#include "appl_conf.h"
#include "i2c.h"
#include "lcd.h"
#include "uart.h"
#include "rcvd_data_proc.h"
#include "i2c_fsm.h"

 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
int Slave_I2C_Rcvd_Data_Proc(unsigned char *slave_rcvd_valid_data_str, unsigned int slave_i2c_rcvd_valid_data_str_len)
{
    switch(slave_rcv_data_str_index)
	{
		case 0:
		       Write_LCD_Command(0x01);			 
	           Goto_XY_LCD_Disp(SLAVE_LCD_RCVD_DATA_MSG_LINE_NUM, NUM_COL1);
		       Data_Str_Disp_LCD("Rcvd Data by I2C");		
		       Goto_XY_LCD_Disp(SLAVE_LCD_RCVD_DATA1_LINE_NUM, NUM_COL1);
		
		       //SHOULD_REMOVE
			   #ifdef TRACE
		          Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, slave_i2c_rcvd_valid_data_str_len);
		          Data_Str_Disp_LCD(" : ");		
			   #endif
	           Data_Str_Disp_LCD(slave_rcvd_valid_data_str);
	   	      				
		       //SHOULD_REMOVE
			   #ifdef TRACE
		          UART_Transmit_Str("Rcvd Slave's valid Data's len: ");
		          UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, slave_i2c_rcvd_valid_data_str_len);
		          UART_Transmit_Char('\r');
		          UART_Transmit_Str("Rcvd Slave's valid Data: ");
		          UART_Transmit_Str(slave_rcvd_valid_data_str);
		          UART_Transmit_Char('\r');
			   #endif
		              
	    break;	
	    case 1:
	          Goto_XY_LCD_Disp(SLAVE_LCD_RCVD_DATA2_LINE_NUM, NUM_COL1);
		
		      //SHOULD_REMOVE
			  #ifdef TRACE
		        Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, slave_i2c_rcvd_valid_data_str_len);
		        Data_Str_Disp_LCD(" : ");
		      #endif
	          Data_Str_Disp_LCD(slave_rcvd_valid_data_str);
	          lcd_const_disp_flag[SLAVE_LCD_RCVD_DATA2_LINE_NUM] = STATE_YES_IN_CHAR;
					
		      //SHOULD_REMOVE
			  #ifdef TRACE
		         UART_Transmit_Str("Rcvd Slave's valid Data's len: ");
		         UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, slave_i2c_rcvd_valid_data_str_len);
		         UART_Transmit_Char('\r');
		         UART_Transmit_Str("Rcvd Slave's valid Data: ");
		         UART_Transmit_Str(slave_rcvd_valid_data_str);
		         UART_Transmit_Char('\r');
			  #endif	 
		     
	    break; 
	}
	
	 ++slave_rcv_data_str_index;
	return SUCCESS; 	
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
