/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    :  There are 2 data str to be send by I2C_MASTER. By using I2C polling, after valid I2C slave address for I2C_SLAVE and then valid command(MW char) are send by I2C_MASTER, 
then after receive I2C ACK bit in I2C_MASTER,  then, start to send a data str from I2C_MASTER to I2C_SLAVE, and when DATA_TERMINATOR_CHAR is send by I2C_MASTER, 
then by send I2C stop bit, to end data transfer for a data str and then display rcvd data str in LCD_SLAVE connected to I2C_SLAVE. Repeat process for another data str sent by I2C_MASTER.  

  Transmission control(TC) and other communications related characters 
 =====================================================================
   '\\'          - in our case as user predefined valid data terminator. 
   '\0'  (NULL)  - NUL char in ascii, defined as a filler character. It can be used as media-fill or time-fill. In our case, data are NULL terminated after DATA_TERMINATOR_CHAR 
                as well as media-fill for unoccupied data and is used as user predefined fill char.
   '\x05' (ENQ) - enquiry in ascii or (TC5). is used by a master station to ask a slave station to send its next message.In our case, when slave has rcvd ENQ from master 
                 and if slave wants to transmits more message, then slave transmits I2C ACK bit. When ENQ is rcvd in slave and when slave has no transmit data to master, then slave transmits I2C NAK bit to master.                   
   '\x80' (PAD) - Padding Character in ascii used in our case as padded char. 
   '\x95' (MW) - Message Waiting in ascii, is used to Sets a message waiting indicator in the receiving device. 
                In our case, if master has some valid data to sent, then master device transmits MW and slave is ready to transmit data and then master is ready to sent data.  
 
                     									 	 
AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran 
	 
KNOWN BUGS            : 

NOTE                  : This is a I2C_MASTER code and error checking are not implemented 
						
CHANGE LOGS           : 

*****************************************************************************/

#include "main.h"
#include "port.h"
#include "io_conf.h"
#include "appl_conf.h" 
#include "i2c.h"
#include "i2c_fsm.h"
#include "uart.h"
#include "lcd.h"

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.
// 'C' source line config statements
#pragma config FOSC = XT    // Oscillator Selection bits (XT oscillator)
#pragma config WDTE = OFF   // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF  // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = OFF  // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = OFF    // Low-Voltage In-Circuit Serial Programming Enable bit
#pragma config CPD = OFF    // Data EEPROM Memory Code Protection bit
#pragma config WRT = OFF    // Flash Program Memory Write Enable bits
#pragma config CP = OFF     // Flash Program Memory Code Protection bit

char lcd_const_disp_flag[5] = {STATE_NO_IN_CHAR, STATE_NO_IN_CHAR, STATE_NO_IN_CHAR, STATE_NO_IN_CHAR, STATE_NO_IN_CHAR};
char master_tx_valid_data_str[][MAX_COMM_NUM_CHARS + 1] = {"MASTER", "FROM MASTER"};
char master_rcvd_valid_data_str[MAX_COMM_NUM_CHARS + 1], i2c_master_rcvd_data_str[MAX_COMM_NUM_CHARS + 1], i2c_master_tx_data_str[MAX_COMM_NUM_CHARS + 1];
unsigned int master_i2c_num_data_chars_received = 0, master_i2c_num_data_chars_transmitted = 0, master_i2c_valid_rcvd_num_data_chars, master_i2c_valid_tx_num_data_chars;
char i2c_rcv_enable_flag = STATE_NO_IN_CHAR, i2c_tx_enable_flag = STATE_NO_IN_CHAR, is_rcvd_end_data_char_flag = STATE_NO_IN_CHAR, is_tx_end_data_char_flag = STATE_NO_IN_CHAR, \
   is_rcvd_data_terminator_flag = STATE_NO_IN_CHAR, is_tx_data_terminator_flag = STATE_NO_IN_CHAR, is_master_i2c_ready = STATE_NO_IN_CHAR; 
master_i2c_frame_fsm_states  master_cur_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_IDLE, master_prev_i2c_frame_fsm_state ;
i2c_error_status_types i2c_error_status_type = I2C_NO_ERROR;
i2c_device_types i2c_device_type;
unsigned int i2c_slave_addr; 
unsigned char slave_internal_command = MW_CHAR;
unsigned int master_rcv_data_str_index = 0;
char is_master_rcvd_data_str_flag = STATE_INVALID_IN_CHAR;

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void main()
{
	 unsigned char master_i2c_rcvd_char, master_i2c_rcvd_ack_state, master_i2c_sent_char;   
	 char rcvd_status;	  
	 static char is_error_or_transfer_data_strs_over_flag = STATE_NO_IN_CHAR;
	 static unsigned int master_send_data_str_index = 0;
     
   TRISE = 0x00;
   PORTE = 0x00;
   LCD_PORT_GPIO = 0x00;        
   LCD_PORT = 0x00;     
   ANSEL = 0x00;
   ANSELH = 0x00; 
   LCD_Init();
   UART_Init();
    
  /* // SHOULD_REMOVE 
   Data_Str_Disp_LCD("CLOCK");
   UART_Transmit_Str("RTC\r"); */
   
   i2c_device_type = I2C_MASTER_TYPE;
   master_cur_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_IDLE;
     
   while(1)
   {
       //I2C_Frame_Fsm_Proc(i2c_device_type);	
       switch(master_cur_i2c_frame_fsm_state)
	   {
		   case MASTER_I2C_FRAME_FSM_IDLE:	
               if(is_error_or_transfer_data_strs_over_flag == STATE_NO_IN_CHAR)
			   {
		           #ifdef TRACE  
			         UART_Transmit_Str("MASTER_I2C_FRAME_FSM_IDLE state \r");	
			       #endif 
			  
                   Reset_Transfer_Parameters();
				   if(master_send_data_str_index < 2)
				   {
				       master_prev_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_IDLE;
			           master_cur_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_PASSIVE_OPEN;
			 
			           //SHOULD_REMOVE
			           #ifdef TRACE
			               UART_Transmit_Str("MASTER_I2C_FRAME_FSM_PASSIVE_OPEN state \r");	 
			            #endif	
				   }
				   else
				   {
					   is_error_or_transfer_data_strs_over_flag = STATE_YES_IN_CHAR;
				   }
			 }               
		   break;
		   case MASTER_I2C_FRAME_FSM_PASSIVE_OPEN:
		       I2C_Init(I2C_POLLING_SERVICE, I2C_MASTER_OSC_DIV4, I2C_SLEW_RATE_CTRL_DIS, I2C_MASTER_GNL_CALL_DONT_CARE, I2C_SLAVE_ADDR );  
		       i2c_rcv_enable_flag = STATE_YES_IN_CHAR;
		       i2c_tx_enable_flag = STATE_YES_IN_CHAR; 
			   master_prev_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_PASSIVE_OPEN; 
			   master_cur_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_SENT_START_BIT;
			   
			   //SHOULD_REMOVE
			   #ifdef TRACE 
			      UART_Transmit_Str("MASTER_I2C_FRAME_FSM_SENT_START_BIT state \r");	 
			   #endif
			  
		   break; 
           case MASTER_I2C_FRAME_FSM_SENT_START_BIT:
		      I2C_Sent_Start();
              switch(i2c_cur_service_type)
			  {
                  case I2C_INTP_SERVICE:				  
			         while(is_master_i2c_ready == STATE_NO_IN_CHAR);
			         is_master_i2c_ready = STATE_NO_IN_CHAR; 
				  break;
				  case I2C_POLLING_SERVICE:
				    while(SSPIF == 0)
					{
						;
					}
					SSPIF = 0;
              }				  
			  __delay_ms(REQ_TIME_MASTER_WAIT_IN_MILLI_SEC);
			  master_prev_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_SENT_START_BIT; 
			  master_cur_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_SENT_ADDR_WRITE;
				
			  //SHOULD_REMOVE
			  #ifdef TRACE  
			     UART_Transmit_Str("MASTER_I2C_FRAME_FSM_SENT_ADDR_WRITE state \r");	
			  #endif 
			  
	       break;
		   case MASTER_I2C_FRAME_FSM_SENT_ADDR_WRITE:
		     //(send I2C SLAVE address with write condition) 			 
		      master_i2c_rcvd_ack_state = Master_I2C_Send_Byte(i2c_slave_addr & 0xFE); 
              switch(i2c_cur_service_type)
			  {
                  case I2C_INTP_SERVICE:				  
			         while(is_master_i2c_ready == STATE_NO_IN_CHAR);
			         is_master_i2c_ready = STATE_NO_IN_CHAR; 
				  break;
              }				 
			  if(SSPCON2bits.ACKSTAT) 
				  master_i2c_rcvd_ack_state = STATE_NO_IN_INT;
              else if(!SSPCON2bits.ACKSTAT)			
				 master_i2c_rcvd_ack_state = STATE_YES_IN_INT;
			  		  
			  if(master_i2c_rcvd_ack_state != STATE_YES_IN_INT)
              {
				 #ifdef TRACE_ERROR
					UART_Transmit_Str("ERR: Send Slave Address with write ");\
					
				   //SHOULD_REMOVE
		             switch(master_i2c_rcvd_ack_state)
				     {
					    case STATE_INVALID_IN_INT:
					      UART_Transmit_Str("and rcvd INVALID\r"); 
					    break;
                        case STATE_NO_IN_INT:
                          UART_Transmit_Str("and rcvd NACK\r"); 
					    break;					   
					 }
				  #endif				  
				  master_prev_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_SENT_ADDR_WRITE;				 
				  Master_I2C_Sent_Stop(I2C_ERROR);
		          break;
	          }			   
			  __delay_ms(REQ_TIME_MASTER_WAIT_IN_MILLI_SEC);
			  master_cur_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_DATA_SENT_INTR_CMD;			  
			  
			   //SHOULD_REMOVE
			   #ifdef TRACE 
			       UART_Transmit_Str("Master sends I2C slave addr with write bit: ");	
                   UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, i2c_slave_addr & 0xFE );			  
			       UART_Transmit_Str("\rMASTER_I2C_FRAME_FSM_DATA_SENT_INTR_CMD state \r");	
			  #endif
			   master_prev_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_SENT_ADDR_WRITE; 
		   break;
           case MASTER_I2C_FRAME_FSM_DATA_SENT_INTR_CMD:
		      // (send I2C SLAVE's Internal command )
              master_i2c_rcvd_ack_state = Master_I2C_Send_Byte(slave_internal_command);  
              switch(i2c_cur_service_type)
			  {
                  case I2C_INTP_SERVICE:				  
			         while(is_master_i2c_ready == STATE_NO_IN_CHAR);
			         is_master_i2c_ready = STATE_NO_IN_CHAR; 
				  break;
              }				  
			  if(SSPCON2bits.ACKSTAT) 
				  master_i2c_rcvd_ack_state = STATE_NO_IN_INT;
              else if(!SSPCON2bits.ACKSTAT)			
				 master_i2c_rcvd_ack_state = STATE_YES_IN_INT;
			 
			  if(master_i2c_rcvd_ack_state != STATE_YES_IN_INT)
              {
				 
				 #ifdef TRACE_ERROR
				   //SHOULD_REMOVE
				     UART_Transmit_Str("ERR: Send internal command : ");
				     UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, slave_internal_command);
		             switch(master_i2c_rcvd_ack_state)
				     {
					    case STATE_INVALID_IN_INT:
					      UART_Transmit_Str(" and rcvd INVALID\r"); 
					    break;
                        case STATE_NO_IN_INT:
                          UART_Transmit_Str(" and rcvd NACK\r"); 
					    break;					   
					 }
				  #endif
				  
				   master_prev_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_DATA_SENT_INTR_CMD; 				  
				   Master_I2C_Sent_Stop(I2C_ERROR);	
			       break; 
			   }
			   switch(slave_internal_command)
		       {
		        	case MW_CHAR:
			           Append_Data_Terminator_Char(master_tx_valid_data_str[master_send_data_str_index], i2c_master_tx_data_str);
					   master_cur_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_SENT_DATA;			  
			  
			           //SHOULD_REMOVE
			           #ifdef TRACE  
			             UART_Transmit_Str("MASTER_I2C_FRAME_FSM_SENT_DATA state \r");
                         UART_Transmit_Str("Valid master's data str : ");
			             UART_Transmit_Str(master_tx_valid_data_str[master_send_data_str_index]);
				         UART_Transmit_Char('\r');
				         UART_Transmit_Str("To send master's data str : ");
				         UART_Transmit_Str(i2c_master_tx_data_str);
				         UART_Transmit_Char('\r');				   
			           #endif	
			          
		            break;
					case ENQ_CHAR:					    
					     master_cur_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_SENT_RESTART_BIT;			  
			  
			           //SHOULD_REMOVE
			           #ifdef TRACE  
			             UART_Transmit_Str("MASTER_I2C_FRAME_FSM_SENT_RESTART_BIT state \r");                        				   
			           #endif
					 break; 
					 default:
					 	//error: invalid internal command sent
					   ;  	
		        }
			     __delay_ms(REQ_TIME_MASTER_WAIT_IN_MILLI_SEC);
				master_prev_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_DATA_SENT_INTR_CMD; 
				 
		   break; 
           case MASTER_I2C_FRAME_FSM_SENT_DATA:
               master_i2c_sent_char = i2c_master_tx_data_str[master_i2c_valid_tx_num_data_chars];
			   		   
		       #ifdef TRACE
				    //SHOULD_REMOVE	
				    UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, master_i2c_sent_char);
					UART_Transmit_Str(" : ");
					UART_Transmit_Char(master_i2c_sent_char);
                    UART_Transmit_Char('\r');					
			  #endif
			  
			  master_i2c_rcvd_ack_state = Master_I2C_Send_Byte(master_i2c_sent_char);
              switch(i2c_cur_service_type)
			  {
                  case I2C_INTP_SERVICE:				  
			         while(is_master_i2c_ready == STATE_NO_IN_CHAR);
			         is_master_i2c_ready = STATE_NO_IN_CHAR; 
				  break;
              }				 
			  if(SSPCON2bits.ACKSTAT) 
				  master_i2c_rcvd_ack_state = STATE_NO_IN_INT;
              else if(!SSPCON2bits.ACKSTAT)			
				 master_i2c_rcvd_ack_state = STATE_YES_IN_INT;
			 
			  if(master_i2c_rcvd_ack_state != STATE_YES_IN_INT)
			  {
				  #ifdef TRACE_ERROR
				     //SHOULD_REMOVE
					 UART_Transmit_Str("ERR: Send char ");				    
		             switch(master_i2c_rcvd_ack_state)
				     {
					    case STATE_INVALID_IN_INT:
					      UART_Transmit_Str("and rcvd INVALID\r"); 
					    break;
                        case STATE_NO_IN_INT:
                          UART_Transmit_Str("and rcvd NACK\r"); 
					    break;					   
					 }
				  #endif 
				  
				  master_prev_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_SENT_DATA; 
				  Master_I2C_Sent_Stop(I2C_ERROR);
		          break; 				
			  }
			  switch(master_i2c_sent_char)
		      {	
                  case DATA_TERMINATOR_CHAR:
                     is_tx_data_terminator_flag = STATE_YES_IN_CHAR;	
					 
					 //SHOULD_REMOVE
					  #ifdef TRACE
					     UART_Transmit_Str("Send master's data terminator\r");
					  #endif
				      is_tx_end_data_char_flag = STATE_YES_IN_CHAR;    
					  ++master_i2c_num_data_chars_transmitted;
					  master_prev_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_SENT_DATA; 
					  Master_I2C_Sent_Stop(I2C_NO_ERROR);
					  
					  ++master_send_data_str_index;
				  break;	  
				  case PADDED_CHAR: 
                  case NULL_CHAR:
				     //SHOULD_REMOVE
					  #ifdef TRACE
					     UART_Transmit_Str("Send master's padded or null char\r");
					  #endif
				     ++master_i2c_num_data_chars_transmitted;
                  break;
                  default:
                     ++master_i2c_valid_tx_num_data_chars;
					 ++master_i2c_num_data_chars_transmitted;								       
			  }
			  __delay_ms(REQ_TIME_MASTER_WAIT_IN_MILLI_SEC);
			  
		   break;		   
		   case MASTER_I2C_FRAME_FSM_SENT_STOP_BIT:
		         I2C_Sent_Stop();
				 switch(i2c_cur_service_type)
			     {
                     case I2C_INTP_SERVICE:				  
			            while(is_master_i2c_ready == STATE_NO_IN_CHAR);
			            is_master_i2c_ready = STATE_NO_IN_CHAR; 
				     break;
					 case I2C_POLLING_SERVICE:
					    while(SSPIF == 0)
						{
							;
						}
						SSPIF = 0;	
					 break;
                 }			 
				 master_cur_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_TIME_WAIT;
				  
				 #ifdef TRACE 	   
	              //SHOULD_REMOVE
	                UART_Transmit_Str("Send master's stop bit \r");
					UART_Transmit_Str("MASTER_I2C_FRAME_FSM_TIME_WAIT state \r");
                 #endif
				 master_prev_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_SENT_STOP_BIT; 
		   break;
		   case MASTER_I2C_FRAME_FSM_TIME_WAIT:
		       __delay_ms(REQ_TIME_MASTER_WAIT_AFTER_SEND_STOP_BIT_IN_MILLI_SEC);			   
			   switch(i2c_cur_service_type)
			   {
				   case I2C_INTP_SERVICE:
				   // disable I2C interrupt
			          PIE1bits.SSPIE = 0;
                   break;
			   }				   
			   i2c_cur_service_type = I2C_INVALID_SERVICE;
			   switch(i2c_error_status_type)
	           {
                   case I2C_NO_ERROR:
				      switch(is_master_rcvd_data_str_flag)
					  {
						  case STATE_YES_IN_CHAR:
	        	             master_cur_i2c_frame_fsm_state =  MASTER_I2C_FRAME_FSM_PROC_RCVD_DATA;
							 
			                 #ifdef TRACE 	   
	                           //SHOULD_REMOVE
	                           UART_Transmit_Str("MASTER_I2C_FRAME_FSM_PROC_RCVD_DATA state \r");
                             #endif
							 
						  break;
                          default:
                            master_cur_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_IDLE;
					  }							
	               break;
                   case I2C_ERROR:
                   default:
				      is_error_or_transfer_data_strs_over_flag = STATE_YES_IN_CHAR;
                      master_cur_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_IDLE;		   
		              #ifdef TRACE  
		                UART_Transmit_Str("ERR: MASTER_I2C_FRAME_FSM_IDLE state \r");
		              #endif
		   
               }
			    master_prev_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_TIME_WAIT; 
		   break;
           default:
			    //error: invalid i2c frame fsm state
				;			 
	    }
    }   
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
