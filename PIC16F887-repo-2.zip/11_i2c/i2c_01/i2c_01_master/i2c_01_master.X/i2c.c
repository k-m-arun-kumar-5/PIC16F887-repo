/**************************************************************************
   FILE          :    i2c.c
 
   PURPOSE       :   I2C Library
 
   AUTHOR        :   K.M.Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
#include "main.h" 
#include "port.h"
#include "i2c.h"
#include "lcd.h"
#include "uart.h"
 
static void I2C_Wait_SSPIF(); 
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void I2C_Init(I2c_types I2C_type, I2c_slew_rate_ctrl_types I2C_slew_rate_ctrl_type,  I2c_gnl_call_types I2C_gnl_call_type )
{
	SSPSTAT = I2C_slew_rate_ctrl_type;
	SSPCON = I2C_type;
	SSPCON2 = I2C_gnl_call_type;
    if(I2C_type & 0b00000100) //If Slave Mode
    {
       SSPCON2 = I2C_gnl_call_type;  
    }
    else              //If Master Mode
    {
        
    }
}
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void I2C_Send_Start(void)
{
	SSPCON2bits.SEN = 1;
	I2C_Wait_SSPIF();
	while(SSPCON2bits.SEN == 1); // Wait till I2C is idle
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
char I2C_Master_Send_Byte(const unsigned int to_send_byte)
{
	unsigned char temp;
	
	while(Is_I2C_Idle(I2C_IDLE) == STATE_NO)
	{
		
	    //SHOULD_REMOVE
		Goto_XY_LCD_Disp(4,1);
		Data_Str_Disp_LCD("EB");
		UART_Transmit_Str(" I2C busy\r");
		
	}		
	if(SSPCONbits.WCOL == 1)
	{
		/* If the user writes the SSPBUF when a transmit is already in progress (i.e., SSPSR is still shifting out a data byte),
		the WCOL is set and the contents of the buffer are unchanged (the write doesn’t occur). WCOL must be cleared in software. */
		
		//SHOULD_REMOVE
		Goto_XY_LCD_Disp(4,4);
		Data_Str_Disp_LCD("EW");
		UART_Transmit_Str("ERR: WCOL in Send\r");
		
		while(SSPSTATbits.BF == 1); //wait till I2c has been completed in sending previous send byte
		SSPCONbits.WCOL = 0;
	}
	
	if(SSPCONbits.WCOL == 1)
	{
		/* If the user writes the SSPBUF when a receive is already in progress (i.e., SSPSR is still shifting in a data
           byte), the WCOL bit is set and the contents of the buffer are unchanged (the write doesn’t occur).  */
		   
		//SHOULD_REMOVE
		Goto_XY_LCD_Disp(4,4);
		Data_Str_Disp_LCD("EX");
		UART_Transmit_Str("ERR: WCOL in Wait to Send\r");
		
		if(SSPCON2bits.RCEN == 1)
	    {
	       while(SSPCON2bits.RCEN == 1);  // wait till i2c has completed received data
	       //temp = SSPBUF;
	    }
		SSPCONbits.WCOL = 0;
	}
	if(SSPCONbits.WCOL == 0)
	{	
        SSPBUF = to_send_byte;
	    I2C_Wait_SSPIF();  //wait till I2C transmitter has completed sending data byte and received ack seq 
	    if(SSPCON2bits.ACKSTAT)
		   return STATE_NO;    // return rcvd NACK  
        return  STATE_YES;    // return rcvd ACK 
    }
	return STATE_INVALID;
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
//Function : I2C_Stop sends stop bit sequence
void I2C_Send_Stop(void)
{
	SSPCON2bits.PEN = 1;			// Send stop bit
	I2C_Wait_SSPIF();
	while(SSPCON2bits.PEN == 1);   // Wait till I2C is idle
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
// Function Purpose: I2C_ReStart sends start bit sequence
void I2C_Send_Restart(void)
{
	SSPCON2bits.RSEN = 1;			// Send Restart bit
	I2C_Wait_SSPIF();
	while(SSPCON2bits.RSEN == 1);   // Wait till I2C is idle
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
// Function Purpose: I2C_Read_Byte reads one byte
unsigned char I2C_Rcvd_Byte(void)
{
	unsigned char rcvd_byte, temp;
	
	SSPCON2bits.RCEN = 1;
	
	if(SSPCONbits.SSPOV == 1) 
	{
		 /* In receive operation, the SSPOV bit is set when eight bits are received into the SSPSR 
		 and the BF bit is already set from a previous reception */
		 
		//SHOULD_REMOVE
		Goto_XY_LCD_Disp(4,7);
		Data_Str_Disp_LCD("ES");
		UART_Transmit_Str("ERR: SSPOV in receive\r");
		
		SSPCONbits.SSPOV = 0;
		// temp = SSPBUF; 
		return INVALID_I2C_OPER_CHAR;
	}
	if(SSPCONbits.WCOL == 1)
	{
		/* If the user writes the SSPBUF when a receive is already in progress (i.e., SSPSR is still shifting in a data
           byte), the WCOL bit is set and the contents of the buffer are unchanged (the write doesn’t occur).  */
		   
		//SHOULD_REMOVE
		Goto_XY_LCD_Disp(4,10);
		Data_Str_Disp_LCD("ER");
		UART_Transmit_Str("ERR: WCOL in receive\r");
		
		if(SSPCON2bits.RCEN == 1)
	    {
	        while(SSPCON2bits.RCEN == 1);   // receive in progress 
	       //temp = SSPBUF;
	    }
		SSPCONbits.WCOL = 0;
	}
	
	
    if(SSPCONbits.WCOL == 0 && SSPCONbits.SSPOV == 0)
	{		
	   		// Enable reception of 8 bits
	   while(SSPSTATbits.BF == 0);   // receive in progress    
        rcvd_byte = SSPBUF;		        //  received byte
	    I2C_Wait_SSPIF();
	    return rcvd_byte; 
	}
	
	//SHOULD_REMOVE
	Goto_XY_LCD_Disp(4,7);
	Data_Str_Disp_LCD("EZ");
	UART_Transmit_Str("ERR: WCOL or SSPOV in receive\r"); 
	
	return INVALID_I2C_OPER_CHAR;
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
//Function : I2C_Send_ACK sends ACK bit sequence
void I2C_Send_ACK(void)
{
	SSPCON2bits.ACKDT = 0;			// 0 means ACK
	SSPCON2bits.ACKEN = 1;			// Send ACKDT value
	I2C_Wait_SSPIF();       
	while(SSPCON2bits.ACKEN == 1);  // Wait till I2C is idle	
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
//Function : I2C_Send_NACK sends NACK bit sequence
void I2C_Send_NACK(void)
{
	SSPCON2bits.ACKDT = 1;			// 1 means NACK
	SSPCON2bits.ACKEN = 1;			// Send ACKDT value
	I2C_Wait_SSPIF();
    while(SSPCON2bits.ACKEN == 1);  // Wait till I2C is idle
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
char Is_I2C_Idle(idle_i2c_states idle_i2c_state)
{
	char idle_flag = STATE_YES;  
    /*                           _
	  SSPSTATbits.R = bit 2 or R/W */
	switch(idle_i2c_state)
	{
		case I2C_IDLE:
		   if(SSPSTATbits.R || SSPCON2bits.SEN || SSPCON2bits.RSEN || SSPCON2bits.PEN || SSPCON2bits.ACKEN || SSPCON2bits.RCEN)
			   idle_flag = STATE_NO; // i2c not idle
		break;
        case I2C_START_IDLE:
           	if(SSPSTATbits.R || SSPCON2bits.SEN )
              	idle_flag = STATE_NO; // i2c not idle due to start in progress
        break;
        case I2C_REPEAT_START_IDLE:
           	if(SSPSTATbits.R || SSPCON2bits.RSEN )
              	idle_flag = STATE_NO; // i2c not idle due to repeat start in progress
        break; 
        case I2C_STOP_IDLE:
           	if(SSPSTATbits.R || SSPCON2bits.PEN )
              	idle_flag = STATE_NO; // i2c not idle due to stop in progress
        break;	
        case I2C_ACK_SEQ_IDLE:
           	if(SSPSTATbits.R || SSPCON2bits.ACKEN )
              	idle_flag = STATE_NO; // i2c not idle due to ACK sequence in progress
        break;
		case I2C_RECEIVE_IDLE:
           	if(SSPSTATbits.R || SSPCON2bits.RCEN )
              	idle_flag = STATE_NO; // i2c not idle due to receive in progress
        break; 
        default:
		  //error: due to invalid idle state mode
		  ;
	} 
    return 	idle_flag;
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
static void I2C_Wait_SSPIF()
{
	while(SSPIF == 0); //Wait for it to complete
	SSPIF = 0;         // Clear the flag bit
}
 /*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
