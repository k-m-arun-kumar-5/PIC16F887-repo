/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    :  by using I2C, get RTC(real time clock) time from I2C enabled RTC chip (I2C slave) and display it in LCD_MASTER connected to I2C master PIC.  

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : This is a I2C_MASTER code                                  
                       
CHANGE LOGS           : 

*****************************************************************************/

// 'C' source line config statements

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include "main.h"
#include "port.h"
#include "lcd.h"
#include "i2c.h"
#include "uart.h"
#include "string.h"
#include "assert.h"

#define REQ_TIME_CNT_AFTER_SEND_STOP_FLAG            (100UL)
#define REQ_RTC_DATAS                                   (7U)

void RTC_Datas_BCD_to_Binary_Conv(const unsigned char *rtc_datas_from_rtc);
unsigned int BCD_to_Binary_Conv(const unsigned int rtc_datas_in_bcd);

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void main()
{
	unsigned int rtc_internal_addr, rtc_data_index;
	unsigned char rtc_datas_from_rtc[REQ_RTC_DATAS], rcv_char;
	
   TRISE = 0x00;
   PORTE = 0x00;
   LCD_PORT_GPIO = 0x00;        
   LCD_PORT = 0x00;  
   ANSEL = 0x00;
   ANSELH = 0x00; 
   LCD_Init();
   UART_Init();
   /*  DS1307(RTC) supports in I2C standard mode (100KHz) only */
   I2C_Init(I2C_MASTER_OSC_DIV4, I2C_SLEW_RATE_CTRL_DIS, I2C_MASTER_GNL_CALL_DONT_CARE);  
  
  /* // SHOULD_REMOVE 
   Data_Str_Disp_LCD("CLOCK");
   UART_Transmit_Str("RTC\r"); */
   
   Delay_Time_By_Count(REQ_TIME_CNT_AFTER_SEND_STOP_FLAG);
   Delay_Time_By_Count(REQ_TIME_CNT_AFTER_SEND_STOP_FLAG);
   
   while(1)
   {
       I2C_Send_Start();
	   
	   //SHOULD_REMOVE
	   #ifdef TRACE
	     UART_Transmit_Str("Send Start\r"); 
	   #endif
	   
       if(I2C_Master_Send_Byte(0xD0) != STATE_YES) //(send DS1307(RTC) I2C SLAVE address(D0) with write condition) 
       {
		   //SHOULD_REMOVE
	       UART_Transmit_Str("Send Slave Address with write and rcvd not ack\r"); 
		   
		   I2C_Send_Stop(); 		   
           Delay_Time_By_Count(REQ_TIME_CNT_AFTER_SEND_STOP_FLAG);			   
		   continue; 
	   }
	   #ifdef TRACE 
	   //SHOULD_REMOVE
       UART_Transmit_Str("Send Slave Address with write\r"); 	   
	   #endif
	   
       if(I2C_Master_Send_Byte(0x00)  != STATE_YES)
	   {
		   //SHOULD_REMOVE
	       UART_Transmit_Str("Send Slave intn addr and rcvd not ack\r");	

		   I2C_Send_Stop();
           Delay_Time_By_Count(REQ_TIME_CNT_AFTER_SEND_STOP_FLAG);			
		   continue; 
                  			  
	    }
		#ifdef TRACE
	   //SHOULD_REMOVE
	   UART_Transmit_Str("Send Slave intn addr\r");	
	    #endif
		
       I2C_Send_Restart();
	   
		#ifdef TRACE   
       //SHOULD_REMOVE
	   UART_Transmit_Str("Send restart\r");	
	   #endif   
	   
       if(I2C_Master_Send_Byte(0xD1) != STATE_YES)    //(send DS1307(RTC) I2C SLAVE address(D0) with read condition 
	   {
		     //SHOULD_REMOVE
	        UART_Transmit_Str("Send Slave Address with read and rcvd not ack\r"); 
			   
		    I2C_Send_Stop();
            Delay_Time_By_Count(REQ_TIME_CNT_AFTER_SEND_STOP_FLAG);			
			continue;
	   }
	   
	   	#ifdef TRACE 
       //SHOULD_REMOVE
	   UART_Transmit_Str("Send Slave Address with read\r");  
	    #endif  
		
	   for( rtc_internal_addr = 0, rtc_data_index = 0; rtc_data_index < REQ_RTC_DATAS - 1; rtc_internal_addr++, rtc_data_index++)
       {
           rcv_char =  I2C_Rcvd_Byte(); // rcv 
		   if(rcv_char == INVALID_I2C_OPER_CHAR)
		   {
			    I2C_Send_NACK();
			   
	            //SHOULD_REMOVE
	            UART_Transmit_Str("Send master's NACK\r");
			   
	            I2C_Send_Stop();
                Delay_Time_By_Count(REQ_TIME_CNT_AFTER_SEND_STOP_FLAG);  
     		    break;
		   }

           rtc_datas_from_rtc[rtc_data_index] = rcv_char; 
		   
		   #ifdef TRACE 
		      //SHOULD_REMOVE
	          UART_Transmit_Str("Read Slave's intn addr - ");
		      UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, rtc_data_index);
		      UART_Transmit_Str(" : ");
		      UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, rtc_datas_from_rtc[rtc_data_index]);
		      UART_Transmit_Char('\r');
		   #endif 
		   
		   I2C_Send_ACK();
		   
		   #ifdef TRACE 	   
		      //SHOULD_REMOVE
		      UART_Transmit_Str("Send master's ACK\r");
		   #endif
		   
       }
        if(rtc_data_index == REQ_RTC_DATAS - 1)	
		{			
	       rcv_char =  I2C_Rcvd_Byte(); // rcv 
		   if(rcv_char == INVALID_I2C_OPER_CHAR)
		   {
		    	I2C_Send_NACK();
			   
	           //SHOULD_REMOVE
	           UART_Transmit_Str("Send master's NACK\r");
			   
	           I2C_Send_Stop();
               Delay_Time_By_Count(REQ_TIME_CNT_AFTER_SEND_STOP_FLAG); 
			   continue;
		   }
		    rtc_datas_from_rtc[rtc_data_index] = rcv_char; 
		
	        #ifdef TRACE 				   
	       //SHOULD_REMOVE
	        UART_Transmit_Str("Read Slave's intn addr - ");
	        UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, rtc_data_index);
	        UART_Transmit_Str(" : ");
	        UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, rtc_datas_from_rtc[rtc_data_index]);
	        UART_Transmit_Char('\r');	
	 	    #endif	
		
	        I2C_Send_NACK();
		
		    #ifdef TRACE 		   
	       //SHOULD_REMOVE
	        UART_Transmit_Str("Send master's NACK\r");
		    #endif	
		
	        I2C_Send_Stop();
		
		    #ifdef TRACE 	   
	       //SHOULD_REMOVE
	        UART_Transmit_Str("Send Master Stop\r");
            #endif
		 
            Delay_Time_By_Count(REQ_TIME_CNT_AFTER_SEND_STOP_FLAG);
		
		   //RTC datas from RTC chip are in BCD format, conv RTC datas into binary format
            RTC_Datas_BCD_to_Binary_Conv(rtc_datas_from_rtc);
            memset(rtc_datas_from_rtc, '\0', REQ_RTC_DATAS);
		}
    }   
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void RTC_Datas_BCD_to_Binary_Conv(const unsigned char *rtc_datas_from_rtc)
{
	unsigned int seconds, minutes, hours, day, date, month, year; 
	Goto_XY_LCD_Disp(1,1);
    if(rtc_datas_from_rtc[2] < 0x24 )
	{
		hours = BCD_to_Binary_Conv(rtc_datas_from_rtc[2]);
	    Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, hours ); 
	}
	else
	{
		//error: invalid hours
	}
    Write_LCD_Data(':');
	
	Goto_XY_LCD_Disp(1,4);
	if(rtc_datas_from_rtc[1] < 0x60 )
	{
	   minutes = BCD_to_Binary_Conv(rtc_datas_from_rtc[1]);
	   
	   Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, minutes); 
	}
	else
	{
		//error: invalid minutes
	}
    Write_LCD_Data(':');
	
	if(rtc_datas_from_rtc[0] < 0x60 )
	{
	   seconds =  BCD_to_Binary_Conv(rtc_datas_from_rtc[0]);
	    Goto_XY_LCD_Disp(1,7);
	   Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, seconds); 
    }
	else
	{
		//error: invalid seconds
	}
	
	Goto_XY_LCD_Disp(2,1);
    if(rtc_datas_from_rtc[3] > 0x00 && rtc_datas_from_rtc[3] < 0x08)
	{
		day = BCD_to_Binary_Conv(rtc_datas_from_rtc[3]);
        switch(day)
        {
        	case 1:
	           Data_Str_Disp_LCD("SUN");
	        break;
	        case 2:
	           Data_Str_Disp_LCD("MON");
	        break; 
	        case 3:
	           Data_Str_Disp_LCD("TUE");
	        break;
	        case 4:
	           Data_Str_Disp_LCD("WED");
	        break; 
	        case 5:
	           Data_Str_Disp_LCD("THU");
	        break; 
	        case 6:
	          Data_Str_Disp_LCD("FRI");
	        break;
	        case 7:
	          Data_Str_Disp_LCD("SAT");
	        break;	    
        }
	}
	else
	{
          Goto_XY_LCD_Disp(4,14); 
		  Data_Str_Disp_LCD("ED");  
	}
	
	Write_LCD_Data(' ');
	Goto_XY_LCD_Disp(2,5); 
	if(rtc_datas_from_rtc[4] > 0x00 && rtc_datas_from_rtc[4] < 0x32 )
	{
		 date = BCD_to_Binary_Conv(rtc_datas_from_rtc[4]);
         Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, date);
	}
	else
	{
		//error: invalid date range
	}
    Write_LCD_Data(' ');
	Goto_XY_LCD_Disp(2,8);
    if(rtc_datas_from_rtc[5] > 0x00 && rtc_datas_from_rtc[5] < 0x13 )
	{
        month = BCD_to_Binary_Conv(rtc_datas_from_rtc[5]);
        switch(month)
	    {
	    	case 1:
	    	   Data_Str_Disp_LCD("JAN");
	    	break;
            case 2:
               Data_Str_Disp_LCD("FEB");
		    break; 
		    case 3:
		       Data_Str_Disp_LCD("MAR");
		    break;
            case 4:
               Data_Str_Disp_LCD("APR");
		    break;
            case 5:
		       Data_Str_Disp_LCD("MAY");
		    break;
            case 6:
               Data_Str_Disp_LCD("JUN");
		    break; 
		    case 7:
		       Data_Str_Disp_LCD("JUL");
		    break;
            case 8:
               Data_Str_Disp_LCD("AUG");
		    break; 
		    case 9:
		       Data_Str_Disp_LCD("SEP");
		    break;
            case 10:
               Data_Str_Disp_LCD("OCT");
		    break; 
	        case 11:
		      Data_Str_Disp_LCD("NOV");
		    break;
            case 12:
              Data_Str_Disp_LCD("DEC");
		    break; 		
	    }		
	}	  
	else
	{
        Goto_XY_LCD_Disp(4,17); 
		Data_Str_Disp_LCD("EM");
	}
    Goto_XY_LCD_Disp(2,11); 
    Write_LCD_Data(' ');   
    year = BCD_to_Binary_Conv(rtc_datas_from_rtc[6]);
	Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, 20);
	Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, year);
    
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
unsigned int BCD_to_Binary_Conv(const unsigned int rtc_data_in_bcd)
{
	unsigned int rtc_data_in_binary = 0, most_nibble, least_nibble;
	
	most_nibble = ((rtc_data_in_bcd & 0xF0) >> 4);
	assert(most_nibble < 10);
	least_nibble = (rtc_data_in_bcd & 0x0F);
	assert(least_nibble < 10);
	rtc_data_in_binary = most_nibble * 10 + least_nibble;
	return rtc_data_in_binary;
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
