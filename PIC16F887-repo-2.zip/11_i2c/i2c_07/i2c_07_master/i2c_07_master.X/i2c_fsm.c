/* ********************************************************************
   FILE                   : i2c_fsm.c

   PROGRAM DESCRIPTION    : I2C frame fsm library 
                      									 
	 
   AUTHOR                :    K.M. Arun Kumar alias Arunkumar Murugeswaran 
	 
   KNOWN BUGS            : 

   NOTE                  :  										
                                    
   CHANGE LOGS           : 

*****************************************************************************/
#include "main.h"
#include "port.h"
#include "io_conf.h"
#include "appl_conf.h"
#include "lcd.h"
#include "i2c.h"
#include "uart.h"
#include "i2c_fsm.h"
#include "string.h"

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void I2C_Frame_Fsm_Proc(const i2c_device_types cur_i2c_device_type)
{    
      
       
	   
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void Master_I2C_Sent_Stop(const i2c_error_status_types cur_i2c_error_status_type)
{
	char rcvd_status;	
	
	__delay_ms(REQ_TIME_MASTER_WAIT_IN_MILLI_SEC);
	i2c_error_status_type = cur_i2c_error_status_type;
	switch(i2c_error_status_type)
	{
        case I2C_NO_ERROR:
	       rcvd_status = I2C_Addr_Info();
	       if(rcvd_status == STATE_YES_IN_CHAR)	//transmit or rcvd data str		  
	       {
	          if(master_cur_i2c_frame_fsm_state == MASTER_I2C_FRAME_FSM_RCV_DATA)
	          {
		         is_master_rcvd_data_str_flag = STATE_YES_IN_CHAR;    				  
		      }
              else
	          {			
                 is_master_rcvd_data_str_flag = STATE_NO_IN_CHAR;  
		      } 
           }
	       else
	       {
	     	  is_master_rcvd_data_str_flag = STATE_INVALID_IN_CHAR; 
	       }
		break;   
	}
	master_cur_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_SENT_STOP_BIT;
	
	//SHOULD_REMOVE
	#ifdef TRACE  
	    UART_Transmit_Str("master rcvd data str flag : ");
		UART_Transmit_Char(is_master_rcvd_data_str_flag);
		UART_Transmit_Char('\r');
	    UART_Transmit_Str("MASTER_I2C_FRAME_FSM_SENT_STOP_BIT state \r");	
	#endif
    
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
 void Reset_Transfer_Parameters()
{
	SSPCONbits.SSPEN = 0; // Disables serial port and configures these pins as I/O port pins
	i2c_error_status_type = I2C_NO_ERROR;
	master_i2c_num_data_chars_received = 0;
	master_i2c_valid_rcvd_num_data_chars = 0;
	memset(i2c_master_rcvd_data_str, NULL_CHAR, MAX_COMM_NUM_CHARS);
	is_rcvd_end_data_char_flag = STATE_NO_IN_CHAR;
	is_rcvd_data_terminator_flag = STATE_NO_IN_CHAR;
	
	is_tx_data_terminator_flag = STATE_NO_IN_CHAR; 
	master_i2c_num_data_chars_transmitted = 0;
	master_i2c_valid_tx_num_data_chars = 0;
	memset(i2c_master_tx_data_str, NULL_CHAR, MAX_COMM_NUM_CHARS);	
	is_tx_end_data_char_flag = STATE_NO_IN_CHAR;
	
	i2c_error_status_type = I2C_NO_ERROR;
	is_master_i2c_ready = STATE_NO_IN_CHAR;
	is_extr_intp_sw_pressed_flag = STATE_NO_IN_CHAR;
} 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void Append_Data_Terminator_Char(const char * const valid_data_str, char * const append_data_terminator_str)
{
	unsigned int valid_data_str_len;
	
	memset(append_data_terminator_str, NULL_CHAR, MAX_COMM_NUM_CHARS);
	valid_data_str_len = strlen(valid_data_str);	
	strncpy(append_data_terminator_str,valid_data_str, valid_data_str_len );
	append_data_terminator_str[valid_data_str_len] = DATA_TERMINATOR_CHAR;
		
	//SHOULD_REMOVE
	#ifdef TRACE
	   UART_Transmit_Str("Data terminated str: ");
	   UART_Transmit_Str(append_data_terminator_str);
	   UART_Transmit_Char('\r');
	#endif
} 

 /*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
