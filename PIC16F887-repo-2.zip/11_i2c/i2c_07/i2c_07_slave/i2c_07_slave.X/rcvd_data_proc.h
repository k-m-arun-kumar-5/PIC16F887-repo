/**************************************************************************
   FILE          :    rcvd_data_proc.h
 
   PURPOSE       :   rcvd datas Procedure Header
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran 
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/ 
#ifndef _RCVD_DATA_PROC_H
#define	_RCVD_DATA_PROC_H

#define SLAVE_LCD_RCVD_DATA_LINE_NUM                  (3U)
#define SLAVE_LCD_ERR_LINE_NUM                        (4U)

#endif	

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
