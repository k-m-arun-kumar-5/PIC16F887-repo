/**************************************************************************
   FILE          :    i2c_fsm.h
 
   PURPOSE       :   I2C Frame FSM header 
 
   AUTHOR        :     K.M. Arun Kumar alias Arunkumar Murugeswaran 
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _I2C_FSM_H
#define _I2C_FSM_H

/* -------------------- macro  defination ---------------------------------------- */


/* -------------------- data type defination ---------------------------------------- */

typedef enum {SLAVE_I2C_FRAME_FSM_IDLE,SLAVE_I2C_FRAME_FSM_WAIT_PASSIVE_OPEN, SLAVE_I2C_FRAME_FSM_PASSIVE_OPEN, SLAVE_I2C_FRAME_FSM_RCV_START_BIT, SLAVE_I2C_FRAME_FSM_RCV_ADDR_WRITE, \
SLAVE_I2C_FRAME_FSM_DATA_RCV_INTR_CMD, SLAVE_I2C_FRAME_FSM_SENT_DATA, SLAVE_I2C_FRAME_FSM_RCV_ADDR_READ, SLAVE_I2C_FRAME_FSM_RCV_DATA, SLAVE_I2C_FRAME_FSM_RCV_RESTART_BIT, \
SLAVE_I2C_FRAME_FSM_RCVD_STOP_BIT, SLAVE_I2C_FRAME_FSM_PROC_RCVD_DATA  } slave_i2c_frame_fsm_states;
  
typedef enum { I2C_MASTER_TYPE, I2C_SLAVE_TYPE } i2c_device_types; 
  
typedef enum {I2C_NO_ERROR = 0,  I2C_ERROR} i2c_error_status_types;  

/* -------------------- public variable  declaration---------------------------------------- */

extern char slave_tx_valid_data_str[][15 + 1];  //MAX_COMM_NUM_CHARS = 15
extern char slave_rcvd_valid_data_str[], i2c_slave_rcvd_data_str[], i2c_slave_tx_data_str[];
extern unsigned int slave_i2c_num_data_chars_received, slave_i2c_num_data_chars_transmitted,  slave_i2c_valid_rcvd_num_data_chars, slave_i2c_valid_tx_num_data_chars ;
extern char i2c_rcv_enable_flag , i2c_tx_enable_flag, is_rcvd_end_char_flag, is_tx_end_char_flag, is_rcvd_data_terminator_flag, is_tx_data_terminator_flag, is_slave_i2c_send_or_rcvd_char_flag ;
extern char lcd_const_disp_flag[5] ;
extern slave_i2c_frame_fsm_states  slave_i2c_frame_fsm_state;
extern i2c_error_status_types i2c_error_status_type;
extern i2c_device_types i2c_device_type;
extern unsigned int slave_send_data_str_index, slave_rcv_data_str_index;
extern char is_slave_rcvd_data_str_flag;
extern volatile char is_extr_intp_occured_flag;

/* -------------------- public prototype declaration --------------------------------------- */
void I2C_Frame_Fsm_Proc(const i2c_device_types cur_i2c_device_type);
int Slave_I2C_Rcvd_Data_Proc(unsigned char *, unsigned int ); 
void Reset_Transfer_Parameters();
void Append_Data_Terminator_Char(const char * const valid_data_str, char * const append_data_terminator_str);
void Slave_I2C_Rcv_Stop(const i2c_error_status_types cur_i2c_error_status_type);

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
