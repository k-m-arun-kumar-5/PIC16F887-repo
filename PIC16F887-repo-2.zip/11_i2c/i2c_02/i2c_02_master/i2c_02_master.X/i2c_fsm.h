/**************************************************************************
   FILE          :    i2c_fsm.h
 
   PURPOSE       :   I2C Frame FSM header 
 
   AUTHOR        :    K.M.Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _I2C_FSM_H
#define _I2C_FSM_H

/* -------------------- macro  defination ---------------------------------------- */
#define REQ_TIME_CNT_AFTER_SEND_STOP_FLAG            (100UL)
#define MAX_COMM_NUM_CHARS                            (20U)

                
#define NULL_CHAR                     ('\0')



/* -------------------- data type defination ---------------------------------------- */

typedef enum {MASTER_I2C_FRAME_FSM_IDLE, MASTER_I2C_FRAME_FSM_PASSIVE_OPEN, MASTER_I2C_FRAME_FSM_SENT_START_BIT, MASTER_I2C_FRAME_FSM_SENT_ADDR_WRITE, MASTER_I2C_FRAME_FSM_DATA_SENT_INTR_ADDR, \
   MASTER_I2C_FRAME_FSM_SENT_DATA, MASTER_I2C_FRAME_FSM_SENT_ADDR_READ, MASTER_I2C_FRAME_FSM_RCV_DATA, MASTER_I2C_FRAME_FSM_SENT_RESTART_BIT, MASTER_I2C_FRAME_FSM_SENT_STOP_BIT, \
   MASTER_I2C_FRAME_FSM_PROC_RCVD_DATA } master_i2c_frame_fsm_states;

/* -------------------- public variable  declaration---------------------------------------- */

extern master_i2c_frame_fsm_states  master_i2c_frame_fsm_state;

/* -------------------- public prototype declaration --------------------------------------- */
void I2C_Frame_Fsm_Proc();
void Reset_Transfer_Parameters();

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
