/**************************************************************************
   FILE          :    rtc_proc.h
 
   PURPOSE       :   rcvd RTC datas Procedure Header
 
   AUTHOR        :     K.M. Arun Kumar alias Arunkumar Murugeswaran 
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/ 
#ifndef _RTC_PROC_H
#define	_RTC_PROC_H

#define REQ_RTC_DATAS                                  (7U)
void RTC_Datas_BCD_to_Binary_Conv(const unsigned char *rtc_datas_from_rtc);
unsigned int BCD_to_Binary_Conv(const unsigned int rtc_data_in_bcd);

extern unsigned char rtc_datas_from_rtc[REQ_RTC_DATAS];

#endif	

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
