/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    :  by using I2C, get RTC(real time clock) time from I2C enabled RTC chip (I2C slave) and display it in LCD_MASTER connected to I2C master PIC.
   Modified from i2c_01_master with I2C Frame FSM been added. 

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  :  This is a I2C_MASTER code
                                  
                       
CHANGE LOGS           : 

*****************************************************************************/       
// 'C' source line config statements

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include "main.h"
#include "port.h"
#include "i2c.h"
#include "i2c_fsm.h"
#include "uart.h"
#include "lcd.h"

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void main()
{
		
   TRISE = 0x00;
   PORTE = 0x00;
   LCD_PORT_GPIO = 0x00;        
   LCD_PORT = 0x00;  
   ANSEL = 0x00;
   ANSELH = 0x00; 
   LCD_Init();
   UART_Init();
   /*  DS1307(RTC) supports in I2C standard mode (100KHz) only */
   I2C_Init(I2C_MASTER_OSC_DIV4, I2C_SLEW_RATE_CTRL_DIS, I2C_MASTER_GNL_CALL_DONT_CARE);  
  
  /* // SHOULD_REMOVE 
   Data_Str_Disp_LCD("CLOCK");
   UART_Transmit_Str("RTC\r"); */
   
   Delay_Time_By_Count(REQ_TIME_CNT_AFTER_SEND_STOP_FLAG);
   Delay_Time_By_Count(REQ_TIME_CNT_AFTER_SEND_STOP_FLAG);
   
   while(1)
   {
       I2C_Frame_Fsm_Proc();
	   
   }   
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
