/* ********************************************************************
   FILE                   : i2c_fsm.c

   PROGRAM DESCRIPTION    : I2C frame fsm library 
                      									 
	 
   AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
   KNOWN BUGS            : 

   NOTE                  :  										
                                    
   CHANGE LOGS           : 

*****************************************************************************/
#include "main.h"
#include "port.h"
#include "lcd.h"
#include "i2c.h"
#include "uart.h"
#include "i2c_fsm.h"
#include "rtc_proc.h"
#include "string.h"

#define REQ_TIME_CNT_AFTER_SEND_STOP_FLAG            (100UL)
//#define TRACE                                          (1)
unsigned char rtc_datas_from_rtc[REQ_RTC_DATAS];

master_i2c_frame_fsm_states  master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_IDLE;
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void I2C_Frame_Fsm_Proc()
{    
       char is_first_instance_occur_flag = STATE_NO; 
       unsigned int rtc_internal_addr, rtc_data_index;
	   unsigned char rcv_char;   
	   
	   switch(master_i2c_frame_fsm_state)
	   {
		   case MASTER_I2C_FRAME_FSM_IDLE:	
             rtc_internal_addr = 0;
			 rtc_data_index = 0;
			 memset(rtc_datas_from_rtc, '\0', REQ_RTC_DATAS);
			 
             //SHOULD_REMOVE
			// if(is_first_instance_occur_flag == STATE_NO)
			 {
				#ifdef TRACE  
                   UART_Transmit_Str("Master in MASTER_I2C_FRAME_FSM_IDLE state \r");	
				#endif
			   // is_first_instance_occur_flag = STATE_YES;
			 }
			 
			 master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_PASSIVE_OPEN;
			 
			  //SHOULD_REMOVE
             #ifdef TRACE 
			    UART_Transmit_Str("Master in MASTER_I2C_FRAME_FSM_PASSIVE_OPEN state \r");	 
             #endif

		   break;
		   case MASTER_I2C_FRAME_FSM_PASSIVE_OPEN:
		       master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_SENT_START_BIT;
			   
			   //SHOULD_REMOVE
			   #ifdef TRACE 
			      UART_Transmit_Str("Master in MASTER_I2C_FRAME_FSM_SENT_START_BIT state \r");	 
			   #endif			   			    			   
		   break; 
		   case MASTER_I2C_FRAME_FSM_SENT_START_BIT:
		       I2C_Send_Start(); 
			   master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_SENT_ADDR_WRITE;
				
			  //SHOULD_REMOVE
			  #ifdef TRACE  
			     UART_Transmit_Str("Master in MASTER_I2C_FRAME_FSM_SENT_ADDR_WRITE state \r");	
			  #endif
	       break;
		   case MASTER_I2C_FRAME_FSM_SENT_ADDR_WRITE:
		      if(I2C_Master_Send_Byte(0xD0) != STATE_YES) //(send DS1307(RTC) I2C SLAVE address(D0) with write condition) 
              {
		          //SHOULD_REMOVE
	              UART_Transmit_Str("Send Slave Address with write and rcvd not ack\r"); 
		   
		          I2C_Send_Stop(); 		   
                  Delay_Time_By_Count(REQ_TIME_CNT_AFTER_SEND_STOP_FLAG);			   
                  master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_IDLE;
			      break;
	          }
			  master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_DATA_SENT_INTR_ADDR;			  
			  
			  //SHOULD_REMOVE
			  #ifdef TRACE  
			     UART_Transmit_Str("Master in MASTER_I2C_FRAME_FSM_DATA_SENT_INTR_ADDR state \r");	
			  #endif
		   break;
           case MASTER_I2C_FRAME_FSM_DATA_SENT_INTR_ADDR:
			   if(I2C_Master_Send_Byte(0x00)  != STATE_YES)
	           {
		          
				   //SHOULD_REMOVE
	               UART_Transmit_Str("Send Slave intn addr and rcvd not ack\r");	

		           I2C_Send_Stop();
                   Delay_Time_By_Count(REQ_TIME_CNT_AFTER_SEND_STOP_FLAG);			
		           master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_IDLE;
			       break;                  			  
	            }
				master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_SENT_RESTART_BIT;			  
			  
			    //SHOULD_REMOVE
			    #ifdef TRACE  
			       UART_Transmit_Str("Master in MASTER_I2C_FRAME_FSM_SENT_RESTART_BIT state \r");	
			    #endif					    
		   break; 
		   case MASTER_I2C_FRAME_FSM_SENT_RESTART_BIT:		   
		      I2C_Send_Restart();
			  master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_SENT_ADDR_READ ;
					  
			  //SHOULD_REMOVE
			  #ifdef TRACE  
			     UART_Transmit_Str("Master in MASTER_I2C_FRAME_FSM_SENT_ADDR_READ state \r");	
			  #endif 
		   break;
		   case MASTER_I2C_FRAME_FSM_SENT_ADDR_READ:
			  if(I2C_Master_Send_Byte(0xD1) != STATE_YES)    //(send DS1307(RTC) I2C SLAVE address(D0) with read condition 
	          {
                    
				  //SHOULD_REMOVE
	               UART_Transmit_Str("Send Slave Address with read and rcvd not ack\r"); 
			   
		           I2C_Send_Stop();
                   Delay_Time_By_Count(REQ_TIME_CNT_AFTER_SEND_STOP_FLAG);			
			       master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_IDLE;
			       break;                  			  
	          }
			  rtc_internal_addr = 0;
			  rtc_data_index = 0;
			  master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_RCV_DATA;			  
			  
			 //SHOULD_REMOVE
			 #ifdef TRACE  
			    UART_Transmit_Str("Master in MASTER_I2C_FRAME_FSM_RCV_DATA state \r");	
			 #endif					    
		  break; 
		  case MASTER_I2C_FRAME_FSM_RCV_DATA:
			     rcv_char =  I2C_Rcvd_Byte(); // rcv 
		         if(rcv_char == INVALID_I2C_OPER_CHAR)
		         {
			          I2C_Send_Stop();
                      Delay_Time_By_Count(REQ_TIME_CNT_AFTER_SEND_STOP_FLAG);			
			          master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_IDLE;
					  break;
		         }
                 rtc_datas_from_rtc[rtc_data_index] = rcv_char; 
		   
		         #ifdef TRACE 
		           //SHOULD_REMOVE
	               UART_Transmit_Str("Read Slave's intn addr - ");
		           UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, rtc_data_index);
		           UART_Transmit_Str(" : ");
		           UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, rtc_datas_from_rtc[rtc_data_index]);
		           UART_Transmit_Char('\r');
		         #endif 
				 
				 ++rtc_internal_addr;
				 ++rtc_data_index;
				 if(rtc_data_index < REQ_RTC_DATAS)
				 {
		             I2C_Send_ACK();
					 
					 #ifdef TRACE 	   
		             //SHOULD_REMOVE
		                 UART_Transmit_Str("Send master's ACK\r");
		             #endif
				 }
			    else
				{
		             I2C_Send_NACK();
					 master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_SENT_STOP_BIT;
					 
					 #ifdef TRACE 		   
	                   //SHOULD_REMOVE
	                    UART_Transmit_Str("Send master's NACK\r");
	                    UART_Transmit_Str("Master in MASTER_I2C_FRAME_FSM_SENT_STOP_BIT state \r");	
			        #endif	
				}				
		   break;
		   case MASTER_I2C_FRAME_FSM_SENT_STOP_BIT:
			     I2C_Send_Stop();
		         Delay_Time_By_Count(REQ_TIME_CNT_AFTER_SEND_STOP_FLAG);
				 master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_PROC_RCVD_DATA;
				 
		        #ifdef TRACE 	   
	           //SHOULD_REMOVE
	               UART_Transmit_Str("Send Master Stop\r");
				   UART_Transmit_Str("Master in MASTER_I2C_FRAME_FSM_PROC_RCVD_DATA state \r");
                #endif
		   break;
		   case MASTER_I2C_FRAME_FSM_PROC_RCVD_DATA:
			    //RTC datas from RTC chip are in BCD format, conv RTC datas into binary format
                RTC_Datas_BCD_to_Binary_Conv(rtc_datas_from_rtc);               
			    master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_IDLE;			   
		   break;
		   default:
			    //error: invalid i2c frame fsm state
				;			 
	   }
}

 /*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
