/**************************************************************************
   FILE          :    io_conf.h
 
   PURPOSE       :   main peripherial configuration Header
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran 
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _IO_CONF_H
 #define _IO_CONF_H
 
 /* -------------------------------- OSC Freq conf -------------------------------------*/
 #define _XTAL_FREQ                             (20000000UL)
 
 /* ------------------------------- LCD oper conf ---------------------------------------*/
 

 
/* for 20 * 4 LCD disp */                             
#define BEGIN_LOC_LINE1                      (0X80)
#define BEGIN_LOC_LINE2                      (0xC0)
#define BEGIN_LOC_LINE3                      (0x94) 
#define BEGIN_LOC_LINE4                      (0xD4)
#define END_LOC_LINE1                        (0x93)
#define END_LOC_LINE2                        (0xD3)
#define END_LOC_LINE3                        (0xA7) 
#define END_LOC_LINE4                        (0xE7)

/* num cols = num of chars in a line */
#define MAX_AVAIL_NUM_COLS                    (20)
#define CONFIGURE_MAX_NUM_LINES               (4)
#define MAX_AVAIL_NUM_LINES                   (4) 
#define MAX_AVAIL_NUM_CHARS_IN_LCD        (MAX_AVAIL_NUM_COLS * MAX_AVAIL_NUM_LINES) 
#define CONFIGURE_MAX_NUM_COLS             (MAX_AVAIL_NUM_COLS)
#define CONFIGURE_MAX_NUM_CHARS_IN_LCD    (CONFIGURE_MAX_NUM_LINES * CONFIGURE_MAX_NUM_COLS ) 
#define MAX_NUM_CHARS_INPUT_DATA          (MAX_AVAIL_NUM_COLS) 

#define LCD_ENABLE_PULSE_WIDTH          (100UL)


/* -------------------------------- timer oper conf ------------------------------------*/

 //in Timer1_Load_Init_Val_Calc() in timer1.c, change variable inc_timer1, which (directly loads initial TMR1 values ), depends on Osc freq
 
/* ------------------------------- uart oper conf -------------------------------------- */

//in UART_Init() in uart.c, change SPBRG, which dependc on Osc freq  and baud rate

/* ----------------------------------- i2c oper conf -------------------------------------*/

//in I2C_Init(), change SSPADD for I2C master, which depends on Osc Freq and I2C clock  

#define I2C_CLK_IN_KHz                      (100ul)

//I2C Slave Address	- 0b0000 011,	R/W - dont care ,description -	reserved for future purposes for unused I2C Slave Address
#define I2C_SLAVE_ADDR                      (0x06) 

#define REQ_TIME_MASTER_WAIT_IN_MILLI_SEC                        (80ul)
#define REQ_TIME_MASTER_WAIT_AFTER_SEND_STOP_BIT_IN_MILLI_SEC   (200ul)
#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
