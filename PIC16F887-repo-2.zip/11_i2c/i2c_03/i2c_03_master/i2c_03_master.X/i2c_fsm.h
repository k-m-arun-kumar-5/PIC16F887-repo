/**************************************************************************
   FILE          :    i2c_fsm.h
 
   PURPOSE       :   I2C Frame FSM header 
 
   AUTHOR        :     K.M. Arun Kumar alias Arunkumar Murugeswaran 
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _I2C_FSM_H
#define _I2C_FSM_H

/* -------------------- macro  defination ---------------------------------------- */
#define REQ_TIME_CNT_BEFORE_SENT_STOP_BIT            (100UL)
#define REQ_TIME_CNT_TIME_WAIT                      (1000UL)
#define MAX_COMM_NUM_CHARS                            (20U)

#define DATA_TERMINATOR_CHAR                          ('\\')                 
#define NULL_CHAR                                     ('\0')
#define ENQ_CHAR                                    ('\x05')
#define PADDED_CHAR                                 ('\x80')

/* -------------------- data type defination ---------------------------------------- */

typedef enum {MASTER_I2C_FRAME_FSM_IDLE, MASTER_I2C_FRAME_FSM_WAIT_PASSIVE_OPEN, MASTER_I2C_FRAME_FSM_PASSIVE_OPEN, MASTER_I2C_FRAME_FSM_SENT_START_BIT, MASTER_I2C_FRAME_FSM_SENT_ADDR_WRITE,\
   MASTER_I2C_FRAME_FSM_DATA_SENT_INTR_CMD, MASTER_I2C_FRAME_FSM_SENT_DATA, MASTER_I2C_FRAME_FSM_SENT_ADDR_READ, MASTER_I2C_FRAME_FSM_RCV_DATA, MASTER_I2C_FRAME_FSM_SENT_RESTART_BIT,\
   MASTER_I2C_FRAME_FSM_SENT_STOP_BIT, MASTER_I2C_FRAME_FSM_PROC_RCVD_DATA, MASTER_I2C_FRAME_FSM_TIME_WAIT,  MASTER_I2C_FRAME_FSM_SENT_ADDR_READ1 } master_i2c_frame_fsm_states;

typedef enum { I2C_MASTER_TYPE, I2C_SLAVE_TYPE } i2c_device_types; 
  
typedef enum {I2C_NO_ERROR = 0,  I2C_ERROR} i2c_error_status_types;

/* -------------------- public variable  declaration---------------------------------------- */

extern char master_tx_valid_data_str[][MAX_COMM_NUM_CHARS + 1];
extern char master_rcvd_valid_data_str[MAX_COMM_NUM_CHARS + 1], i2c_master_rcvd_data_str[MAX_COMM_NUM_CHARS + 1], i2c_master_tx_data_str[MAX_COMM_NUM_CHARS + 1];
extern unsigned int master_i2c_num_data_chars_received, master_i2c_num_data_chars_transmitted,  master_i2c_valid_rcvd_num_data_chars, master_i2c_valid_tx_num_data_chars ;
extern char i2c_rcv_enable_flag , i2c_tx_enable_flag, is_rcvd_end_data_char_flag, is_tx_end_data_char_flag, is_rcvd_data_terminator_flag, is_tx_data_terminator_flag, is_master_i2c_ready ;
extern char lcd_const_disp_flag[5] ;
extern master_i2c_frame_fsm_states  master_cur_i2c_frame_fsm_state, master_prev_i2c_frame_fsm_state;
extern i2c_error_status_types i2c_error_status_type;
extern i2c_device_types i2c_device_type;
extern char is_master_rcvd_data_str_flag;

/* -------------------- public prototype declaration --------------------------------------- */
void I2C_Frame_Fsm_Proc(const i2c_device_types cur_i2c_device_type);
int Master_I2C_Rcvd_Data_Proc(unsigned char *master_rcvd_valid_data, unsigned int master_i2c_rcvd_valid_num_data_chars); 
void Reset_Transfer_Parameters();
void Append_Data_Terminator_Char(const char * const valid_data_str, char * const append_data_terminator_str);
void Master_I2C_Sent_Stop(const i2c_error_status_types cur_i2c_error_status_type);
void Master_Ready_To_Rcv();
#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
