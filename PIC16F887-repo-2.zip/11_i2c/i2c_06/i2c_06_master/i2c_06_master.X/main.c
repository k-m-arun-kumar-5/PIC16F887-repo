/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    :  There are 2 data str to be rcvd by I2C_MASTER. By using I2C, after valid I2C slave address for I2C_SLAVE and then valid command(ENQ char) are send by I2C_MASTER, 
then after receive I2C ACK bit in I2C_MASTER, then send a I2C restart bit and after sending I2C read oper for the I2C_SLAVE's address, then, start to rcv a data str in I2C_MASTER send by I2C_SLAVE,
and when DATA_TERMINATOR_CHAR is received by I2C_MASTER, then end data transfer of a data str by send I2C stop bit and then display rcvd data str in LCD_MASTER connected to I2C_MASTER.   
Repeat the process to rcv another data str.

  Transmission control(TC) and other communications related characters 
 =====================================================================
   '\\'          - in our case as user predefined valid data terminator. 
   '\0'  (NULL)  - NUL char in ascii, defined as a filler character. It can be used as media-fill or time-fill. In our case, data are NULL terminated after DATA_TERMINATOR_CHAR 
                as well as media-fill for unoccupied data and is used as user predefined fill char.
   '\x05' (ENQ) - enquiry in ascii or (TC5). is used by a master station to ask a slave station to send its next message.In our case, when slave has rcvd ENQ from master 
                 and if slave wants to transmits more message, then slave transmits I2C ACK bit. When ENQ is rcvd in slave and when slave has no transmit data to master, then slave transmits I2C NAK bit to master.                   
   '\x80' (PAD) - Padding Character in ascii used in our case as padded char. 
   '\x95' (MW) - Message Waiting in ascii, is used to Sets a message waiting indicator in the receiving device. 
                In our case, if master has some valid data to sent, then master device transmits MW and slave is ready to transmit data and then master is ready to sent data.  
 
                     									 	 
AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran 
	 
KNOWN BUGS            : 

NOTE                  : This is a I2C_MASTER code and error checking are not implemented 
						
CHANGE LOGS           : 

*****************************************************************************/

#include "main.h"
#include "port.h"
#include "io_conf.h"
#include "appl_conf.h" 
#include "i2c.h"
#include "i2c_fsm.h"
#include "uart.h"
#include "lcd.h"
#include "rcvd_data_proc.h"

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.
// 'C' source line config statements
#pragma config FOSC = XT    // Oscillator Selection bits (XT oscillator)
#pragma config WDTE = OFF   // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF  // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = OFF  // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = OFF    // Low-Voltage In-Circuit Serial Programming Enable bit
#pragma config CPD = OFF    // Data EEPROM Memory Code Protection bit
#pragma config WRT = OFF    // Flash Program Memory Write Enable bits
#pragma config CP = OFF     // Flash Program Memory Code Protection bit

char lcd_const_disp_flag[5] = {STATE_NO_IN_CHAR, STATE_NO_IN_CHAR, STATE_NO_IN_CHAR, STATE_NO_IN_CHAR, STATE_NO_IN_CHAR};
char master_tx_valid_data_str[][MAX_COMM_NUM_CHARS + 1] = {"MASTER"};
char master_rcvd_valid_data_str[MAX_COMM_NUM_CHARS + 1], i2c_master_rcvd_data_str[MAX_COMM_NUM_CHARS + 1], i2c_master_tx_data_str[MAX_COMM_NUM_CHARS + 1];
unsigned int i2c_num_chars_received = 0, i2c_num_chars_transmitted = 0, master_i2c_valid_rcvd_num_data_chars, master_i2c_valid_tx_num_data_chars;
char i2c_rcv_enable_flag = STATE_NO_IN_CHAR, i2c_tx_enable_flag = STATE_NO_IN_CHAR, is_rcvd_end_char_flag = STATE_NO_IN_CHAR, is_tx_end_char_flag = STATE_NO_IN_CHAR, \
   is_rcvd_data_terminator_flag = STATE_NO_IN_CHAR, is_tx_data_terminator_flag = STATE_NO_IN_CHAR, is_master_i2c_ready = STATE_NO_IN_CHAR; 
master_i2c_frame_fsm_states  master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_IDLE ;
i2c_error_status_types i2c_error_status_type = I2C_NO_ERROR;
i2c_device_types i2c_device_type;
unsigned int i2c_slave_addr; 
unsigned char slave_internal_command = ENQ_CHAR;
unsigned int master_rcv_str_index = 0;
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void main()
{
	 unsigned char master_i2c_rcvd_char, master_i2c_rcvd_ack_state, master_i2c_sent_char;   
	 char rcvd_status;	  
	 static char is_transfer_data_strs_over = STATE_NO_IN_CHAR;
	 static unsigned int master_send_str_index = 0;
     
   TRISE = 0x00;
   PORTE = 0x00;
   LCD_PORT_GPIO = 0x00;        
   LCD_PORT = 0x00;  
   ANSEL = 0x00;
   ANSELH = 0x00; 
   LCD_Init();
   UART_Init();
    
  /* // SHOULD_REMOVE 
   Data_Str_Disp_LCD("CLOCK");
   UART_Transmit_Str("RTC\r"); */
   
   i2c_device_type = I2C_MASTER_TYPE;
   master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_IDLE;
   while(1)
   {
       //I2C_Frame_Fsm_Proc(i2c_device_type);	
       switch(master_i2c_frame_fsm_state)
	   {
		   case MASTER_I2C_FRAME_FSM_IDLE:	
               if(is_transfer_data_strs_over == STATE_NO_IN_CHAR)
			   {
		          #ifdef TRACE  
			         UART_Transmit_Str("MASTER_I2C_FRAME_FSM_IDLE state \r");	
			       #endif 
			  
                   Reset_Transfer_Parameters();	
			       if(master_rcv_str_index  < 2)
			       {
			          master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_PASSIVE_OPEN;
			 
			         //SHOULD_REMOVE
			         #ifdef TRACE
			            UART_Transmit_Str("MASTER_I2C_FRAME_FSM_PASSIVE_OPEN state \r");	 
			         #endif
			      }
			      else
			      {
			 	     is_transfer_data_strs_over = STATE_YES_IN_CHAR;
			      }
			 }               
		   break;
		   case MASTER_I2C_FRAME_FSM_PASSIVE_OPEN:
		       I2C_Init(I2C_MASTER_OSC_DIV4, I2C_SLEW_RATE_CTRL_DIS, I2C_MASTER_GNL_CALL_DONT_CARE, I2C_SLAVE_ADDR );  
		       i2c_rcv_enable_flag = STATE_YES_IN_CHAR;
		       i2c_tx_enable_flag = STATE_YES_IN_CHAR; 
			   master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_SENT_START_BIT;
			   
			   //SHOULD_REMOVE
			   #ifdef TRACE 
			      UART_Transmit_Str("MASTER_I2C_FRAME_FSM_SENT_START_BIT state \r");	 
			   #endif			   			    			   
		   break; 
           case MASTER_I2C_FRAME_FSM_SENT_START_BIT:
		      I2C_Sent_Start(); 
			  while(is_master_i2c_ready == STATE_NO_IN_CHAR);
			  is_master_i2c_ready = STATE_NO_IN_CHAR; 
			   master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_SENT_ADDR_WRITE;
				
			  //SHOULD_REMOVE
			  #ifdef TRACE  
			     UART_Transmit_Str("MASTER_I2C_FRAME_FSM_SENT_ADDR_WRITE state \r");	
			  #endif
			   __delay_ms(REQ_TIME_MASTER_WAIT_IN_MILLI_SEC);
	       break;
		   case MASTER_I2C_FRAME_FSM_SENT_ADDR_WRITE:
		     //(send I2C SLAVE address with write condition) 			 
		      master_i2c_rcvd_ack_state = Master_I2C_Send_Byte(i2c_slave_addr & 0xFE); 
			  while(is_master_i2c_ready == STATE_NO_IN_CHAR);
			  is_master_i2c_ready = STATE_NO_IN_CHAR;
			  if(SSPCON2bits.ACKSTAT) 
				  master_i2c_rcvd_ack_state = STATE_NO_IN_INT;
              else if(!SSPCON2bits.ACKSTAT)			
				 master_i2c_rcvd_ack_state = STATE_YES_IN_INT;
			  		  
			  if(master_i2c_rcvd_ack_state != STATE_YES_IN_INT)
              {
				 #ifdef TRACE_ERROR
					UART_Transmit_Str("ERR: Send Slave Address with write ");\
					
				   //SHOULD_REMOVE
		             switch(master_i2c_rcvd_ack_state)
				     {
					    case STATE_INVALID_IN_INT:
					      UART_Transmit_Str("and rcvd INVALID\r"); 
					    break;
                        case STATE_NO_IN_INT:
                          UART_Transmit_Str("and rcvd NACK\r"); 
					    break;					   
					 }
				  #endif				  
									 
				  Master_I2C_Sent_Stop(I2C_ERROR);
		          break;
	          }
			 
			  __delay_ms(REQ_TIME_MASTER_WAIT_IN_MILLI_SEC);
			  master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_DATA_SENT_INTR_CMD;			  
			  
			  //SHOULD_REMOVE
			  #ifdef TRACE 
			     UART_Transmit_Str("Master sends I2C slave addr with write bit: ");	
                 UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, i2c_slave_addr & 0xFE );			  
			     UART_Transmit_Str("\rMASTER_I2C_FRAME_FSM_DATA_SENT_INTR_CMD state \r");	
			  #endif
			  
		   break;
           case MASTER_I2C_FRAME_FSM_DATA_SENT_INTR_CMD:
		      // (send I2C SLAVE's Internal command ) 			 
		      master_i2c_rcvd_ack_state = Master_I2C_Send_Byte(slave_internal_command);  
			  while(is_master_i2c_ready == STATE_NO_IN_CHAR);
			  is_master_i2c_ready = STATE_NO_IN_CHAR;
			  if(SSPCON2bits.ACKSTAT) 
				  master_i2c_rcvd_ack_state = STATE_NO_IN_INT;
              else if(!SSPCON2bits.ACKSTAT)			
				 master_i2c_rcvd_ack_state = STATE_YES_IN_INT;
			 
			  if(master_i2c_rcvd_ack_state != STATE_YES_IN_INT)
              {
				 
				 #ifdef TRACE_ERROR
				   //SHOULD_REMOVE
				     UART_Transmit_Str("ERR: Send internal command : ");
				     UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, slave_internal_command);
		             switch(master_i2c_rcvd_ack_state)
				     {
					    case STATE_INVALID_IN_INT:
					      UART_Transmit_Str(" and rcvd INVALID\r"); 
					    break;
                        case STATE_NO_IN_INT:
                          UART_Transmit_Str(" and rcvd NACK\r"); 
					    break;					   
					 }
				  #endif
				  				  
				   Master_I2C_Sent_Stop(I2C_ERROR);	
			       break; 
			   }
			   switch(slave_internal_command)
		       {
		        	case MW_CHAR:
			           Append_Data_Terminator_Char(master_tx_valid_data_str[master_send_str_index], i2c_master_tx_data_str);
                       master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_SENT_DATA;			  
			  
			           //SHOULD_REMOVE
			           #ifdef TRACE  
			             UART_Transmit_Str("MASTER_I2C_FRAME_FSM_SENT_DATA state \r");
                         UART_Transmit_Str("Valid master's data str : ");
			             UART_Transmit_Str(master_tx_valid_data_str[master_send_str_index]);
				         UART_Transmit_Char('\r');
				         UART_Transmit_Str("To send master's data str : ");
				         UART_Transmit_Str(i2c_master_tx_data_str);
				         UART_Transmit_Char('\r');				   
			           #endif	
			          
		            break;
					case ENQ_CHAR:
					     master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_SENT_RESTART_BIT;			  
			  
			           //SHOULD_REMOVE
			           #ifdef TRACE  
			             UART_Transmit_Str("MASTER_I2C_FRAME_FSM_SENT_RESTART_BIT state \r");                        				   
			           #endif
					 break; 
					 default:
					 	//error: invalid internal command sent
					   ;  	
		        }
		        __delay_ms(REQ_TIME_MASTER_WAIT_IN_MILLI_SEC);
		   break;     
		   case MASTER_I2C_FRAME_FSM_SENT_RESTART_BIT:	
             // MUST_CALL		   
		     I2C_Sent_Restart();	
             while(is_master_i2c_ready == STATE_NO_IN_CHAR);
			 is_master_i2c_ready = STATE_NO_IN_CHAR; 
			
			 __delay_ms(REQ_TIME_MASTER_WAIT_IN_MILLI_SEC);
			 master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_SENT_ADDR_READ;
			  
			 //SHOULD_REMOVE
			  #ifdef TRACE  
			     UART_Transmit_Str("MASTER_I2C_FRAME_FSM_SENT_ADDR_READ state \r");	
			  #endif 
		   break;
		   case MASTER_I2C_FRAME_FSM_SENT_ADDR_READ:
		     //(send I2C SLAVE address with read condition) 
		      master_i2c_rcvd_ack_state = Master_I2C_Send_Byte(i2c_slave_addr | 0x01);  
			  while(is_master_i2c_ready == STATE_NO_IN_CHAR);
			  is_master_i2c_ready = STATE_NO_IN_CHAR;
			  if(SSPCON2bits.ACKSTAT) 
				  master_i2c_rcvd_ack_state = STATE_NO_IN_CHAR;
              else if(!SSPCON2bits.ACKSTAT)			
				 master_i2c_rcvd_ack_state = STATE_YES_IN_CHAR;
			  if(master_i2c_rcvd_ack_state != STATE_YES_IN_CHAR)
              {  
				  #ifdef TRACE_ERROR
				   //SHOULD_REMOVE
				     UART_Transmit_Str("ERR: Send Slave Address with read ");
		             switch(master_i2c_rcvd_ack_state)
				     {
					    case STATE_INVALID_IN_CHAR:
					      UART_Transmit_Str("and rcvd INVALID\r"); 
					    break;
                        case STATE_NO_IN_CHAR:
                          UART_Transmit_Str("and rcvd NACK\r"); 
					    break;					   
					 }
				  #endif	
				  
				  Master_I2C_Sent_Stop(I2C_ERROR);	
		          break;
	          }
			  	  
			 //SHOULD_REMOVE
			 #ifdef TRACE
                UART_Transmit_Str("Master sends I2C slave addr with read bit : ");	
                UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, i2c_slave_addr | 0x01 );			 
			    UART_Transmit_Str("\rMASTER_I2C_FRAME_FSM_RCV_DATA state \r");	
				UART_Transmit_Str("Rcvd Master's data char \r");
				UART_Transmit_Str("========================\r");
			 #endif	
			    __delay_ms(REQ_TIME_MASTER_WAIT_IN_MILLI_SEC); 
			   master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_RCV_DATA;
			   
		  break;	   		   
		  case MASTER_I2C_FRAME_FSM_RCV_DATA:
		         Master_Ready_To_Rcv();  
		         while(is_master_i2c_ready == STATE_NO_IN_CHAR);
			     is_master_i2c_ready = STATE_NO_IN_CHAR;
			     master_i2c_rcvd_char  =  Master_I2C_Rcvd_Byte(); // rcv 
				 
				 #ifdef TRACE
				    //SHOULD_REMOVE	
				    UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, master_i2c_rcvd_char);
					UART_Transmit_Str(" : ");
					UART_Transmit_Char(master_i2c_rcvd_char);
                    UART_Transmit_Char('\r');					
				 #endif
				 
		         switch(master_i2c_rcvd_char)
		         {	
                      case DATA_TERMINATOR_CHAR:                          			  
						  is_rcvd_data_terminator_flag = STATE_YES_IN_CHAR;	
						  
	                      //SHOULD_REMOVE
						  #ifdef TRACE
					         UART_Transmit_Str("Rcvd Slave's data terminator\r");
					      #endif
						   master_rcvd_valid_data_str[master_i2c_valid_rcvd_num_data_chars] = NULL_CHAR;
						   Master_I2C_Send_NACK();
						   while(is_master_i2c_ready == STATE_NO_IN_CHAR);
			               is_master_i2c_ready = STATE_NO_IN_CHAR;
						   is_rcvd_end_char_flag = STATE_YES_IN_CHAR;    
						   ++i2c_num_chars_received;
						   Master_I2C_Sent_Stop(I2C_NO_ERROR);	
					  break;	   
					  case PADDED_CHAR: 
					  case NULL_CHAR:
					  
						   //SHOULD_REMOVE
						  #ifdef TRACE
					         UART_Transmit_Str("Rcvd Slave's PAD CHAR 0R NULL char \r");
					      #endif 
						    ++i2c_num_chars_received;
							Master_I2C_Send_ACK();
                            while(is_master_i2c_ready == STATE_NO_IN_CHAR);
			                is_master_i2c_ready = STATE_NO_IN_CHAR;							
                      break;
					  case INVALID_I2C_OPER_CHAR:
					       Master_I2C_Send_NACK();
					       while(is_master_i2c_ready == STATE_NO_IN_CHAR);
			               is_master_i2c_ready = STATE_NO_IN_CHAR;					     
						   Master_I2C_Sent_Stop(I2C_ERROR);
						   
						   #ifdef TRACE_ERROR 	   
		                    //SHOULD_REMOVE
		                      UART_Transmit_Str("ERR: invalid oper rcvd\r");
		                   #endif 
						   
					  break;	 
                      default:
                          	master_rcvd_valid_data_str[master_i2c_valid_rcvd_num_data_chars++] = master_i2c_rcvd_char;
							Master_I2C_Send_ACK();
							while(is_master_i2c_ready == STATE_NO_IN_CHAR);
			                is_master_i2c_ready = STATE_NO_IN_CHAR;	
					        ++i2c_num_chars_received;
							
					       #ifdef TRACE 	   
		                    //SHOULD_REMOVE
		                      UART_Transmit_Str("Send master's ACK\r");
		                   #endif
				 }
                  __delay_ms(REQ_TIME_MASTER_WAIT_IN_MILLI_SEC);
		   break;
		   case MASTER_I2C_FRAME_FSM_SENT_STOP_BIT:
		         I2C_Sent_Stop();
				 while(is_master_i2c_ready == STATE_NO_IN_CHAR);
			     is_master_i2c_ready = STATE_NO_IN_CHAR;				 
				 master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_TIME_WAIT;
				  
				 #ifdef TRACE 	   
	              //SHOULD_REMOVE
	                UART_Transmit_Str("Send master's stop bit \r");
					UART_Transmit_Str("MASTER_I2C_FRAME_FSM_TIME_WAIT state \r");
                 #endif
		   break;
		   case MASTER_I2C_FRAME_FSM_TIME_WAIT:
		       __delay_ms(REQ_TIME_MASTER_WAIT_AFTER_SEND_STOP_BIT_IN_MILLI_SEC);
			   // disable I2C interrupt
			   PIE1bits.SSPIE = 0; 
			  
			   // for master send str
			   //  master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_IDLE;
			   switch(i2c_error_status_type)
	           {
                   case I2C_NO_ERROR:
	        	      master_i2c_frame_fsm_state =  MASTER_I2C_FRAME_FSM_PROC_RCVD_DATA;
			          #ifdef TRACE 	   
	                    //SHOULD_REMOVE
	                    UART_Transmit_Str("MASTER_I2C_FRAME_FSM_PROC_RCVD_DATA state \r");
                      #endif
	               break;
                   case I2C_ERROR:
                   default:
				      is_transfer_data_strs_over = STATE_YES_IN_CHAR;
                      master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_IDLE;		   
		              #ifdef TRACE  
		                UART_Transmit_Str("ERR: MASTER_I2C_FRAME_FSM_IDLE state \r");
		              #endif
		   
               }
		   break;
           case MASTER_I2C_FRAME_FSM_PROC_RCVD_DATA:			    
                Master_I2C_Rcvd_Data_Proc(master_rcvd_valid_data_str, master_i2c_valid_rcvd_num_data_chars);				
				 ++master_rcv_str_index;
				 master_i2c_frame_fsm_state = MASTER_I2C_FRAME_FSM_IDLE;				
				
		   break; 		   
		   default:
			    //error: invalid i2c frame fsm state
				;			 
	    }
    }   
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
