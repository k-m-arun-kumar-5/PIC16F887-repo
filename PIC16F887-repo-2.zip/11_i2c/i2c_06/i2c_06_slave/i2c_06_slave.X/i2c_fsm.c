/* ********************************************************************
   FILE                   : i2c_fsm.c

   PROGRAM DESCRIPTION    : I2C frame fsm library 
                      									 
	 
   AUTHOR                : M.Arun Kumar
	 
   KNOWN BUGS            : 

   NOTE                  :  										
                                    
   CHANGE LOGS           : 

*****************************************************************************/
#include "main.h"
#include "port.h"
#include "io_conf.h"
#include "appl_conf.h"
#include "lcd.h"
#include "i2c.h"
#include "uart.h"
#include "i2c_fsm.h"
#include "rcvd_data_proc.h"
#include "string.h"

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void I2C_Frame_Fsm_Proc(const i2c_device_types cur_i2c_device_type)
{    
         
	   
	   
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void Slave_I2C_Rcv_Stop(const i2c_error_status_types cur_i2c_error_status_type)
{
	i2c_error_status_type = cur_i2c_error_status_type;	
	slave_i2c_frame_fsm_state = SLAVE_I2C_FRAME_FSM_RCV_STOP_BIT;
	
	//SHOULD_REMOVE
	#ifdef TRACE  
	    UART_Transmit_Str("SLAVE_I2C_FRAME_FSM_RCV_STOP_BIT state \r");	
	#endif	
	
    Slave_I2C_Ready();
	/* slave_i2c_rcvd_char  =  Slave_I2C_Rcvd_Byte(); // rcv remaining unrcv chars 				 
	   #ifdef TRACE
	       //SHOULD_REMOVE	
		     UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, slave_i2c_rcvd_char);
		     UART_Transmit_Str(" : ");
		     UART_Transmit_Char(slave_i2c_rcvd_char);
             UART_Transmit_Char('\r');					
	   #endif */
	   
    I2C_Rcvd_Stop();
			  
    #ifdef TRACE 	   
     //SHOULD_REMOVE
       UART_Transmit_Str("Rcvd Master's I2C Stop\r");				  
    #endif
			  
    switch(i2c_error_status_type)
	{
        case I2C_NO_ERROR:
		// for slave send data str
		  ++slave_send_str_index;
	      slave_i2c_frame_fsm_state = SLAVE_I2C_FRAME_FSM_IDLE;
	      #ifdef TRACE  
		       UART_Transmit_Str("SLAVE_I2C_FRAME_FSM_IDLE state \r");
		  #endif	

         //for slave rcvd data str
		/* slave_i2c_frame_fsm_state = SLAVE_I2C_FRAME_FSM_PROC_RCVD_DATA;
	      #ifdef TRACE  
		       UART_Transmit_Str("SLAVE_I2C_FRAME_FSM_PROC_RCVD_DATA state \r");
		  #endif */
		  
	    break;
        case I2C_ERROR:
        default:
           slave_i2c_frame_fsm_state = SLAVE_I2C_FRAME_FSM_IDLE;
		   
		   #ifdef TRACE  
		       UART_Transmit_Str("ERR: SLAVE_I2C_FRAME_FSM_IDLE state \r");
		  #endif
		   
    }
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void Slave_I2C_Ready()
{
	 #ifdef TRACE  
	     UART_Transmit_Str("I2C slave ready \r");	
	 #endif
	 
	is_slave_i2c_send_or_rcvd_char_flag = STATE_NO_IN_CHAR;
	SSPCONbits.CKP = 1; //Enable i2c clock
	
	 
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
 void Reset_Transfer_Parameters()
{
	SSPCONbits.SSPEN = 0; // Disables serial port and configures these pins as I/O port pins
	i2c_error_status_type = I2C_NO_ERROR;
	i2c_num_chars_received = 0;
	slave_i2c_valid_rcvd_num_data_chars = 0;
	memset(i2c_slave_rcvd_data_str, NULL_CHAR, MAX_COMM_NUM_CHARS);
	is_rcvd_end_char_flag = STATE_NO_IN_CHAR;
	is_rcvd_data_terminator_flag = STATE_NO_IN_CHAR;
	
	is_tx_data_terminator_flag = STATE_NO_IN_CHAR; 
	i2c_num_chars_transmitted = 0;
	slave_i2c_valid_tx_num_data_chars = 0;
	memset(i2c_slave_tx_data_str, NULL_CHAR, MAX_COMM_NUM_CHARS);	
	is_tx_end_char_flag = STATE_NO_IN_CHAR;
} 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void Append_Data_Terminator_Char(const char * const valid_data_str, char * const append_data_terminator_str)
{
	unsigned int valid_data_str_len;
	
	memset(append_data_terminator_str, NULL_CHAR, MAX_COMM_NUM_CHARS);
	valid_data_str_len = strlen(valid_data_str);	
	strncpy(append_data_terminator_str,valid_data_str, valid_data_str_len );
	append_data_terminator_str[valid_data_str_len] = DATA_TERMINATOR_CHAR;
	//append_data_terminator_str[valid_data_str_len + 1] = NULL_CHAR;
	
	//SHOULD_REMOVE
	/* #ifdef TRACE
	   UART_Transmit_Str("Data terminated str: ");
	   UART_Transmit_Str(append_data_terminator_str);
	   UART_Transmit_Char('\r');
	#endif */
	
} 

 /*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
