/**************************************************************************
   FILE          :    isr.c
 
   PURPOSE       :   Interrupt Service Routine Library
 
   AUTHOR        :    M. Arun Kumar
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #include "main.h"
 #include "port.h"
 #include "io_conf.h"
 #include "uart.h" 
 #include "i2c_fsm.h"
 #include "intp_event_handle.h"
 
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void interrupt Interrupt_ISR() 
{
	if(SSPIF == 1)
	{
		 SSPCONbits.CKP = 0; //Holds i2c clock low (clock stretching or disable I2C clock). (Used to ensure data setup time.)
		 is_slave_i2c_send_or_rcvd_char_flag = STATE_YES_IN_CHAR;
		 SSPIF = 0;
		 #ifdef TRACE  
	        UART_Transmit_Str("I2C slave rcvd or tx char as SSPIF = 1 \r");	
	     #endif 
	}
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/