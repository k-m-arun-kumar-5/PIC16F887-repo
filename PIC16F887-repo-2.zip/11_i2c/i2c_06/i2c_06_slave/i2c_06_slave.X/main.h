/**************************************************************************
   FILE          :    main.h
 
   PURPOSE       :    project header.  
 
   AUTHOR        :    M. Arun Kumar
 
  KNOWN BUGS     :
	
  NOTE           :   PROJECT header- groups the key information about the 8051 device you have used, along with other key
parameters � such as the oscillator frequency and commonly used information such as common data types in the project
	
  CHANGE LOGS     :
	   
 **************************************************************************/
 
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _MAIN_H
#define _MAIN_H

/* Must include the appropriate microcontroller header file here eg for eg we use 8051/8052 uC device.
 In most case, microcontroller header is also a device header.in our case, reg52.h
 device header will include the addresses of the special function registers (SFRs) used for port access, plus similar
 details for other on-chip components such as analog-to-digital converters*/
 /* reg52.h is a system header and for <> enclosed one, preprocessor will search the reg52.h in predetermined directory path to locate the header file. */
 // Must include the appropriate microcontroller header file here
//#define HI_TECH_COMPILER
#ifdef HI_TECH_COMPILER
  #include <pic.h>
  __CONFIG(0x2CE4);
#else // XC8 compiler
  #include <xc.h>
#endif

#define LED_OFF                                  (0)
#define LED_ON                                   (1) 
 
#define KEY_PRESSED                              (1) 
#define KEY_NOT_PRESSED                          (0)

#define STATE_YES_IN_CHAR                       ('y')
#define STATE_NO_IN_CHAR                        ('n')
#define STATE_INVALID_IN_CHAR                   ('X')
#define STATE_VALID_IN_CHAR                     ('V')

#define STATE_YES_IN_INT                          (0U) 
#define STATE_NO_IN_INT                           (1U)
#define STATE_UNKNOWN_IN_INT                      (2U)
#define STATE_INVALID_IN_INT                      (3U)
#define STATE_VALID_IN_INT                        (4U)

#define DISP_FLAG_NUM_DIGIT1                   (1U)
#define DISP_FLAG_NUM_DIGIT2                   (2U)
#define DISP_FLAG_NUM_DIGIT3                   (3U)
#define DISP_FLAG_NUM_DIGIT4                   (4U)
#define DISP_FLAG_NUM_DIGIT5                   (5U)
#define DISP_FLAG_HEX_DIGIT1                   (6U)
#define DISP_FLAG_HEX_DIGIT2                   (7U)
#define DISP_FLAG_HEX_DIGIT3                   (8U)
#define DISP_FLAG_HEX_DIGIT4                   (9U)

#define SUCCESS                                   (0U)
#define FAILURE                                   (1U) 
   
#define NULL_CHAR                               ('\0')

#define OSC_PER_INST                            (4)
// Number of oscillations required to execute per instruction or increment a timer 
// 4 � Original PIC 16f887


typedef unsigned char tByte;
typedef unsigned int tWord;
typedef unsigned long tLong;


#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/