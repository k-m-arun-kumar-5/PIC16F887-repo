/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : There are 2 data str to be rcvd by I2C_SLAVE. By using I2C, then valid command(MW char) are send by I2C_MASTER, then after receive I2C ACK bit in I2C_MASTER, 
then  start to send a data str from I2C_MASTER to I2C_SLAVE, and when DATA_TERMINATOR_CHAR is send by I2C_MASTER, and rcvd by I2C_SLAVE, then I2C_SLAVE waits for stop bit, 
and when I2C_SLAVE rcvd for stop bit, to end data transfer for a data str, then display rcvd data str in LCD_SLAVE connected to I2C_SLAVE.
Repeat process for another data str to be rcvd by I2C_SLAVE.   


  Transmission control(TC) and other communications related characters 
 =====================================================================
   '\\'          - in our case as user predefined valid data terminator. 
   '\0'  (NULL)  - NUL char in ascii, defined as a filler character. It can be used as media-fill or time-fill. In our case, data are NULL terminated after DATA_TERMINATOR_CHAR 
                as well as media-fill for unoccupied data and is used as user predefined fill char.
   '\x05' (ENQ) - enquiry in ascii or (TC5). is used by a master station to ask a slave station to send its next message.In our case, when slave has rcvd ENQ from master 
                 and if slave wants to transmits more message, then slave transmits I2C ACK bit. When ENQ is rcvd in slave and when slave has no transmit data to master, then slave transmits I2C NAK bit to master.                   
   '\x80' (PAD) - Padding Character in ascii used in our case as padded char. 
   '\x95' (MW) - Message Waiting in ascii, is used to Sets a message waiting indicator in the receiving device. 
                In our case, if master has some valid data to sent, then master device transmits MW and slave is ready to transmit data and then master is ready to sent data.  
 
                     									 	 
AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran 
	 
KNOWN BUGS            :  In I2C, by use write operation in I2C, implementation not working 

NOTE                  :   This is a I2C_SLAVE code and error checking are not implemented
						
CHANGE LOGS           : 

*****************************************************************************/
   
#include "main.h"
#include "port.h"
#include "io_conf.h"
#include "appl_conf.h"
#include "lcd.h"
#include "i2c.h"
#include "uart.h"
#include "i2c_fsm.h"
#include "rcvd_data_proc.h"
#include "string.h"

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.
// 'C' source line config statements
#pragma config FOSC = XT    // Oscillator Selection bits (XT oscillator)
#pragma config WDTE = OFF   // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF  // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = OFF  // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = OFF    // Low-Voltage In-Circuit Serial Programming Enable bit
#pragma config CPD = OFF    // Data EEPROM Memory Code Protection bit
#pragma config WRT = OFF    // Flash Program Memory Write Enable bits
#pragma config CP = OFF     // Flash Program Memory Code Protection bit

char lcd_const_disp_flag[5] = {STATE_NO_IN_CHAR, STATE_NO_IN_CHAR, STATE_NO_IN_CHAR, STATE_NO_IN_CHAR, STATE_NO_IN_CHAR};
char slave_tx_valid_data_str[][MAX_COMM_NUM_CHARS + 1] = {"FROM SLAVE", "SLAVE"};
char slave_rcvd_valid_data_str[MAX_COMM_NUM_CHARS + 1], i2c_slave_rcvd_data_str[MAX_COMM_NUM_CHARS + 1], i2c_slave_tx_data_str[MAX_COMM_NUM_CHARS + 1];
unsigned int slave_i2c_num_data_chars_received = 0, slave_i2c_num_data_chars_transmitted = 0, slave_i2c_valid_rcvd_num_data_chars = 0, slave_i2c_valid_tx_num_data_chars = 0;
char i2c_rcv_enable_flag = STATE_NO_IN_CHAR, i2c_tx_enable_flag = STATE_NO_IN_CHAR, is_rcvd_end_char_flag = STATE_NO_IN_CHAR, is_tx_end_char_flag = STATE_NO_IN_CHAR, \
          is_rcvd_data_terminator_flag = STATE_NO_IN_CHAR, is_tx_data_terminator_flag = STATE_NO_IN_CHAR, is_slave_i2c_send_or_rcvd_char_flag = STATE_NO_IN_CHAR; 
slave_i2c_frame_fsm_states  slave_i2c_frame_fsm_state = SLAVE_I2C_FRAME_FSM_IDLE ;
i2c_device_types i2c_device_type;
unsigned int i2c_slave_addr = I2C_SLAVE_ADDR;
i2c_error_status_types i2c_error_status_type = I2C_NO_ERROR;
unsigned int slave_send_data_str_index = 0, slave_rcv_data_str_index = 0;
char is_slave_rcvd_data_str_flag = STATE_INVALID_IN_CHAR;
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void main()
{
   unsigned char slave_i2c_rcvd_char, rcvd_status, slave_i2c_sent_char;
   unsigned int slave_i2c_rcvd_ack_state;
   static char is_error_or_transfer_data_strs_over_flag = STATE_NO_IN_CHAR;
   
   TRISE = 0x00;
   PORTE = 0x00;
   LCD_PORT_GPIO = 0x00;        
   LCD_PORT = 0x00;  
   ANSEL = 0x00;
   ANSELH = 0x00; 
   LCD_Init();
   UART_Init();
    
  
  /* // SHOULD_REMOVE 
   Data_Str_Disp_LCD("CLOCK");
   UART_Transmit_Str("RTC\r"); */
   
   i2c_device_type = I2C_SLAVE_TYPE;
   while(1)
   {
      // I2C_Frame_Fsm_Proc(i2c_device_type);	
       switch(slave_i2c_frame_fsm_state)
	   {
		   case SLAVE_I2C_FRAME_FSM_IDLE:
               if(is_error_or_transfer_data_strs_over_flag == STATE_NO_IN_CHAR)
			   {
		          #ifdef TRACE  
			         UART_Transmit_Str("SLAVE_I2C_FRAME_FSM_IDLE state \r");	
			       #endif 
			  
                   Reset_Transfer_Parameters();	
				   if(slave_rcv_data_str_index  < 2)
			       {
			          slave_i2c_frame_fsm_state = SLAVE_I2C_FRAME_FSM_PASSIVE_OPEN;
			 
			         //SHOULD_REMOVE
			         #ifdef TRACE
			            UART_Transmit_Str("SLAVE_I2C_FRAME_FSM_PASSIVE_OPEN state \r");	 
			         #endif
				   }
				   else
				   {
					   is_error_or_transfer_data_strs_over_flag = STATE_YES_IN_CHAR;
				   }
			    }
		   break;
		   case SLAVE_I2C_FRAME_FSM_PASSIVE_OPEN:
		       I2C_Init(I2C_POLLING_SERVICE, I2C_SLAVE_7BIT_ADDR, I2C_SLEW_RATE_CTRL_DIS, I2C_SLAVE_GNL_CALL_DIS, I2C_SLAVE_ADDR);
		       i2c_rcv_enable_flag = STATE_YES_IN_CHAR;
		       i2c_tx_enable_flag = STATE_YES_IN_CHAR; 
			   slave_i2c_frame_fsm_state = SLAVE_I2C_FRAME_FSM_RCV_START_BIT;
			   
			   //SHOULD_REMOVE
			   #ifdef TRACE 
			      UART_Transmit_Str("SLAVE_I2C_FRAME_FSM_RCV_START_BIT state \r");	 
			   #endif			   			    			   
		   break; 
           case SLAVE_I2C_FRAME_FSM_RCV_START_BIT:
		       Slave_I2C_Ready(); 
		       I2C_Rcvd_Start(); 
			   slave_i2c_frame_fsm_state = SLAVE_I2C_FRAME_FSM_RCV_ADDR_WRITE;
				
			  //SHOULD_REMOVE
			  #ifdef TRACE  
			     UART_Transmit_Str("SLAVE_I2C_FRAME_FSM_RCV_ADDR_WRITE state \r");	
			  #endif
	       break;		 
           case SLAVE_I2C_FRAME_FSM_RCV_ADDR_WRITE:
		      switch(i2c_cur_service_type)
			  {
				  case I2C_INTP_SERVICE:
		             while(is_slave_i2c_send_or_rcvd_char_flag == STATE_NO_IN_CHAR);
					 is_slave_i2c_send_or_rcvd_char_flag = STATE_NO_IN_CHAR;
				  break;
			  }				  
		      slave_i2c_rcvd_char = Slave_I2C_Rcvd_Byte();
              if(slave_i2c_rcvd_char !=  i2c_slave_addr & 0xFE)  			  
              {
		          //SHOULD_REMOVE
				  #ifdef TRACE_ERROR
	                  UART_Transmit_Str("ERR: Rcvd ADDR not match I2C Slave Address with write \r");
                  #endif 			  
				
                  Slave_I2C_Rcv_Stop(I2C_ERROR);                             
			      break;
	          }
			  rcvd_status = I2C_Addr_Info();
			  if(rcvd_status == STATE_NO_IN_CHAR)			  
			  {
	              //SHOULD_REMOVE
	              UART_Transmit_Str("ERR: I2C Address info not rcvd in write \r"); 
		          
				  Slave_I2C_Rcv_Stop(I2C_ERROR);				  
			      break; 
			  }
			  rcvd_status =I2C_Slave_Write_Info();
			  if(rcvd_status == STATE_NO_IN_CHAR)
			  {
				  //SHOULD_REMOVE
	              UART_Transmit_Str("ERR: Write info not match in address write\r"); 
		          
				  Slave_I2C_Rcv_Stop(I2C_ERROR);				  
			      break;  
			  }			  
			   slave_i2c_frame_fsm_state = SLAVE_I2C_FRAME_FSM_DATA_RCV_INTR_CMD;			  
			  
			  //SHOULD_REMOVE
			  #ifdef TRACE  
			     UART_Transmit_Str("SLAVE_I2C_FRAME_FSM_DATA_RCV_INTR_CMD state \r");	
			  #endif		  
			 			  
		break;
        case SLAVE_I2C_FRAME_FSM_DATA_RCV_INTR_CMD:
		       switch(i2c_cur_service_type)
			   {
				  case I2C_INTP_SERVICE:
				     Slave_I2C_Ready();   
		             while(is_slave_i2c_send_or_rcvd_char_flag == STATE_NO_IN_CHAR);
					 is_slave_i2c_send_or_rcvd_char_flag = STATE_NO_IN_CHAR;
				  break;
			   }		
			   slave_i2c_rcvd_char = Slave_I2C_Rcvd_Byte();
				   
			   switch(slave_i2c_rcvd_char)
			   {
				   case ENQ_CHAR:				     
				       slave_i2c_frame_fsm_state = SLAVE_I2C_FRAME_FSM_RCV_RESTART_BIT ;
					 
					  //SHOULD_REMOVE
			          #ifdef TRACE  
			             UART_Transmit_Str("SLAVE_I2C_FRAME_FSM_RCV_RESTART_BIT state \r");	
			          #endif
				   break;
				   case MW_CHAR:
				       slave_i2c_frame_fsm_state = SLAVE_I2C_FRAME_FSM_RCV_DATA ;
					 
					  //SHOULD_REMOVE
			          #ifdef TRACE  
			             UART_Transmit_Str("SLAVE_I2C_FRAME_FSM_RCV_DATA state \r");	
			          #endif
				    
				   break;
                   default:
                    
                     //SHOULD_REMOVE
					 #ifdef TRACE_ERROR
                       UART_Transmit_Str("ERR: Rcvd invalid cmd \r"); 
		             #endif
					 
				       Slave_I2C_Rcv_Stop(I2C_ERROR);			      	   		
			   } 	
		  	            	   
		   break; 
		   case SLAVE_I2C_FRAME_FSM_RCV_DATA:
		       switch(i2c_cur_service_type)
			   {
				  case I2C_INTP_SERVICE:
				     Slave_I2C_Ready();
		             while(is_slave_i2c_send_or_rcvd_char_flag == STATE_NO_IN_CHAR);
					 is_slave_i2c_send_or_rcvd_char_flag = STATE_NO_IN_CHAR;
				  break;
			   }	
			   slave_i2c_rcvd_char = Slave_I2C_Rcvd_Byte(); // rcv 
				 
				 #ifdef TRACE
				    //SHOULD_REMOVE	
				    UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, slave_i2c_rcvd_char);
					UART_Transmit_Str(" : ");
					UART_Transmit_Char(slave_i2c_rcvd_char);
                    UART_Transmit_Char('\r');					
				 #endif
				 
		         switch(slave_i2c_rcvd_char)
		         {	
                      case DATA_TERMINATOR_CHAR:	
                          is_rcvd_data_terminator_flag = STATE_YES_IN_CHAR;	
						  					  
	                      //SHOULD_REMOVE
						  #ifdef TRACE
					         UART_Transmit_Str("Rcvd master's data terminator\r");
					      #endif
						  is_rcvd_end_char_flag = STATE_YES_IN_CHAR;    
						  ++slave_i2c_num_data_chars_received;
						  slave_rcvd_valid_data_str[slave_i2c_valid_rcvd_num_data_chars] = NULL_CHAR;
					      Slave_I2C_Rcv_Stop(I2C_NO_ERROR);						  						 
						  
					  case PADDED_CHAR: 
                      case NULL_CHAR:
					      #ifdef TRACE
					         UART_Transmit_Str("Rcvd master's padded or null char \r");
					      #endif 
						  ++slave_i2c_num_data_chars_received;
                      break;
					  case INVALID_I2C_OPER_CHAR:
					     Slave_I2C_Rcv_Stop(I2C_ERROR);
					  break; 
                      default:
                         slave_rcvd_valid_data_str[slave_i2c_valid_rcvd_num_data_chars++] = slave_i2c_rcvd_char;
						 ++slave_i2c_num_data_chars_received;									       
				 }                
		   break;
		   case SLAVE_I2C_FRAME_FSM_PROC_RCVD_DATA:			    
                Slave_I2C_Rcvd_Data_Proc(slave_rcvd_valid_data_str, slave_i2c_valid_rcvd_num_data_chars);				
				slave_i2c_frame_fsm_state = SLAVE_I2C_FRAME_FSM_IDLE;
		   break;
		   case SLAVE_I2C_FRAME_FSM_RCVD_STOP_BIT:		    
		     switch(i2c_cur_service_type)
			 {
				  case I2C_INTP_SERVICE:
				    //disable I2C interrupt
		             PIE1bits.SSPIE = 0;
				  break;
			 }	
			 i2c_cur_service_type = I2C_INVALID_SERVICE;
		     switch(i2c_error_status_type)
	         {
				  case I2C_NO_ERROR:
				     switch(is_slave_rcvd_data_str_flag)
					 {
						 case STATE_YES_IN_CHAR:
						     slave_i2c_frame_fsm_state = SLAVE_I2C_FRAME_FSM_PROC_RCVD_DATA;
	                         #ifdef TRACE  
		                        UART_Transmit_Str("SLAVE_I2C_FRAME_FSM_PROC_RCVD_DATA state \r");
		                     #endif 
						 break;
                         default:
                             slave_i2c_frame_fsm_state = SLAVE_I2C_FRAME_FSM_IDLE;
					
				             #ifdef TRACE  
		                         UART_Transmit_Str("SLAVE_I2C_FRAME_FSM_IDLE state \r");
		                     #endif							 
					 }
				  break;
				  case I2C_ERROR:
                  default:
				     is_error_or_transfer_data_strs_over_flag = STATE_YES_IN_CHAR;
                     slave_i2c_frame_fsm_state = SLAVE_I2C_FRAME_FSM_IDLE;
		   
		             #ifdef TRACE  
		                UART_Transmit_Str("ERR: SLAVE_I2C_FRAME_FSM_IDLE state \r");
		             #endif
             }				
		  break;
		  default:
			    //error: invalid i2c frame fsm state
				;			 
	   } 				   
   }   
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
