/**************************************************************************
   FILE          :    i2c.c
 
   PURPOSE       :   I2C Library
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran 
 
  KNOWN BUGS     :    In I2C, by use write operation in I2C, implementation not working 
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
#include "main.h" 
#include "port.h"
#include "io_conf.h"
#include "appl_conf.h"
#include "i2c.h"
#include "lcd.h"
#include "uart.h"

 i2c_service_types i2c_cur_service_type = I2C_INVALID_SERVICE;
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
unsigned int Slave_I2C_Send_Byte(const unsigned int to_send_byte)
{
	unsigned char temp;
	
	if(SSPCONbits.WCOL == 1)
	{
		/* If the user writes the SSPBUF when a transmit is already in progress (i.e., SSPSR is still shifting out a data byte),
		the WCOL is set and the contents of the buffer are unchanged (the write doesn’t occur). WCOL must be cleared in software. */
		
		//SHOULD_REMOVE
		#ifdef TRACE_ERROR
		  Goto_XY_LCD_Disp(LCD_DISP_ERR_LINE_NUM,4);
		  Data_Str_Disp_LCD("EW ");
	      UART_Transmit_Str("ERR: WCOL in Send\r");
		#endif
		
		while(SSPSTATbits.BF == 1)
		{
			//wait till I2c has been completed in sending previous send byte
			//SHOULD_REMOVE
		    #ifdef TRACE_ERROR
		        UART_Transmit_Str("ERR: attempt to send char while sending previous char\r");
		    #endif
		} 
		SSPCONbits.WCOL = 0;
		SSPIF = 0;
	}
	
	if(SSPCONbits.WCOL == 1)
	{
		/* If the user writes the SSPBUF when a receive is already in progress (i.e., SSPSR is still shifting in a data
           byte), the WCOL bit is set and the contents of the buffer are unchanged (the write doesn’t occur).  */
		   
		//SHOULD_REMOVE
		#ifdef TRACE_ERROR
		   Goto_XY_LCD_Disp(LCD_DISP_ERR_LINE_NUM,4);
		   Data_Str_Disp_LCD("EX ");
		   UART_Transmit_Str("ERR: WCOL in Wait to Send\r");
		#endif
		
		while(SSPSTATbits.BF == 0)
		{
			
		   //SHOULD_REMOVE
		   #ifdef TRACE_ERROR
		       UART_Transmit_Str("ERR: attempt to send char while receiving char\r");
		   #endif
		   
		}
		temp = SSPBUF;  // Read the previous value to clear the SSPBUF 
		SSPIF = 0;
		//SHOULD_REMOVE
		#ifdef TRACE_ERROR
		    UART_Transmit_Str("attempt to send char and Rcvd previous char : ");
			UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, temp);
			UART_Transmit_Char('\r');
		#endif
		 
		SSPCONbits.WCOL = 0;
	}
	if(SSPCONbits.WCOL == 0)
	{	
        switch(i2c_cur_service_type)
		{
		    case I2C_INTP_SERVICE:
               SSPBUF = to_send_byte;
			break;
			case I2C_POLLING_SERVICE:
			   SSPBUF = to_send_byte;
			   Slave_I2C_Ready();		         			
		       while(SSPIF == 0)
		       {
		          	//wait till I2C transmitter has completed sending data byte and received ack seq 
		         	//SHOULD_REMOVE
		            /* #ifdef TRACE_ERROR
		                UART_Transmit_Str("ERR: Slave sending char \r");
		            #endif */
		        }
		       //Holds I2C clock low (I2C clock stretching). (Used to ensure data setup time.) 
	           SSPCONbits.CKP = 0; 
		       SSPIF = 0;
			   
		       #ifdef TRACE
	           //SHOULD_REMOVE
	              UART_Transmit_Str("In slave enables clock stretched\r");
               #endif
			 break;  
		}
		return STATE_VALID_IN_INT;
	}
	return STATE_INVALID_IN_INT;
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/

// Function Purpose: Slave_I2C_Rcvd_Byte reads one byte
unsigned char Slave_I2C_Rcvd_Byte(void)
{
	unsigned char rcvd_byte, temp;
	
	if(SSPCONbits.SSPOV == 1) 
	{
		 SSPIF = 0;
		 /* In receive operation, the SSPOV bit is set when eight bits are received into the SSPSR 
		 and the BF bit is already set from a previous reception */
		 
		//SHOULD_REMOVE
		#ifdef TRACE_ERROR
		   Goto_XY_LCD_Disp(LCD_DISP_ERR_LINE_NUM,7);
		   Data_Str_Disp_LCD("ES ");
		   UART_Transmit_Str("ERR: SSPOV in receive\r");
		#endif	
		
		temp = SSPBUF; // Read the previous value to clear the SSPBUF	
		
        //SHOULD_REMOVE
		 #ifdef TRACE_ERROR
		    UART_Transmit_Str("ERR: attempt to rcv char and Rcvd previous char : ");
		    UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, temp);
			UART_Transmit_Char('\r');
		 #endif 
		 
         SSPCONbits.SSPOV = 0;		 
	}
	if(SSPCONbits.WCOL == 1)
	{
		/* If the user writes the SSPBUF when a receive is already in progress (i.e., SSPSR is still shifting in a data
           byte), the WCOL bit is set and the contents of the buffer are unchanged (the write doesn’t occur).  */
		   
		//SHOULD_REMOVE
		#ifdef TRACE_ERROR
	    	Goto_XY_LCD_Disp(LCD_DISP_ERR_LINE_NUM,10);
	    	Data_Str_Disp_LCD("ER ");
	    	UART_Transmit_Str("ERR: WCOL in receive\r");
		#endif
		while(SSPSTATbits.BF == 0)
	    {
		   // receive in progress 
		   //SHOULD_REMOVE
		   #ifdef TRACE_ERROR
		       UART_Transmit_Str("ERR: attempt to rcv char and previous char Receiving \r");
			#endif   
	    } 
		temp = SSPBUF;	// Read the previous value to clear the SSPBUF
		SSPIF = 0;
		//SHOULD_REMOVE
		 #ifdef TRACE_ERROR
		    UART_Transmit_Str("ERR: attempt to rcv char and Rcvd previous char : ");
		    UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, temp);
			UART_Transmit_Char('\r');
		 #endif 
		 
		SSPCONbits.WCOL = 0;
	}
	if(SSPCONbits.WCOL == 0 && SSPCONbits.SSPOV == 0)
	{	
        switch(i2c_cur_service_type)
		{
		    case I2C_INTP_SERVICE:
               rcvd_byte = SSPBUF;		 //  received byte
	           SSPIF = 0;
            break;
			case I2C_POLLING_SERVICE:
                Slave_I2C_Ready();		 
	            while(SSPIF == 0)
	            {
		           // receive in progress 
		          /* //SHOULD_REMOVE
		        	#ifdef TRACE_ERROR
		               UART_Transmit_Str("ERR: Char Receiving \r");
			        #endif */
	             } 
		         //Holds I2C clock low (I2C clock stretching). (Used to ensure data setup time.) 
		         SSPCONbits.CKP = 0;
				 rcvd_byte = SSPBUF;		        //  received byte
	             SSPIF = 0;	 			
			break;
		}			
		
        #ifdef TRACE
		  //SHOULD_REMOVE
		  UART_Transmit_Str("slave rcvd char : ");
          UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2,rcvd_byte);
		  UART_Transmit_Char('\r');		  
        #endif 
		
		return rcvd_byte; 
	}
	
	//SHOULD_REMOVE
	#ifdef TRACE_ERROR
    	Goto_XY_LCD_Disp(LCD_DISP_ERR_LINE_NUM,7);
	    Data_Str_Disp_LCD("EZ ");
	    UART_Transmit_Str("ERR: WCOL or SSPOV in receive\r"); 
	#endif
	
	return INVALID_I2C_OPER_CHAR;
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void Slave_I2C_Ready()
{
	 #ifdef TRACE  
	     UART_Transmit_Str("I2C slave ready \r");	
	 #endif	 
	
	SSPCONbits.CKP = 1; //Enable I2C clock means slave has released I2C clock	
}
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void I2C_Init(const i2c_service_types set_i2c_service_type, const I2c_types I2C_type, const I2c_slew_rate_ctrl_types I2C_slew_rate_ctrl_type,  const I2c_gnl_call_types I2C_gnl_call_type, const unsigned int to_tx_i2c_slave_addr )
{ 
   
    i2c_cur_service_type = set_i2c_service_type;
	switch(i2c_cur_service_type)
	{
		case I2C_INTP_SERVICE:
	       /* ENABLE IC2 interrupt */
		   SSPIF = 0;
           PIE1bits.SSPIE = 1;
           INTCONbits.PEIE = 1;
           INTCONbits.GIE = 1;
		break;
        case I2C_POLLING_SERVICE:
           PIE1bits.SSPIE = 0;
        break;
        default:
		  #ifdef TRACE_ERROR
		       UART_Transmit_Str("ERR: Invalid I2C service \r");
		  #endif
	}		
	
	SSPSTAT = I2C_slew_rate_ctrl_type;
	SSPCON = I2C_type;
	SSPCON2 = I2C_gnl_call_type;	
    if(I2C_type & 0b00000100) 
    {
		//If Slave Mode		
       SSPCON2 = I2C_gnl_call_type; 
       SSPADD = to_tx_i2c_slave_addr; // i2c slave address	       	   
    }
    else              
    {
		//If Master Mode
        i2c_slave_addr = to_tx_i2c_slave_addr; //master communicates to this i2c slave address
		//0x49 for 100Khz @ 20Mhz Fosc, SSPADD = (_XTAL_FREQ/(4 * I2C_CLK )) - 1, SSPADD = 0x49 for I2C_CLK = 100KHz clock and _XTAL_FREQ = 20Mhz
		SSPADD = 0x49; 
    }
	 SSPIF = 0;
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void I2C_Rcvd_Start(void)
{
	while(SSPSTATbits.S == 0)
	{
		//Wait till start bit has been detected last
		/* #ifdef TRACE_ERROR
		  UART_Transmit_Str("ERR: wait for Start bit \r");
		#endif */
	}	
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void I2C_Rcvd_Stop(void)
{
	while(SSPSTATbits.P == 0)
	{
		//Wait till stop bit has been detected last
		//SHOULD_REMOVE
		/* #ifdef TRACE_ERROR
		    UART_Transmit_Str("ERR: wait for stop bit \r");
		 #endif */
	} 	
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void I2C_Rcvd_Restart(void)
{
	I2C_Rcvd_Start();
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
unsigned char I2C_Addr_Info()
{
	//SSPSTAT - D/A - bit 5 = 0 : Indicates that the last byte received or transmitted was address
	unsigned char return_status = STATE_YES_IN_CHAR;
	
	//SSPSTAT - D/A - bit 5 = 1 : Indicates that the last byte received or transmitted was data
	if(SSPSTATbits.D_nA == 1) 
		return_status =  STATE_NO_IN_CHAR;
	return return_status;
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
unsigned char I2C_Slave_Write_Info()
{
	// write bit info was rcvd in slave following the last address match */
	unsigned char return_status = STATE_YES_IN_CHAR;
	/* SSPSTAT - R/W - bit 2 = R/W bit information rcvd in slave following the last address match. 
	  This bit is only valid from the address match to the next Start bit, Stop bit, or not ACK bit */
	  /* read bit info was rcvd  in slave following the last address match */
	if(SSPSTATbits.R_nW == 1) 
	/* if R/W bit of the incoming address byte is set(read operation) and an address match occurs, 
      then R/W bit of the SSPSTAT register is set(read operation).	*/
		return_status =  STATE_NO_IN_CHAR;
	return return_status;
}

#ifdef UNUSED

void I2C_Master_Init(const unsigned long c)
{
  SSPCON = 0b00101000;            //SSP Module as Master
  SSPCON2 = 0;
  SSPADD = (_XTAL_FREQ/(4*c))-1; //Setting Clock Speed
  SSPSTAT = 0;
  TRISC3 = 1;                   //Setting as input as given in datasheet
  TRISC4 = 1;                   //Setting as input as given in datasheet
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void I2C_Master_Wait()
{
  while ((SSPSTAT & 0x04) || (SSPCON2 & 0x1F)); //Transmit is in progress
}
void I2C_Master_Start()
{
  I2C_Master_Wait();    
  SEN = 1;             //Initiate start condition
}
void I2C_Master_RepeatedStart()
{
  I2C_Master_Wait();
  RSEN = 1;           //Initiate repeated start condition
}
void I2C_Master_Stop()
{
  I2C_Master_Wait();
  PEN = 1;           //Initiate stop condition
}
void I2C_Master_Write(unsigned d)
{
  I2C_Master_Wait();
  SSPBUF = d;         //Write data to SSPBUF
}
unsigned short I2C_Master_Read(unsigned short a)
{
  unsigned short temp;
  I2C_Master_Wait();
  RCEN = 1;
  I2C_Master_Wait();
  temp = SSPBUF;      //Read data from SSPBUF
  I2C_Master_Wait();
  ACKDT = (a)?0:1;    //Acknowledge bit
  ACKEN = 1;          //Acknowledge sequence
  return temp;
}
void I2C_Slave_Init(short address) 
{
  SSPSTAT = 0x80;    
  SSPADD = address; //Setting address
  SSPCON = 0x36;    //As a slave device
  SSPCON2 = 0x01;
  TRISC3 = 1;       //Setting as input as given in datasheet
  TRISC4 = 1;       //Setting as input as given in datasheet
  GIE = 1;          //Global interrupt enable
  PEIE = 1;         //Peripheral interrupt enable
  SSPIF = 0;        //Clear interrupt flag
  SSPIE = 1;        //Synchronous serial port interrupt enable
}
void interrupt I2C_Slave_Read()
{
    unsigned char z;
  if(SSPIF == 1)
  {
    SSPCONbits.CKP = 0;

    if ((SSPCONbits.SSPOV) || (SSPCONbits.WCOL)) //If overflow or collision
    {
      z = SSPBUF; // Read the previous value to clear the buffer
      SSPCONbits.SSPOV = 0; // Clear the overflow flag
      SSPCONbits.WCOL = 0; // Clear the collision bit
      SSPCONbits.CKP = 1;
    }
  }

  if(!SSPSTATbits.D_nA && !SSPSTATbits.R_nW) //If last byte was Address + Write
  {
    z = SSPBUF;
    while(!BF);
    PORTD = SSPBUF;
    SSPCONbits.CKP = 1;
  }
  else if(!SSPSTATbits.D_nA && SSPSTATbits.R_nW) //If last byte was Address + Read
  {
    z = SSPBUF;
    BF = 0;
    SSPBUF = PORTB ;
    SSPCONbits.CKP = 1;
    while(SSPSTATbits.BF);
  }

  SSPIF = 0;
  }
#endif
 /*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
