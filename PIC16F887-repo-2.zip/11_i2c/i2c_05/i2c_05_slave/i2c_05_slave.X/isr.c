/**************************************************************************
   FILE          :    isr.c
 
   PURPOSE       :   Interrupt Service Routine Library
 
   AUTHOR        :     K.M. Arun Kumar alias Arunkumar Murugeswaran 
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #include "main.h"
 #include "port.h"
 #include "io_conf.h"
 #include "uart.h" 
 #include "i2c_fsm.h"
 #include "intp_event_handle.h"
 
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void interrupt Interrupt_ISR() 
{
	if( INTCONbits.INTE == 1 && INTF == 1)           // external interrupt ISR - higher priority
	{
		/*if INTF is not cleared in software, and when EXTR_INTP_SW is pressed on and after execution of External Interrupt ISR,   
		 and even when EXTR_INTP_SW is released, External Interrupt ISR keeps on been executed, until INTF, which was set, 
		 when EXTR_INTP_SW was pressed on, is cleared in software */		 
		 INTF = 0;
	     INTCONbits.INTE = 0; //disable the INT pin external interrupt		
		 External_Interrupt_Occured_Appl_Proc();		
	}
	if(SSPIF == 1)
	{
		 SSPCONbits.CKP = 0; //Holds i2c clock low (clock stretching or disable I2C clock). (Used to ensure data setup time.)
		 is_slave_i2c_send_or_rcvd_char_flag = STATE_YES_IN_CHAR;
		 SSPIF = 0;
		 #ifdef TRACE  
	        UART_Transmit_Str("I2C slave rcvd or tx char as SSPIF = 1 \r");	
	     #endif 
	}
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
