/**************************************************************************
   FILE          :    rcvd_data_proc.c
 
   PURPOSE       :   rcvd data Procedure 
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran 
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
#include "main.h" 
#include "port.h"
#include "appl_conf.h"
#include "i2c.h"
#include "lcd.h"
#include "uart.h"
#include "rcvd_data_proc.h"
#include "i2c_fsm.h"

 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
int Master_I2C_Rcvd_Data_Proc(unsigned char *master_rcvd_valid_data_str, unsigned int master_i2c_rcvd_valid_data_str_len)
{
	if(lcd_const_disp_flag[MASTER_LCD_RCVD_DATA_LINE_NUM] == STATE_NO_IN_CHAR)	
	{					 
	    Goto_XY_LCD_Disp(MASTER_LCD_RCVD_DATA_LINE_NUM,1);
		
		//SHOULD_REMOVE
		Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, master_i2c_rcvd_valid_data_str_len);
		Data_Str_Disp_LCD(" : ");
		
	    Data_Str_Disp_LCD(master_rcvd_valid_data_str);
	   	lcd_const_disp_flag[MASTER_LCD_RCVD_DATA_LINE_NUM] = STATE_YES_IN_CHAR;
					
		//SHOULD_REMOVE
		UART_Transmit_Str("Rcvd Slave's valid Data's len: ");
		UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, master_i2c_rcvd_valid_data_str_len);
		UART_Transmit_Char('\r');
		UART_Transmit_Str("Rcvd Slave's valid Data: ");
		UART_Transmit_Str(master_rcvd_valid_data_str);
		UART_Transmit_Char('\r');
		return 0;
	}
	return -1;
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
