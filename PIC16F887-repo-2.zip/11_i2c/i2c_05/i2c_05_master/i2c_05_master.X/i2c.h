/**************************************************************************
   FILE          :    i2c.h
 
   PURPOSE       :    I2C library Header
 
   AUTHOR        :     K.M. Arun Kumar alias Arunkumar Murugeswaran 
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/ 
#ifndef _I2C_H
#define	_I2C_H

#define INVALID_I2C_OPER_CHAR              ('\xFF')

typedef enum 
{
    I2C_MASTER_OSC_DIV4                 = 0b00101000, //In SSPCON, SSPM<3:0> - MSSP enabled and I2C Master mode, clock = FOSC / (4 * (SSPADD+1)) 
    I2C_MASTER_OSC_FIRMWARE             = 0b00100011, //In SSPCON, SSPM<3:0> - MSSP enabled and I2C firmware controlled Master mode (Slave idle) 
    I2C_SLAVE_7BIT_ADDR                 = 0b00100110, //In SSPCON, SSPM<3:0> - MSSP enabled and I2C Slave mode, 7-bit address
    I2C_SLAVE_10BIT_ADDR                = 0b00100111, //In SSPCON, SSPM<3:0> - MSSP enabled and I2C Slave mode, 10-bit address
    I2C_SLAVE_7BIT_ADDR_S_P_INTR_EN     = 0b00101110, //In SSPCON, SSPM<3:0> - MSSP enabled and I2C Slave mode, 7-bit address with Start and Stop bit interrupts enabled
    I2C_SLAVE_10BIT_ADDR_S_P_INTR_EN    = 0b00101111  //In SSPCON, SSPM<3:0> - MSSP enabled and I2C Slave mode, 10-bit address with Start and Stop bit interrupts enabled
} I2c_types;

typedef enum
{
	I2C_SLEW_RATE_CTRL_DIS             = 0b10000000, //In SSPSTAT, SMP - In I2C Master or Slave mode: Slew rate control disabled for standard speed mode (100 kHz and 1 MHz)
	I2C_SLEW_RATE_CTRL_EN              = 0b00000000  //In SSPSTAT, SMP - In I2C Master or Slave mode: Slew rate control enabled for high speed mode (400 kHz)
} I2c_slew_rate_ctrl_types;

typedef enum
{
	I2C_MASTER_GNL_CALL_DONT_CARE      = 0b00000000, //In SSPCON2, GCEN - I2C MASTER mode only, general call address is dont care
	I2C_SLAVE_GNL_CALL_EN              = 0b10000000, //In SSPCON2, GCEN - I2C Slave mode only, Enable interrupt when a general call address (0000h) is received in the SSPSR
	I2C_SLAVE_GNL_CALL_DIS             = 0b00000000  //In SSPCON2, GCEN - I2C Slave mode only, General call address disabled  
} I2c_gnl_call_types;

typedef enum
{
	I2C_IDLE, I2C_START_IDLE, I2C_REPEAT_START_IDLE, I2C_STOP_IDLE, I2C_ACK_SEQ_IDLE, I2C_RECEIVE_IDLE
} idle_i2c_states;


char I2C_Bus_Idle_Status();
void I2C_Init(const I2c_types, const I2c_slew_rate_ctrl_types, const I2c_gnl_call_types, const unsigned int to_tx_i2c_slave_addr);
void I2C_Sent_Start(void);
void I2C_Sent_Restart(void);
void I2C_Sent_Stop(void);
void I2C_Rcvd_Start(void);
void I2C_Rcvd_Restart(void);
void I2C_Rcvd_Stop(void);
void Master_I2C_Send_ACK(void);
void Master_I2C_Send_NACK(void);
void Slave_I2C_Send_ACK(void);
void Slave_I2C_Send_NACK(void);
unsigned int Master_I2C_Send_Byte(const unsigned int);
unsigned int Slave_I2C_Send_Byte(const unsigned int);
unsigned char Master_I2C_Rcvd_Byte();
unsigned char Slave_I2C_Rcvd_Byte();
unsigned char I2C_Addr_Info();
unsigned char I2C_Slave_Write_Info();
char Is_I2C_Idle(idle_i2c_states idle_i2c_state);

extern unsigned int i2c_slave_addr;
#endif	

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
