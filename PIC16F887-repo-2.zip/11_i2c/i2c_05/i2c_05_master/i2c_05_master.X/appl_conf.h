/**************************************************************************
   FILE          :    appl_conf.h
 
   PURPOSE       :   main application configuration Header
 
   AUTHOR        :     K.M. Arun Kumar alias Arunkumar Murugeswaran 
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _APPL_CONF_H
 #define _APPL_CONF_H 
 
 /* -------------------------------- debug conf -----------------------------------------*/
#define TRACE                                   (1U)
#define TRACE_ERROR                             (2U)

/*------------------------------- LCD disp conf ------------------------------------------*/
#define  LCD_DISP_ERR_LINE_NUM                  (4U)


/* -------------------------------Timer state conf ---------------------------------------*/



/* ---------------------------------- ADC input signal val conf -------------------------- */

/* ---------------------------------- I2C oper conf -------------------------------------- */

//I2C Slave Address	- 0b0000 011,	R/W - dont care ,description -	reserved for future purposes for unused I2C Slave Address
#define I2C_SLAVE_ADDR                                (0x06) 

#define MAX_COMM_NUM_CHARS                            (20U)

#define DATA_TERMINATOR_CHAR                          ('\\') 
#define ENQ_CHAR                                    ('\x05')
#define PADDED_CHAR                                 ('\x80')
#define MW_CHAR                                     ('\x95')

/* ------------------------------- application conf --------------------------------------*/


#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
