/* ********************************************************************
   FILE                   : timer.c

   PROGRAM DESCRIPTION    : Timer library 
                      									 
	 
   AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
   KNOWN BUGS            : 

   NOTE                  :  										
                                    
   CHANGE LOGS           : 

*****************************************************************************/

#include "timer.h"
#include "main.h"

unsigned int prescale_timer1 = 0x01, prescale_shift_timer1= 0, timer1_mode = TMR1_OFF_STATE;
unsigned long int num_calls_timer1 = 0, timer1_init = 0;
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 15  
-*------------------------------------------------------------*/
void Run_Timer1(const unsigned int set_timer1_mode )
{
	
  if(timer1_mode == TMR1_OFF_STATE)
  {
	/*internal timer1 clock  with 1:1 prescale,Timer1 counts when gate(T1G) is high 
     Timer1 counting is controlled by the Timer1 Gate function and no gate input is feed
     and enable timer1*/
	 
	  TMR1H = 0;
      TMR1L = 0;
	  TMR1IF = 0;
	  timer1_mode = set_timer1_mode;
	  /* for T1G gate based  timer 1 running control, Timer1 runs when T1G is high. If T1G is low, timer1 pauses counting */
	 // T1CON =0xC5; 

	 /*internal timer1 clock  with 1:1 prescale, gate(T1G) control for Timer1 is disabled  and enable timer1 and timer 1 runs Timer1 runs */
      T1CON =0x85;   
      prescale_timer1 = 0x01;
      prescale_shift_timer1= 0;
      Prescale_Timer1();
      timer1_init = (65536UL) - (INC1/prescale_timer1); 
      TMR1H = timer1_init / 256UL;
      TMR1L = timer1_init % 256UL; 
      num_calls_timer1 = 0;  
  }
  else
  {
	  /* dont run the timer1 if timer1 is already running  */
	  /* error: try to run timer1, which is not in off state */
	  
  }	  
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 16  
-*------------------------------------------------------------*/
void Stop_Timer1()
{
	if(timer1_mode != TMR1_OFF_STATE)
	{	
	   timer1_mode = TMR1_OFF_STATE;
	   T1CON = 0x80;
	}   
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 17  
-*------------------------------------------------------------*/
void Prescale_Timer1()
{
   if(T1CKPS0 == 1)
   {
      prescale_shift_timer1 |= 0x01;           
   }
   if(T1CKPS1 == 1)
   {
     prescale_shift_timer1 |= 0x02;
   }  
   prescale_timer1 = prescale_timer1  << prescale_shift_timer1;                                                      
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
