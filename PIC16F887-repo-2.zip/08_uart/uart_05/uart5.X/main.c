/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    :   a preset PIN and account number is set by default in code. Account and PIN datas are fed by virtual terminal using keyboard. 
UART is used for communication between virtual terminal and PIC. Parity error check are not implemented.
UART software flow control, Overrun error and Frame error check has been implemented. 
Timeout for long pressed key and no key press is not required. 
Entered password in keypad is displayed in  LCD. Use RESET_SW to reset Process, if any problem arises and start afresh. 
USe enter key in keyboard to end input and entered data is at end.

  At first Welcome message to be displayed, when ACCOUNT_SW is pressed, account number is entered.
If entered account number is correct, then ask for PIN  and if entered PIN is correct,
then display Next stage. If account number is incorrect and ask to reenter account number.
After 3 failed iteration on entered account number, stop reenter of account number and display visit bank. 
If no key is pressed for longer duration or key has been pressed for long duration, display timeout and display visit bank.
After 3 failed iteration on entered PIN number, stop reenter of PIN number and display visit bank.
After displayed visit bank wait for predetermined time(AUTH STATUS DISPLAY TIME DURATION), 
 display welcome message and wait for ACCOUNT_SW to be pressed to enter account number.
After that RESET_SW is pressed to restart the process, if any problem arises. 
Timer1 (executes time to wait from displayed auth status to display welcome message ) with status check. 
	 
AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :  When fast operation on backspace or input data is done on cur input data, then program got stuck, in UART , 
                        due to no implementation of XON & XOFF software flow control and fix issue of getting OERR error when fast pressed backspace key.  

NOTE                  : implements sEOS, a simple time triggered ,nonpremptive and single application task executing embedded OS.
                        Code with base from PIC16F887-repo->04_lcd->lcd_14->lcd14.c.   
                        
STATUS                : NOT YET COMPLETED
                       										
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "main.h"
#include "port.h"
#include "simple_EOS.h"
#include "PC_O_T1.h"
#include "Elap_232.h"
#include "lcd.h"
#include "uart.h"
#include "timer.h"
/*------------------------------------------------------------*-
FUNCTION NAME  : main

DESCRIPTION    :1: Initialize baud rate to 9600. 
                2: configure Timer T2 for automatic reload with preload and recapture values,
								 corresponding to SYSTEM_TICK_INTERVAL msec and run the T2.								
								3: put the CPU of 8051/8052 in idle mode and Every  SYSTEM_TICK_INTERVAL when T2 overflow interrupt occurs, 
                4: for every UPDATE_PERIOD, and finite-state machine (FSM) of animatronic dinosaur system are processed. 							
                5: go to step 3, and repeat
								
INPUT          : none

OUTPUT         : 

NOTE           : in RS 232 port, PC must also be configured 9600 baud, 8 bit data, no parity and 1 stop bit.
-*------------------------------------------------------------*/

void main(void)
   {
		 /* ========= begin : USER CODE INITIALIZE ========== */
		 // Set baud rate to 9600
      PC_LINK_O_Init_T1(9600);

    // Prepare for elapsed time measurement
     Elapsed_Time_RS232_Init(); 
		
	/* ========= end : USER CODE INITIALIZE ========== */	 
    /* Set up simple EOS. configure Timer 2 and start running Timer 2, 
		 with SYSTEM_TICK_INTERVAL time in ms ticks  */ 
   sEOS_Init_Timer2(SYSTEM_TICK_INTERVAL);   
   
   while(1) // Super Loop
      {
				/* uC enters idle mode to save power consumed by CPU. But timers, UART and other
				peripherals continue to work after idle mode */
			/* ============ PERIODIC SYSTEM TASK EXECUTION ============= */	
      sEOS_Go_To_Sleep();  
			/* here uC does not execute. When interrupt occurs, uC executes its corresponding ISR.
         in our case, only Timer 2 overflow interrupt will occur, which executes its ISR, sEOS_ISR()	*/	
			/* ISR of Timer 2 executes application task */	
      }
   }

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/	 
