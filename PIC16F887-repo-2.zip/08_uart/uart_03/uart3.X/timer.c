/**************************************************************************
   FILE          :    timer.c
 
   PURPOSE       :   Timer Library
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #include "main.h"
 #include "timer.h" 
 #include "uart.h"
 #include "io_conf.h"
 #include "appl_conf.h"
 
#ifdef TIMER0_MOD_ENABLE
unsigned int timer0_prescale_shift= 0, timer0_elapsed_num_update = 0,  timer0_init_val = 0  ;
unsigned long int timer0_prescale = 2,timer0_elapsed_num_overflow_1_update = 0, timer0_1_update = 0, timer0_max_num_overflow =0, timer0_req_time_max_update = 0;
unsigned int  timer0_cur_run_state= TMR0_STOP_STATE, timer0_last_run_state_before_stop = TMR0_STOP_STATE, timer0_cur_service_type = TMR0_INVALID_SERVICE;
tmr0_data_types  tmr0_datas[1];
char timer0_timeout_occured_flag = STATE_NO_IN_CHAR;
volatile unsigned int tmr0_measure_pulse_lower_count, tmr0_measure_pulse_upper_count;
#endif
 
 #ifdef TIMER1_MOD_ENABLE
unsigned int timer1_prescale = 1, timer1_prescale_shift= 0, timer1_elapsed_num_update = 0 ;
unsigned long int  timer1_init_val = 0, timer1_elapsed_num_overflow_1_update = 0, timer1_1_update = 0, timer1_max_num_overflow =0, timer1_req_time_max_update = 0, timer1_req_time_delay_in_milli_sec;
unsigned int  timer1_cur_run_state= TMR1_STOP_STATE, timer1_last_run_state_before_stop = TMR1_STOP_STATE, timer1_cur_service_type = TMR1_INVALID_SERVICE;
tmr1_data_types  tmr1_datas[1];
char timer1_timeout_occured_flag = STATE_NO_IN_CHAR;
volatile unsigned long tmr1_measure_pulse_lower_count, tmr1_measure_pulse_upper_count;
#endif

#ifdef TIMER2_MOD_ENABLE
unsigned int timer2_prescale = 1, timer2_prescale_shift= 0, timer2_postscale = 1, timer2_elapsed_num_update = 0 ;
unsigned long int  timer2_init_val = 0, timer2_elapsed_num_overflow_1_update = 0, timer2_1_update = 0, timer2_max_num_overflow =0, timer2_req_time_max_update = 0;
unsigned int  timer2_cur_run_state= TMR2_STOP_STATE, timer2_last_run_state_before_stop = TMR2_STOP_STATE, timer2_cur_service_type = TMR2_INVALID_SERVICE;
tmr2_data_types  tmr2_datas[1];
#endif

#ifdef TIMER0_MOD_ENABLE
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void  Timer0_Conf_Parameters(unsigned int set_timer0_run_state )
{
	unsigned int tmr0_prescale_in_bits, i = 0;
	unsigned long tmr0_cur_prescale_val;
	
	tmr0_datas[set_timer0_run_state].timer0_service_type = TMR0_STATE0_SERVICE_TYPE;
	tmr0_datas[set_timer0_run_state].timer0_input_clk_type = TMR0_STATE0_CLK_TYPE; 
	tmr0_cur_prescale_val = TMR0_STATE0_PRESCALE;
	while(tmr0_cur_prescale_val > 2)
	{
		tmr0_cur_prescale_val /= 2;
		++i;
	}
	tmr0_prescale_in_bits = i;
	tmr0_datas[set_timer0_run_state].timer0_input_clk_prescaler = tmr0_prescale_in_bits;	
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    : Sets up Timer 2 to drive the simple EOS. 
								
INPUT          : none

OUTPUT         : 

NOTE           : Precise tick intervals are only possible with certain 
  oscillator / tick interval combinations. For eg If timing is important,
  you should check the timing calculations manually by using simulator. 
	If you require both accurate baud rates and accurate EOS timing, use an
  11.0592 MHz crystal and a tick rate of 5, 10, 15, 60 or 65 ms. 
	Such that divide by 5 tick rates are precise with an 11.0592 MHz crystal.

Func ID        : 21   
-*------------------------------------------------------------*/
void Timer0_Run(unsigned int set_timer0_run_state, unsigned long int set_timer0_req_time_delay_in_milli_sec)
{
	 Timer0_Conf_Parameters(set_timer0_run_state);
	 if(tmr0_datas[set_timer0_run_state ].timer0_service_type & 4)
	 {
		  //tmr1_datas[set_timer1_run_state ].timer1_service_type  = TMR1_INVALID_SERVICE
		  return;
	 }
	 
	 if(tmr0_datas[set_timer0_run_state ].timer0_service_type & 2)
	 {
		 //Timer 0 is timer 
		 #ifdef TRACE
		     UART_Transmit_Str("TMR0 is Timer \r");
		 #endif
		  
		 if(!(tmr0_datas[set_timer0_run_state].timer0_input_clk_type & 2))
		 {
			  // timer 0 clock source as internal
			 OPTION_REG = tmr0_datas[set_timer0_run_state].timer0_input_clk_type << 4 | 0 << 3 | tmr0_datas[set_timer0_run_state].timer0_input_clk_prescaler; 
	         #ifdef TRACE
	            to_disp.unsigned_val.val_in_bytes.value_byte[0] = OPTION_REG;
                UART_Transmit_Str("OPTION_REG config : 0x");
                UART_Transmit_Num(DISP_HEX_DIGIT2, to_disp );
	            UART_Transmit_Char('\r');                                  	  
             #endif
	         Timer0_Prescale(); 
             timer0_cur_run_state = timer0_last_run_state_before_stop = set_timer0_run_state;
			 timer0_cur_service_type = tmr0_datas[set_timer0_run_state ].timer0_service_type;
			 Timer0_Load_Init_Val_Calc(set_timer0_req_time_delay_in_milli_sec);
		 }	
         else
		 {
             // timer 0 clock source as external
		     #ifdef TRACE_ERROR
				   UART_Transmit_Str("ERR: TMR0 is timer but clk source is not internal \r");
			 #endif 
			 return;			 
		 }			 
	 }
	 else
	 {
		  //Timer 0 is counter 		
         if((tmr0_datas[set_timer0_run_state].timer0_input_clk_type & 2))
		 {
			 // timer 0 clock source as external
			 OPTION_REG = tmr0_datas[set_timer0_run_state].timer0_input_clk_type << 4 | 0 << 3 | tmr0_datas[set_timer0_run_state].timer0_input_clk_prescaler; 
	         #ifdef TRACE
	            to_disp.unsigned_val.val_in_bytes.value_byte[0] = OPTION_REG;
                UART_Transmit_Str("OPTION_REG config : 0x");
                UART_Transmit_Num(DISP_HEX_DIGIT2, to_disp );
	            UART_Transmit_Char('\r');                                  	  
             #endif
	         Timer0_Prescale(); 
             timer0_cur_run_state = timer0_last_run_state_before_stop = set_timer0_run_state;	             
			 timer0_cur_service_type = tmr0_datas[set_timer0_run_state ].timer0_service_type;
			 tmr0_measure_pulse_upper_count = 0;            
             #ifdef TRACE
			   to_disp.unsigned_val.val_in_bytes.value_byte[0] = tmr0_measure_pulse_lower_count;
		       UART_Transmit_Str("TMR0 is counter, TMR0 = 0x");
			   UART_Transmit_Num(DISP_HEX_DIGIT2, to_disp );
	           UART_Transmit_Char('\r');                                  	  
             #endif
		     TMR0 = tmr0_measure_pulse_lower_count;			 
		 }
		 else
		 {			
			  #ifdef TRACE_ERROR
				   UART_Transmit_Str("ERR: TMR0 is counter but clk source is not external \r");
			  #endif 
			  return;
		 }	
	 }
     if(tmr0_datas[set_timer0_run_state ].timer0_service_type & 0x01)
	 {
		  //timer0 service is interrupt
		 #ifdef TRACE
	        UART_Transmit_Str("T0IE & GIE are enabled, interrupt service \r"); 
	     #endif	
		 
		  T0IF = 0;   		 
          INTCONbits.T0IE = 1; //Enables the Timer0 overflow interrupt 
		  INTCONbits.GIE = 1;  //Enables all unmasked interrupts 
	 }
	 else
     {
		 //timer0 service is polling and disable the Timer1 overflow interrupt 
		 #ifdef TRACE
	         UART_Transmit_Str("T0IE is disabled, polling service \r"); 
	     #endif  
		 T0IF = 0;   		 
         INTCONbits.T0IE = 0; //Disable the Timer0 overflow interrupt 		 
	}       	 
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Timer0_Prescale()
{
	unsigned int i;
	
   timer0_prescale = 2;
   timer0_prescale_shift= 0;
   if(PS0 == 1)
   {
      timer0_prescale_shift |= 0x01;           
   }
   if(PS1 == 1)
   {
     timer0_prescale_shift |= 0x02;
   }
   if(PS2 == 1)
   {
	   timer0_prescale_shift |= 0x04;
   }
   for(i = 1; i <= timer0_prescale_shift; ++i)
   {
      timer0_prescale *= 2;
   }  
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : http://picguides.com/beginner/timers.php
                 yet to calculate timer1_adjust_init_val to include timer1 overflow instructions executed delay 
				 from TMR1IF == 1 till instruction to reload TMR1 register to get almost precise time delay

Func ID        : 21   
-*------------------------------------------------------------*/
void Timer0_Load_Init_Val_Calc(const unsigned long int set_timer0_req_time_delay_in_milli_sec)
{
	unsigned long int inc_timer0;
	unsigned long int set_timer0_tick_in_milli_sec = TIMER0_TICK_IN_MILLI_SEC;
	unsigned long int set_timer0_req_time_1_update_in_milli_sec = TIMER0_REQ_TIME_1_UPDATE_REACHED_IN_MILLI_SEC;
	unsigned long int timer0_remainder; 
	
/*	#ifdef TRACE
      to_disp.unsigned_val.val_in_bytes.value_byte[0] = timer0_prescale;
       UART_Transmit_Str("Timer0 Prescaler : ");
       UART_Transmit_Num(DISP_UNSIGN_NUM_DIGIT2, to_disp );
	   UART_Transmit_Char('\r');		
    #endif */
	
      timer0_elapsed_num_overflow_1_update = 0;
	  timer0_elapsed_num_update = 0;
	  timer0_timeout_occured_flag = STATE_NO_IN_CHAR;
	  timer0_1_update = set_timer0_req_time_1_update_in_milli_sec  /set_timer0_tick_in_milli_sec;
      timer0_remainder = set_timer0_req_time_delay_in_milli_sec % set_timer0_req_time_1_update_in_milli_sec;	  
	  if( timer0_remainder == 0)
	  {
		  //set_timer0_req_time_delay_in_milli_sec is in multiples of  set_timer0_req_time_1_update_in_milli_sec
		  tmr0_datas[timer0_cur_run_state ].timer0_req_time_delay_in_milli_sec = set_timer0_req_time_delay_in_milli_sec;	
		  
	  }
	  else
	  {
		  //set_timer0_req_time_delay_in_milli_sec is not in multiples of  set_timer0_req_time_1_update_in_milli_sec
		  #if TIMER0_SET_TIME_DELAY_IN_MULTIPLE == TIMER0_PRESET_TIME_DELAY_IN_MULTIPLE
		    //timer0_req_time_delay_in_milli_sec is previous valid req_time_delay_in_milli_sec, which is multiple of set_timer0_req_time_1_update_in_milli_sec
		     tmr0_datas[timer0_cur_run_state ].timer0_req_time_delay_in_milli_sec = set_timer0_req_time_delay_in_milli_sec - timer0_remainder;
		  #else //TIMER0_SET_TIME_DELAY_IN_MULTIPLE == TIMER0_POSTSET_TIME_DELAY_IN_MULTIPLE
		     //timer0_req_time_delay_in_milli_sec is next valid req_time_delay_in_milli_sec, which is multiple of set_timer0_req_time_1_update_in_milli_sec
            tmr0_datas[timer0_cur_run_state ].timer0_req_time_delay_in_milli_sec = set_timer0_req_time_delay_in_milli_sec - timer0_reminder + set_timer0_req_time_1_update_in_milli_sec ;	
          #endif	
	  }
	  timer0_req_time_max_update = tmr0_datas[timer0_cur_run_state ].timer0_req_time_delay_in_milli_sec / set_timer0_req_time_1_update_in_milli_sec;
	  
	  #ifdef TRACE
	     to_disp.unsigned_val.value_long = tmr0_datas[timer0_cur_run_state ].timer0_req_time_delay_in_milli_sec;
	     UART_Transmit_Str("TMR0 start running set for interval : ");
         UART_Transmit_Num(DISP_UNSIGN_NUM_DIGIT5, to_disp ); 
	     UART_Transmit_Str(" millisecs \r"); 
      #endif		  
	
    /* for timer0, TMR0 = (256 - ((timerPeriod_in_sec * Fosc_in_Hertz)/(4*prescaler)) ),  where 2 = TMR0 load time req is 2 Timer Clock cycle  */
    // inc_timer0  =      (unsigned long)((unsigned long)(_XTAL_FREQ * set_timer0_tick_in_milli_sec ) / (unsigned long)(OSC_PER_INST * TIME_UNIT_1_SEC_IN_MILLI_SEC  )) 
	inc_timer0 = (_XTAL_FREQ / (OSC_PER_INST * TIME_UNIT_1_SEC_IN_MILLI_SEC)) * set_timer0_tick_in_milli_sec; // for 1000ul = 4MHz / (4 * 1000), when _XTAL_FREQ  = 4MHz  
    timer0_init_val = (255 - (inc_timer0/timer0_prescale)) + 1 + 2; 
    TMR0 = timer0_init_val;     
}
#endif

#ifdef TIMER1_MOD_ENABLE
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void  Timer1_Conf_Parameters(unsigned int set_timer1_run_state )
{
	unsigned int tmr1_prescale_in_bits, i = 0;
	unsigned long tmr1_cur_prescale_val;
	
	tmr1_datas[set_timer1_run_state ].timer1_service_type = TMR1_STATE0_SERVICE_TYPE;
	tmr1_datas[set_timer1_run_state ].timer1_gate_ctrl_type = TMR1_STATE0_GATE_CTRL_TYPE; 
	tmr1_datas[set_timer1_run_state ].timer1_input_clk_type = TMR1_STATE0_CLK_TYPE; 
	tmr1_datas[set_timer1_run_state ].timer1_lp_osc_enable_ctrl = TMR1_STATE0_LP_OSC_ENABLE_TYPE; 
	tmr1_cur_prescale_val = TMR1_STATE0_PRESCALE;
	while(tmr1_cur_prescale_val > 1)
	{
		tmr1_cur_prescale_val /= 2;
		++i;
	}
	tmr1_prescale_in_bits = i;
	tmr1_datas[set_timer1_run_state].timer1_input_clk_prescaler =  tmr1_prescale_in_bits; 	
}

 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Timer1_Run(const unsigned int set_timer1_run_state, const unsigned long int set_timer1_req_time_delay_in_milli_sec )
{
      Timer1_Stop();
	  
	  Timer1_Conf_Parameters(set_timer1_run_state);
	  
      if(tmr1_datas[set_timer1_run_state ].timer1_service_type & 0x04)
	  {
		  //tmr1_datas[set_timer1_run_state ].timer1_service_type  = TMR1_INVALID_SERVICE
		  return;
	  }		  
	 
	   if(tmr1_datas[set_timer1_run_state ].timer1_service_type & 0x02)
	   {
		   //timer1 is in timer mode
		   if(!(tmr1_datas[ set_timer1_run_state].timer1_input_clk_type & 1 ))
		   {
	            //Timer1 Clock Source is internal clock
				
				#ifdef TRACE
	              UART_Transmit_Str("TMR1 in timer mode \r"); 
	            #endif
                timer1_cur_run_state = timer1_last_run_state_before_stop = set_timer1_run_state;
       	  
	            T1CON =  (tmr1_datas[ timer1_cur_run_state].timer1_gate_ctrl_type << 6)  | tmr1_datas[ timer1_cur_run_state].timer1_input_clk_type << 1 | \
                    	(tmr1_datas[ timer1_cur_run_state].timer1_lp_osc_enable_ctrl << 3) |  (tmr1_datas[timer1_cur_run_state ].timer1_input_clk_prescaler <<4) ; 
	             Timer1_Prescale(); 
	  
	            #ifdef TRACE
	              to_disp.unsigned_val.val_in_bytes.value_byte[0] = T1CON;
                  UART_Transmit_Str("T1CON config : 0x");
                  UART_Transmit_Num(DISP_HEX_DIGIT2, to_disp );
	              UART_Transmit_Char('\r');                                  	  
                #endif
	  
	            timer1_cur_service_type = tmr1_datas[timer1_cur_run_state ].timer1_service_type;				
				Timer1_Load_Init_Val_Calc(set_timer1_req_time_delay_in_milli_sec); 	
	       }
           else
		   {
			  #ifdef TRACE_ERROR
				   UART_Transmit_Str("ERR: TMR1 is timer but clk source is not internal \r");
			  #endif			  
			 
			  return;
		   }	
	   }
	   else
	   {
		   //timer1 is in counter mode
		   if(tmr1_datas[ set_timer1_run_state].timer1_input_clk_type & 1 ) 
		   {
				//Timer1 Clock Source is external clock  
				if(tmr1_datas[set_timer1_run_state ].timer1_lp_osc_enable_ctrl == TMR1_LP_OSC_ENABLE)
				{	
        			//LP oscillator is enabled for Timer1 clock				
                    timer1_cur_run_state = timer1_last_run_state_before_stop = set_timer1_run_state;
       	  
	                T1CON =  (tmr1_datas[ timer1_cur_run_state].timer1_gate_ctrl_type << 6)  | tmr1_datas[ timer1_cur_run_state].timer1_input_clk_type << 1 | \
                      	(tmr1_datas[ timer1_cur_run_state].timer1_lp_osc_enable_ctrl << 3) |  (tmr1_datas[timer1_cur_run_state ].timer1_input_clk_prescaler <<4) ; 
	                Timer1_Prescale(); 
	  
	                #ifdef TRACE
	                  to_disp.unsigned_val.val_in_bytes.value_byte[0] = T1CON;
                      UART_Transmit_Str("T1CON config : 0x");
                      UART_Transmit_Num(DISP_HEX_DIGIT2, to_disp );
	                  UART_Transmit_Char('\r');                                  	  
                    #endif
	                //Timer1 is counter and set_timer1_req_time_delay_in_milli_sec = initial TMR1 value
	                timer1_cur_service_type = tmr1_datas[timer1_cur_run_state ].timer1_service_type; 
					tmr1_measure_pulse_lower_count = set_timer1_req_time_delay_in_milli_sec;
					tmr1_measure_pulse_upper_count = 0; 
			        TMR1 = tmr1_measure_pulse_lower_count;	
					
			    	#ifdef TRACE
	                   to_disp.unsigned_val.val_in_bytes.value_byte[0] =  TMR1;
	                   UART_Transmit_Str("TMR1 in counter mode, TMR1 = 0x"); 
					   UART_Transmit_Num(DISP_HEX_DIGIT4, to_disp);
	                   UART_Transmit_Char('\r');  
	                #endif
					
				}
				else
				{
					#ifdef TRACE_ERROR
				      UART_Transmit_Str("ERR: TMR1 is counter but LP osc is disabled \r");
				    #endif					
					
				    return;
				}
		   }
		   else
		   {
				#ifdef TRACE_ERROR
				   UART_Transmit_Str("ERR: TMR1 is counter but clk source is not external \r");
				#endif				
				
				return;
		   }
	   }
	   
	   if(tmr1_datas[set_timer1_run_state ].timer1_service_type & 0x01)
	   {
		      //timer1 service is interrupt
		       TMR1IF = 0;   		 
               PIE1bits.TMR1IE = 1; //Enables the Timer1 overflow interrupt 
		       INTCONbits.PEIE = 1;  //Enables all unmasked peripherals interrupts   
               INTCONbits.GIE = 1;  //Enables all unmasked interrupts 
	  
               #ifdef TRACE
	              UART_Transmit_Str("TMR1IE, PEIE & GIE are enabled, interrupt service \r"); 
	           #endif		   
	   }
	   else
	   {
		     //timer1 service is polling and disable the Timer1 overflow interrupt 
		     PIE1bits.TMR1IE = 0; 
			
		     #ifdef TRACE
	            UART_Transmit_Str("TMR1IE is disabled, polling service \r"); 
	         #endif
	   }       
	      
	  TMR1IF = 0;
      T1CONbits.TMR1ON = 1 ; //Enables Timer1 and timer1 runs
}   
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Timer1_Stop()
{
	//if(timer1_cur_run_state != TMR1_STOP_STATE)
	{
	   T1CONbits.TMR1ON = 0 ; //stops Timer1.
	   PIE1bits.TMR1IE = 0; //disable the Timer1 overflow interrupt 
	   TMR1IF = 0;
	   timer1_cur_run_state = TMR1_STOP_STATE;
	   timer1_cur_service_type = TMR1_INVALID_SERVICE;
	   //Commited due to stack overflow
	  /* #ifdef TRACE 
	     UART_Transmit_Str("Timer1 is stopped \r");
	   #endif */	 
	}   
}	
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Timer1_Prescale()
{
	unsigned int i;
	
   timer1_prescale = 1;
   timer1_prescale_shift= 0;
   if(T1CKPS0 == 1)
   {
      timer1_prescale_shift |= 0x01;           
   }
   if(T1CKPS1 == 1)
   {
     timer1_prescale_shift |= 0x02;
   }
   for(i = 1; i <= timer1_prescale_shift; ++i)
   {
      timer1_prescale *= 2;
   }  
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : http://picguides.com/beginner/timers.php
                 yet to calculate timer1_adjust_init_val to include timer1 overflow instructions executed delay 
				 from TMR1IF == 1 till instruction to reload TMR1 register to get almost precise time delay

Func ID        : 21   
-*------------------------------------------------------------*/
void Timer1_Load_Init_Val_Calc(const unsigned long int set_timer1_req_time_delay_in_milli_sec)
{
	unsigned long int inc_timer1;
	unsigned long int set_timer1_tick_in_milli_sec = TIMER1_TICK_IN_MILLI_SEC;
	unsigned long int set_timer1_req_time_1_update_in_milli_sec = TIMER1_REQ_TIME_1_UPDATE_REACHED_IN_MILLI_SEC;
	unsigned long int timer1_remainder; 
	
/*	#ifdef TRACE
      to_disp.unsigned_val.val_in_bytes.value_byte[0] = timer1_prescale;
       UART_Transmit_Str("Timer1 Prescaler : ");
       UART_Transmit_Num(DISP_UNSIGN_NUM_DIGIT2, to_disp );
	   UART_Transmit_Char('\r');		
    #endif */
	
      timer1_elapsed_num_overflow_1_update = 0;
	  timer1_elapsed_num_update = 0;
	  timer1_timeout_occured_flag = STATE_NO_IN_CHAR;
	  timer1_1_update = set_timer1_req_time_1_update_in_milli_sec /set_timer1_tick_in_milli_sec;
      timer1_remainder = set_timer1_req_time_delay_in_milli_sec % set_timer1_req_time_1_update_in_milli_sec;	  
	  if( timer1_remainder == 0)
	  {
		  //set_timer1_req_time_delay_in_milli_sec is in multiples of  set_timer1_req_time_1_update_in_milli_sec
		  tmr1_datas[timer1_cur_run_state ].timer1_req_time_delay_in_milli_sec = set_timer1_req_time_delay_in_milli_sec;	
		  
	  }
	  else
	  {
		  //set_timer1_req_time_delay_in_milli_sec is not in multiples of  set_timer1_req_time_1_update_in_milli_sec
		  #if TIMER1_SET_TIME_DELAY_IN_MULTIPLE == TIMER1_PRESET_TIME_DELAY_IN_MULTIPLE
		    //timer1_req_time_delay_in_milli_sec is previous valid req_time_delay_in_milli_sec, which is multiple of set_timer1_req_time_1_update_in_milli_sec
		     tmr1_datas[timer1_cur_run_state ].timer1_req_time_delay_in_milli_sec = set_timer1_req_time_delay_in_milli_sec - timer1_remainder;
		  #else //TIMER1_SET_TIME_DELAY_IN_MULTIPLE == TIMER1_POSTSET_TIME_DELAY_IN_MULTIPLE
		     //timer1_req_time_delay_in_milli_sec is next valid req_time_delay_in_milli_sec, which is multiple of set_timer1_req_time_1_update_in_milli_sec
            tmr1_datas[timer1_cur_run_state ].timer1_req_time_delay_in_milli_sec = set_timer1_req_time_delay_in_milli_sec - timer1_reminder + set_timer1_req_time_1_update_in_milli_sec ;	
          #endif	
	  }
	  timer1_req_time_max_update = tmr1_datas[timer1_cur_run_state ].timer1_req_time_delay_in_milli_sec / set_timer1_req_time_1_update_in_milli_sec;
	  
	  #ifdef TRACE
	     to_disp.unsigned_val.value_long = tmr1_datas[timer1_cur_run_state ].timer1_req_time_delay_in_milli_sec;
	     UART_Transmit_Str("TMR1 start running set for expiry : ");
         UART_Transmit_Num(DISP_UNSIGN_NUM_DIGIT5, to_disp ); 
	     UART_Transmit_Str(" millisecs \r"); 
      #endif		  
	
    /* for timer1, TMR1 = (65536 - ((timerPeriod_in_sec * Fosc_in_Hertz)/(4*prescaler)) ),  where 2 = TMR1 load time req is 2 Timer Clock cycle  */
    // inc_timer1  =      (unsigned long)((unsigned long)(_XTAL_FREQ * set_timer1_tick_in_milli_sec ) / (unsigned long)(OSC_PER_INST * TIME_UNIT_1_SEC_IN_MILLI_SEC  )) 
	inc_timer1 = (_XTAL_FREQ / (OSC_PER_INST * TIME_UNIT_1_SEC_IN_MILLI_SEC)) * set_timer1_tick_in_milli_sec; // for 1000ul = 4MHz / (4 * 1000), when _XTAL_FREQ  = 4MHz  
    timer1_init_val = (65535 - (inc_timer1/timer1_prescale)) + 1 + 2; 
    TMR1 = timer1_init_val;     
}
#endif

#ifdef TIMER2_MOD_ENABLE
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Timer2_Conf_Parameters(unsigned int set_timer2_run_state )
{
	tmr2_datas[set_timer2_run_state ].timer2_service_type = TMR2_STATE0_SERVICE_TYPE; 
	tmr2_datas[set_timer2_run_state].timer2_clk_prescale = TMR2_STATE0_PRESCALE; 
	tmr2_datas[set_timer2_run_state].timer2_output_postscale =  TMR2_STATE0_POSTSCALE - 1;
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Timer2_Run(const unsigned int set_timer2_run_state, const unsigned long int set_timer2_req_time_delay_in_milli_sec  )
{
	  Timer2_Stop(); 
	  Timer2_Conf_Parameters(set_timer2_run_state );
	  if(tmr2_datas[set_timer2_run_state ].timer2_service_type & 0x04)
	  {
		  //tmr2_datas[set_timer2_run_state ].timer2_service_type  = TMR1_INVALID_SERVICE
		  return;
	  }
	   
	
	  if(tmr2_datas[set_timer2_run_state ].timer2_service_type & 0x02)
	  {
		   //timer2 for PWM and set_timer2_req_time_delay_in_milli_sec = initial TMR2 value 
		    TMR2 = set_timer2_req_time_delay_in_milli_sec;
	        TMR2IF = 0; 
	  }
	  if(tmr2_datas[set_timer2_run_state ].timer2_service_type & 0x01)
	  {
		   //timer2 service is interrupt
		   TMR2IF = 0;   		 
           PIE1bits.TMR2IE = 1; //Enables the Timer2 overflow interrupt 
		   INTCONbits.PEIE = 1;  //Enables all unmasked peripherals interrupts   
           INTCONbits.GIE = 1;  //Enables all unmasked interrupts 
	  
           #ifdef TRACE
	           UART_Transmit_Str("TMR2IE, PEIE & GIE are enabled, interrupt service \r"); 
	      #endif		   
	  }
	  else
	  {
		   //timer2 service is polling and disable the Timer2 overflow interrupt 
		   PIE1bits.TMR2IE = 0; 
			
		    #ifdef TRACE
	           UART_Transmit_Str("TMR2IE is disabled, polling service \r"); 
	        #endif
	  }       
	  timer2_cur_service_type = tmr2_datas[set_timer2_run_state ].timer2_service_type;
	  timer2_cur_run_state = timer2_last_run_state_before_stop = set_timer2_run_state;	  
	  T2CON = (tmr2_datas[timer2_cur_run_state].timer2_clk_prescale ) | ( tmr2_datas[timer2_cur_run_state].timer2_output_postscale << 4) ; 
	  Timer2_Prescale();
      Timer2_Postscale();
	  
	  #ifdef TRACE
	      to_disp.unsigned_val.val_in_bytes.value_byte[0] = T2CON;
          UART_Transmit_Str("T2CON config : 0x");
          UART_Transmit_Num(DISP_HEX_DIGIT2, to_disp );
	      UART_Transmit_Char('\r');               	  
      #endif
	  
      T2CONbits.TMR2ON = 1 ; //Enables Timer2 and timer2 runs
}   
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Timer2_Stop()
{
	//if(timer2_cur_run_state != TMR2_STOP_STATE)
	{
	   T2CONbits.TMR2ON = 0 ; //stops Timer1.
	   PIE1bits.TMR2IE = 0; //disable the Timer2 overflow interrupt 
	   TMR2IF = 0;
	   timer2_cur_run_state = TMR2_STOP_STATE;
	   timer2_cur_service_type = TMR2_INVALID_SERVICE;
	   
	   //Commited due to stack overflow
	  /* #ifdef TRACE 
	     UART_Transmit_Str("Timer2 is stopped \r");
	   #endif */	 
	}   
}	
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Timer2_Prescale()
{
	unsigned int i;
	
   timer2_prescale = 1;
   timer2_prescale_shift= 0;
   if(T2CKPS1 == 1)
   {
     timer2_prescale_shift = 0x02; 
   }
   else
   {
      if(T2CKPS0 == 1)
      {
          timer2_prescale_shift = 0x01;           
      }
   }
   for(i = 1; i <= timer2_prescale_shift; ++i)
   {
      timer2_prescale *= 4;
   }  
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Timer2_Postscale()
{
	timer2_postscale = 1;
	if(TOUTPS0 == 1)
		timer2_postscale += 1;
	if(TOUTPS1 == 1)
		timer2_postscale += 2;
	if(TOUTPS2 == 1)
		timer2_postscale += 4;
	if(TOUTPS3 == 1)
		timer2_postscale += 8;
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : http://picguides.com/beginner/timers.php
                 yet to calculate timer2_adjust_init_val to include timer1 overflow instructions executed delay 
				 from TMR2IF == 1 till instruction to reload TMR2 register to get almost precise time delay

Func ID        : 21   
-*------------------------------------------------------------*/
void Timer2_Load_Init_Val_Calc(const unsigned long int set_timer2_req_time_delay_in_milli_sec)
{
	unsigned long int inc_timer2;
	unsigned long int set_timer2_tick_in_milli_sec = TIMER2_TICK_IN_MILLI_SEC;
	unsigned long int set_timer2_req_time_1_update_in_milli_sec = TIMER2_REQ_TIME_1_UPDATE_REACHED_IN_MILLI_SEC;
	unsigned long int timer2_remainder; 

/*	#ifdef TRACE
        to_disp.unsigned_val.value_long = timer2_prescale;
       UART_Transmit_Str("Timer2 Prescaler : ");
       UART_Transmit_Num(DISP_UNSIGN_NUM_DIGIT2, to_disp );
	   UART_Transmit_Char('\r');		
    #endif */
   
	  timer2_elapsed_num_overflow_1_update = 0;
	  timer2_max_num_overflow  = 0; 
	  timer2_1_update = set_timer2_req_time_1_update_in_milli_sec /set_timer2_tick_in_milli_sec;
      timer2_remainder = set_timer2_req_time_delay_in_milli_sec % set_timer2_req_time_1_update_in_milli_sec;	  
	  if( timer2_remainder == 0)
	  {
		  //set_timer2_req_time_delay_in_milli_sec is in multiples of  set_timer1_req_time_1_update_in_milli_sec
		 tmr2_datas[timer2_cur_run_state ].timer2_req_time_delay_in_milli_sec = set_timer2_req_time_delay_in_milli_sec;  		  	 
	  }
	  else
	  {
		  //set_timer2_req_time_delay_in_milli_sec is not in multiples of  set_timer2_req_time_1_update_in_milli_sec
		  #if TIMER2_SET_TIME_DELAY_IN_MULTIPLE == TIMER2_PRESET_TIME_DELAY_IN_MULTIPLE
		    //timer2_req_time_delay_in_milli_sec is previous valid req_time_delay_in_milli_sec, which is multiple of set_timer2_req_time_1_update_in_milli_sec
		     tmr2_datas[timer2_cur_run_state ].timer2_req_time_delay_in_milli_sec = set_timer2_req_time_delay_in_milli_sec - timer2_remainder;
		  #else //TIMER2_SET_TIME_DELAY_IN_MULTIPLE == TIMER2_POSTSET_TIME_DELAY_IN_MULTIPLE
		     //timer2_req_time_delay_in_milli_sec is next valid req_time_delay_in_milli_sec, which is multiple of set_timer2_req_time_1_update_in_milli_sec
              tmr2_datas[timer2_cur_run_state ].timer2_req_time_delay_in_milli_sec = set_timer2_req_time_delay_in_milli_sec - timer2_reminder + set_timer2_req_time_1_update_in_milli_sec ;	
          #endif	
	  }
	  timer2_req_time_max_update = tmr2_datas[timer2_cur_run_state ].timer2_req_time_delay_in_milli_sec / set_timer2_req_time_1_update_in_milli_sec;
	  
	  #ifdef TRACE
	     to_disp.unsigned_val.value_long = tmr2_datas[timer2_cur_run_state ].timer2_req_time_delay_in_milli_sec;
	     UART_Transmit_Str("Timer2 start running set for expiry : ");
         UART_Transmit_Num(DISP_UNSIGN_NUM_DIGIT5, to_disp); 
	     UART_Transmit_Str(" millisecs \r"); 
      #endif	
	
    /* for timer2, TMR2 = (65536 - ((timerPeriod_in_sec * Fosc_in_Hertz)/(4*prescaler)) ),  where 2 = TMR2 load time req is 2 Timer Clock cycle */
    // inc_timer2  =      (unsigned long)((unsigned long)(_XTAL_FREQ * set_timer2_tick_in_milli_sec ) / (unsigned long)(OSC_PER_INST * TIME_UNIT_1_SEC_IN_MILLI_SEC  )) 
	inc_timer2 = (_XTAL_FREQ / (OSC_PER_INST * TIME_UNIT_1_SEC_IN_MILLI_SEC)) * set_timer2_tick_in_milli_sec; // for 1000ul = 4MHz / (4 * 1000), when _XTAL_FREQ  = 4MHz  
    timer2_init_val = ((65535UL) - (inc_timer2/timer2_prescale)) + 1 + 2; 
    TMR2 = timer2_init_val;    
}
#endif
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
