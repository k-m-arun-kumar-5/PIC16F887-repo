/* ********************************************************************
FILE                   : lcd16.c

PROGRAM DESCRIPTION    : get input from keypad with decimal point and do multiplication operation

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : NOT YET FINISHED
 
USED                  :              
                             
                       
CHANGE LOGS           : 

*****************************************************************************/ 

#include <xc.8>

#define RS_PIN                               RD0
#define RW_PIN                               RD1
#define EN_PIN                               RD2
#define LCD_PORT                           PORTC
#define BACKSPACE_SW                         RD5

#define BACKSPACE_SW_CODE                    ('B')
#define KEY_PRESSED                              (1) 
#define KEY_NOT_PRESSED                          (0)

#define DISP_FLAG_NUM_DIGIT1                   (1)
#define DISP_FLAG_NUM_DIGIT2                   (2)
#define DISP_FLAG_NUM_DIGIT3                   (3)
#define DISP_FLAG_NUM_DIGIT4                   (4)
#define DISP_FLAG_NUM_DIGIT5                   (5)
#define DISP_FLAG_HEX_DIGIT1                   (6)
#define DISP_FLAG_HEX_DIGIT2                   (7)
#define DISP_FLAG_HEX_DIGIT3                   (8)
#define DISP_FLAG_HEX_DIGIT4                   (9) 

/* for 20 * 4 LCD disp */                             
#define BEGIN_LOC_LINE1                      (0X80)
#define BEGIN_LOC_LINE2                      (0xC0)
#define BEGIN_LOC_LINE3                      (0x94) 
#define BEGIN_LOC_LINE4                      (0xD4)
#define END_LOC_LINE1                        (0x93)
#define END_LOC_LINE2                        (0xD3)
#define END_LOC_LINE3                        (0xA7) 
#define END_LOC_LINE4                        (0xE7)

/* num cols = num of chars in a line */
#define MAX_COUNT_DELAY_TIME_LCDPULSE     (1000U)
#define MAX_AVAIL_NUM_COLS                    (20u)
#define CONFIGURE_MAX_NUM_LINES               (4u)
#define MAX_AVAIL_NUM_LINES                   (4u) 
#define MAX_AVAIL_NUM_CHARS_IN_LCD        (MAX_AVAIL_NUM_COLS * MAX_AVAIL_NUM_LINES) 
#define CONFIGURE_MAX_NUM_COLS             (MAX_AVAIL_NUM_COLS)
#define CONFIGURE_MAX_NUM_CHARS_IN_LCD    (CONFIGURE_MAX_NUM_LINES * CONFIGURE_MAX_NUM_COLS ) 
#define MAX_NUM_CHARS_INPUT_DATA          (MAX_AVAIL_NUM_COLS)  

void Delay_Time_ByCount(unsigned int Delay_Time_Count_count);
void LCD_Init();
void LCD_Pulse ();
void Write_LCD_Command (const unsigned int Write_LCD_Command);
void Write_LCD_Data(const char lcd_disp_ch);
void Data_Str_Disp_LCD(const char *lcd_disp_str);
void Data_Num_Disp_LCD(const unsigned int lcd_datanum_disp_format, const unsigned long lcd_disp_data_int);
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num);
void Goto_XY_LCD_Input(unsigned int start_line_num, unsigned int start_col_num);
void Entered_Key_No_Long_Press_Proc(const char pressed_key);

char entered_cur_input_data[MAX_NUM_CHARS_INPUT_DATA + 1], cur_pressed_key_or_sw = '\0' ;
unsigned int cur_disp_lcd_loc = BEGIN_LOC_LINE1, cur_input_lcd_loc = BEGIN_LOC_LINE2, num_chars_entered_cur_data = 0, cur_data = 0, place_value = 10000ul; 

/*------------------------------------------------------------*
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 1   
-*------------------------------------------------------------*/

void main()
{                               
      TRISA = 0x07;
      PORTA = 0x00;
	  /* to leave T1G pin in portb as input to PIC ie RB5 = 1 in TRISB  to run timer 1, if timer1 conf ie T1CON = (0xC5) was set run timer1. 
        if T1G pin in portb is 0 ie RB5 = 0	in TRISB, even if timer1 is conf ie T1CON = (0xC5) was set to run timer1, timer1 will not run.
        T1G pin is input to PIC to control run Timer1, if gate control for Timer 1 to run is enabled. 
		If T1CON = (0x85),  gate control for Timer 1 is disabled, so T1G pin can have used for other purpose */
	  TRISB = 0x00;
	  PORTB = 0x00;
      TRISC = 0x00;
      PORTC = 0x00;
       TRISD  = 0x78;
       PORTD = 0x00;
       TRISE = 0x00;
       PORTE = 0x00;
       ANSEL = 0x00;
       ANSELH = 0x00;
       LCD_Init();
       Init_Const_Data();
       Reset_Process();
       Run_Timer0();
       for(;;)
       {  
          //Timer0_Tick(); // commited  due to stack overflow and Timer0_Tick() contents are inserted below
		   while(T0IF == 0);
               T0IF = 0;
            TMR0= (256UL) - (INC0/prescale_timer0);
	        if(++num_calls_timer0 >= UPDATE_TIME0)
            {
				num_calls_timer0 = 0; 	
				// Auth_Proc();
               while(key_or_sw_input_enable_flag == STATE_YES)
               { 
                   Is_Numchars_Within_Limit();  
	               KEYPAD_PHONE_ROWA = 1;
                   KEYPAD_PHONE_ROWB  = 0;
                   KEYPAD_PHONE_ROWC  = 0;
                   KEYPAD_PHONE_ROWD  = 0; 
                  if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
                  {
		              cur_pressed_key_or_sw = keypad_char[0];//latest pressed key/switch					 
		             if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                     {
						Stoke_Rcvd_Tmr1_Long_Press_Proc(); 						
                         while(KEYPAD_PHONE_COL1 ==KEY_PRESSED)
		                 {
			               Check_Long_Pressed_Key();
                           if(timeout_long_pressed_key_flag == STATE_YES)
                           {
			            		break;
                           }                  
		                }
			            After_Key_Stoke_Proc(cur_pressed_key_or_sw);					
		            } 		  
                 }
                 if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
                 {
		             cur_pressed_key_or_sw = keypad_char[1];//latest pressed key/switch
					 if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                     {
		            	 Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
                         while(KEYPAD_PHONE_COL2 ==KEY_PRESSED)
		                 {
		            	    Check_Long_Pressed_Key();
                           if(timeout_long_pressed_key_flag == STATE_YES)
                           {
			         	    	break;
                           }                  
		                 }
			            After_Key_Stoke_Proc(cur_pressed_key_or_sw);					
		             } 		  
                  } 
                 if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
                 {
	        	     cur_pressed_key_or_sw = keypad_char[2];//latest pressed key/switch					
	        	     if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                     {
		            	 Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
                         while(KEYPAD_PHONE_COL3 ==KEY_PRESSED)
		                 {
			                 Check_Long_Pressed_Key();
                            if(timeout_long_pressed_key_flag == STATE_YES)
                            {
			            		break;
                            }                  
		                 }
		             	After_Key_Stoke_Proc(cur_pressed_key_or_sw);				
		             } 		  
                  } 
                  KEYPAD_PHONE_ROWA = 0;
                  KEYPAD_PHONE_ROWB  = 1;
                  KEYPAD_PHONE_ROWC  = 0;
                  KEYPAD_PHONE_ROWD  = 0; 
                 if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
                  {
		              cur_pressed_key_or_sw = keypad_char[3];//latest pressed key/switch					  
		             if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                     {
		            	Stoke_Rcvd_Tmr1_Long_Press_Proc();  
                        while(KEYPAD_PHONE_COL1 ==KEY_PRESSED)
		                {
			               Check_Long_Pressed_Key();
                          if(timeout_long_pressed_key_flag == STATE_YES)
                          {
			            		break;
                          }                  
		               }
			           After_Key_Stoke_Proc(cur_pressed_key_or_sw);					
		             } 		  
                  } 
                  if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
                  {
	       	           cur_pressed_key_or_sw = keypad_char[4];//latest pressed key/switch					  
                      if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                      {
		              	Stoke_Rcvd_Tmr1_Long_Press_Proc();  
                         while(KEYPAD_PHONE_COL2 ==KEY_PRESSED)
		                 {
		    	             Check_Long_Pressed_Key();
                            if(timeout_long_pressed_key_flag == STATE_YES)
                            {
		    	        		break;
                            }                  
		                 }
		    	        After_Key_Stoke_Proc(cur_pressed_key_or_sw);					
		             } 		  
                   } 
                  if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
                  {
	            	  cur_pressed_key_or_sw = keypad_char[5];//latest pressed key/switch					  
	            	  if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                      {
		            	 Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
                        while(KEYPAD_PHONE_COL3 ==KEY_PRESSED)
		                {
		            	    Check_Long_Pressed_Key();
                            if(timeout_long_pressed_key_flag == STATE_YES)
                            {
		            			break;
                            }                  
		                }
		            	After_Key_Stoke_Proc(cur_pressed_key_or_sw);						
		             } 		  
                  }  
                  KEYPAD_PHONE_ROWA = 0;
                  KEYPAD_PHONE_ROWB  = 0;
                  KEYPAD_PHONE_ROWC  = 1;
                  KEYPAD_PHONE_ROWD  = 0; 
                 if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
                 {
	            	  cur_pressed_key_or_sw = keypad_char[6];//latest pressed key/switch
					  if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                      {
		             	 Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
                         while(KEYPAD_PHONE_COL1 ==KEY_PRESSED)
		                 {
		             	    Check_Long_Pressed_Key();
                           if(timeout_long_pressed_key_flag == STATE_YES)
                           {
		    	        		break;
                           }                  
	                     }
		               	After_Key_Stoke_Proc(cur_pressed_key_or_sw);					
		              } 		  
                  } 
                  if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
                  {
	            	  cur_pressed_key_or_sw = keypad_char[7];//latest pressed key/switch					 
	            	  if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                      {
	            		 Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
                         while(KEYPAD_PHONE_COL2 ==KEY_PRESSED)
	               	     {
	            		    Check_Long_Pressed_Key();
                           if(timeout_long_pressed_key_flag == STATE_YES)
                           {
	            				break;
                           }                  
	            	    }
	             		After_Key_Stoke_Proc(cur_pressed_key_or_sw);					
	            	  } 		  
                   } 
                   if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
                   {
	              	  cur_pressed_key_or_sw = keypad_char[8];//latest pressed key/switch
	          	      if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                      {
	        	    	 Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
                         while(KEYPAD_PHONE_COL3 ==KEY_PRESSED)
	         	         {
	        	    	    Check_Long_Pressed_Key();
                            if(timeout_long_pressed_key_flag == STATE_YES)
							{	
 		    			         break;
                            }                  
						 }
		                 After_Key_Stoke_Proc(cur_pressed_key_or_sw);					
		               } 		  
                    } 
                    KEYPAD_PHONE_ROWA = 0;
                    KEYPAD_PHONE_ROWB  = 0;
                     KEYPAD_PHONE_ROWC  = 0;
                    KEYPAD_PHONE_ROWD  = 1; 
                    if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
                    {
	             	   cur_pressed_key_or_sw = keypad_char[9];//latest pressed key/switch
					   
	             	  if(keypad_keys_enable_flag == STATE_YES && cur_data_can_also_input_nonnum_key == STATE_YES&& max_input_num_chars_flag ==STATE_NO )
                      {
	            		 Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
                         while(KEYPAD_PHONE_COL1 ==KEY_PRESSED)
		                 {
		             	    Check_Long_Pressed_Key();
                            if(timeout_long_pressed_key_flag == STATE_YES)
                            {
		             			break;
                           }                  
	            	     }
		             	 After_Key_Stoke_Proc(cur_pressed_key_or_sw);					
		               } 		  
                     } 
                     if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
                      {
		                 cur_pressed_key_or_sw = keypad_char[10];//latest pressed key/switch
						
		                 if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                         {
		                	Stoke_Rcvd_Tmr1_Long_Press_Proc();  
                             while(KEYPAD_PHONE_COL2 ==KEY_PRESSED)
		                     {
		                	    Check_Long_Pressed_Key();
                                if(timeout_long_pressed_key_flag == STATE_YES)
                                {
		                   			break;
                                 }                  
	                         }
		                	After_Key_Stoke_Proc(cur_pressed_key_or_sw);				
		                  } 		  
                       }                                               
                       if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
                       {
	                  	  cur_pressed_key_or_sw = keypad_char[11];//latest pressed key/switch
						  
	                   	  if(keypad_keys_enable_flag == STATE_YES && cur_data_can_also_input_nonnum_key == STATE_YES && max_input_num_chars_flag ==STATE_NO )
                          {
	                  		 Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
                             while(KEYPAD_PHONE_COL3 ==KEY_PRESSED)
		                     {
		                  	    Check_Long_Pressed_Key();
                                 if(timeout_long_pressed_key_flag == STATE_YES)
                                {
		                			break;
                                }                  
	                        }
		                	After_Key_Stoke_Proc(cur_pressed_key_or_sw);					
		                  } 		  
                        }    
    
                        if(ENTER_SW == KEY_PRESSED)
                        {
	                    	 cur_pressed_key_or_sw = ENTER_SW_CODE;//latest pressed key/switch
							 if(enter_sw_enable_flag == STATE_YES)
							 {	 
	                    	    Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
	                    	    max_input_num_chars_flag = STATE_NO;
								
                                while(ENTER_SW == KEY_PRESSED )
                                { 
                                   Check_Long_Pressed_Key();
                                   if(timeout_long_pressed_key_flag == STATE_YES)
                                   {                                    
                                       break;
                                   }                  
		                        }
		                        After_Switch_Stoke_Proc(cur_pressed_key_or_sw); 	      		 
                             }
						}							 
                         if(BACKSPACE_SW ==KEY_PRESSED )		 
                         {
                            cur_pressed_key_or_sw = BACKSPACE_SW_CODE;//latest pressed key/switch
						   	if(backspace_sw_enable_flag == STATE_YES)
						    {
						        Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
                                while(BACKSPACE_SW == KEY_PRESSED ) 
	                            {    
                                   Check_Long_Pressed_Key();
                                    if(timeout_long_pressed_key_flag == STATE_YES)  
						            {     
                  	  		            break;
                                    }                              
		                        }
		                        After_Switch_Stoke_Proc(cur_pressed_key_or_sw); 
                             }					  
                         }
                         if(ACCOUNT_SW ==KEY_PRESSED )		 
                         {
                            cur_pressed_key_or_sw = ACCOUNT_SW_CODE;//latest pressed key/switch
						   	if(account_sw_enable_flag == STATE_YES)
						    {					
                                
						       Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
                                while(ACCOUNT_SW == KEY_PRESSED ) 
	                            {    
                                    Check_Long_Pressed_Key();
                                    if(timeout_long_pressed_key_flag == STATE_YES)  
						            {     
                  	  		            break;
                                    }                              
		                        }
		                        After_Switch_Stoke_Proc(cur_pressed_key_or_sw); 
                             }					  
                         }						 
						if(status_disp_fsm != INITIAL && cur_line_disp_data[ALL_LINES] == ANY_DATA_DISP )
                        { 
	  	                   Disp_Status_Fsm(); 
		                   cur_line_disp_data[ALL_LINES] = AUTH_STATUS_DISP;     
                        } 
			 	        if(need_input_flag == STATE_YES && detect_presskey_flag != STATE_YES)
                        { 
                            Check_No_Key_Press();            
                        }
                    }                    
                   if(RESET_SW ==KEY_PRESSED )
                   {
	                  cur_pressed_key_or_sw = RESET_SW_CODE;//latest pressed key/switch
					  if(reset_sw_enable_flag == STATE_YES)
					  {	  
	                      Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
                          while(RESET_SW == KEY_PRESSED ) 
	                      {  
                 	          Check_Long_Pressed_Key();
                              if(timeout_long_pressed_key_flag == STATE_YES)  
		                      {                   	  		 
                                    break;
                               } 		   
	                      }
                          After_Switch_Stoke_Proc(cur_pressed_key_or_sw);	
					  }							
                   }		
              } 
	    }	  
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 30   
-*------------------------------------------------------------*/ 
void Goto_XY_LCD_Input(unsigned int start_line_num,unsigned int start_col_num)
{
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1; 
	
	/* max 4 lines and 20 columns */
	lcd_avail_loc_within_limit = STATE_YES;
	if( start_line_num <= CONFIGURE_MAX_NUM_LINES &&  start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
     switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_input_lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   cur_input_lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   cur_input_lcd_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   cur_input_lcd_loc = BEGIN_LOC_LINE4;
		   break; 		  
	 }
	 cur_input_lcd_loc = cur_input_lcd_loc + start_col_lcd;
     Write_LCD_Command(cur_input_lcd_loc); 	 	   
  }
  else
  {
	   /* error due to invalid Lcd loc  */	
	   lcd_avail_loc_within_limit = STATE_NO;
	  // Error_or_Warning_Proc("30.01", FATAL_OCCURED, ERR_CUR_INPUT_LOC_CODE);
	  
  }	  
} 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 29   
-*------------------------------------------------------------*/
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num)
{
	/* max 4 lines and 20 columns */
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1, error_disp_start_loc; 
	lcd_avail_loc_within_limit = STATE_YES;
	
   if(start_line_num <= CONFIGURE_MAX_NUM_LINES && start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
      switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE4;
		   break;		 
	 }	
      cur_disp_lcd_loc = cur_disp_lcd_loc + start_col_lcd;
      Write_LCD_Command(cur_disp_lcd_loc);       
   }
   else
   {
	   /* error due to invalid lcd DISP loc  */
	     lcd_avail_loc_within_limit = STATE_NO;		
		// Error_or_Warning_Proc("29.01", FATAL_OCCURED, ERR_CUR_DISP_LOC_CODE);        		
   }	   
} 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 43   
-*------------------------------------------------------------*/
void Goto_XY_LCD_Disp_Err(const unsigned int start_line_num, const unsigned int start_col_num)
{
	/* max 4 lines and 20 columns */
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1, error_disp_start_loc; 
	lcd_avail_loc_within_limit = STATE_YES;
	
   if(start_line_num <= MAX_AVAIL_NUM_LINES && start_col_num <= MAX_AVAIL_NUM_COLS )
   {
      switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE4;
		   break;		 
	 }	
      cur_disp_lcd_loc = cur_disp_lcd_loc + start_col_lcd;
      Write_LCD_Command(cur_disp_lcd_loc);       
   }
   else
   {
	   /* ERROR: loc exceeds max avail loc in lcd*/
   }
} 
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 33   
-*------------------------------------------------------------*/
/* process to to do when a error or warning has occured */
void Error_or_Warning_Proc(const char *error_trace, const unsigned int warn_or_error_format, const unsigned int warning_or_error_data)
{
	 error_or_warning_code |= warning_or_error_data; 
     INTERNAL_ERROR_LED_PIN = LED_ON;	
	 
	 if(disp_status_time_or_error[ERROR_STATUS_DISP_INDEX] == STATUS_DISP_ON )
	 {
        Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, NUM_COL1);
		Data_Str_Disp_LCD(error_trace);		
		Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, start_col_blank_space);
		Write_LCD_Data(' ');
		Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, start_col_error_code);
		Data_4Digit_Hex_Disp_LCD(error_or_warning_code);		
	 }
	switch(warn_or_error_format)
	{
		case WARNING_OCCURED:	
         if(disp_status_time_or_error[ERROR_STATUS_DISP_INDEX] == STATUS_DISP_ON )
	     { 
		    Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, start_col_error_msg);			   
	        Data_Str_Disp_LCD(warning_msg_disp);
			cur_line_disp_data[ERROR_LINE_NUM] = WARNING_DISP;	
            internal_error_state = WARNING_OCCURED;			
		 }	
		 /*warning occured, process to do  */
        break;
		case ERROR_OCCURED:
		  if(disp_status_time_or_error[ERROR_STATUS_DISP_INDEX] == STATUS_DISP_ON )
	      { 
		    Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, start_col_error_msg);		   
	        Data_Str_Disp_LCD(error_msg_disp);
			cur_line_disp_data[ERROR_LINE_NUM] = ERROR_DISP;
			internal_error_state = ERROR_OCCURED;	
		  }	
		  /*error occured, process to do  */
		break;
        case FATAL_OCCURED:	            
		if(disp_status_time_or_error[ERROR_STATUS_DISP_INDEX] == STATUS_DISP_ON )
	     { 
		    Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, start_col_error_msg);			   
	        Data_Str_Disp_LCD(fatal_msg_disp);
			internal_error_state = FATAL_OCCURED;	
			cur_line_disp_data[ERROR_LINE_NUM] = FATAL_DISP;
		 }	  
		 /* fatal error occured, process to do  */ 
		break;
        default:
         ;
         /* warning invalid error or warning format*/			    
	}
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void LCD_Init()
{
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x38);
    Write_LCD_Command(0x01);
    Write_LCD_Command(0x0E); //insert cursor on at cur_input_lcd_loc
	//Write_LCD_Command(0x0C);
    Write_LCD_Command(0x06);                                       
}     

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 23   
-*------------------------------------------------------------*/
  void Write_LCD_Command (unsigned int cmd)
  {
	  unsigned long int  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  
       RW_PIN = 0;
       RS_PIN = 0; 
       LCD_PORT = cmd;
      // LCD_Pulse();
	  EN_PIN = 1;
	  while(time_delay--);
    // Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
      EN_PIN = 0;
	  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  while(time_delay--);
   //  Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
 }
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 24   
-*------------------------------------------------------------*/
 void Write_LCD_Data(const char ch)
{
	unsigned long int  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	// performance degraded if many data is written to LCD, to check if write loc is within avail disp loc
	// if(lcd_avail_loc_within_limit == STATE_YES) 
	{	
      RW_PIN = 0;
      RS_PIN = 1;
      LCD_PORT =ch;
     // LCD_Pulse();
      EN_PIN = 1;
	  while(time_delay--);
    // Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
     EN_PIN = 0;
	 time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  while(time_delay--);
   //  Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);	 
	}
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 25   
-*------------------------------------------------------------*/

void Data_Str_Disp_LCD(const char *char_ptr)
{ 
       while(*char_ptr)
       {
            Write_LCD_Data(*(char_ptr++));
       }
     
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 27  
-*------------------------------------------------------------*/
void Delay_Time_ByCount( unsigned int time_delay)
{
       while(time_delay--);
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 26  
-*------------------------------------------------------------*/
void Data_Num_Disp_LCD(const unsigned int lcd_datanum_disp_format, const unsigned long lcd_disp_data_int)
{
    unsigned int tens_thousand_digit,thousands_digit, hundreds_digit,tens_digit, unit_digit;
    unsigned long num = lcd_disp_data_int;
    char num_data[] ={'0','1','2','3','4','5','6','7','8','9'};  
	char hex_data[] ={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'}; 
    switch(lcd_datanum_disp_format)
	{
	  case DISP_FLAG_NUM_DIGIT5: 
		  num =  lcd_disp_data_int % 100000;
		  tens_thousand_digit = (unsigned int)(num / (unsigned long)(10000));
          Write_LCD_Data(num_data[tens_thousand_digit]);
	  case DISP_FLAG_NUM_DIGIT4:
	      num = lcd_disp_data_int % 10000;
	      thousands_digit = (unsigned int)(num / (unsigned long)(1000));
	      Write_LCD_Data(num_data[thousands_digit]); 
	  case DISP_FLAG_NUM_DIGIT3: 
		  num = lcd_disp_data_int % 1000;
	      hundreds_digit = (unsigned int) (num / (unsigned long) (100));
	      Write_LCD_Data(num_data[hundreds_digit]);
	  case DISP_FLAG_NUM_DIGIT2:
          num = lcd_disp_data_int % 100;
          tens_digit = (unsigned int) (num / 10);
          Write_LCD_Data(num_data[tens_digit]); 		  
	  case DISP_FLAG_NUM_DIGIT1:
	     unit_digit = (unsigned int) (lcd_disp_data_int % 10);
         Write_LCD_Data(num_data[unit_digit]); 
	  break;
	  case DISP_FLAG_HEX_DIGIT4:
	      /*  ( 16 * 16 * 16 *16 )  = 0 as divide by zero warning */
	      //num = lcd_disp_data_int % ( 16 * 16 * 16 *16 );
          thousands_digit = (num / (16 * 16 * 16));
	      Write_LCD_Data(hex_data[thousands_digit]);
	  case DISP_FLAG_HEX_DIGIT3:
	      num = lcd_disp_data_int %(unsigned long)(16 * 16 * 16);
	      hundreds_digit = (unsigned int) (num / (unsigned long) (16 * 16));
	      Write_LCD_Data(hex_data[hundreds_digit]);
	  case DISP_FLAG_HEX_DIGIT2:
	      num = lcd_disp_data_int %(unsigned long)(16 * 16);
          tens_digit = (unsigned int) (num / 16);
          Write_LCD_Data(hex_data[tens_digit]);
	  case DISP_FLAG_HEX_DIGIT1: 
	      unit_digit = (unsigned int) (lcd_disp_data_int % 16);
          Write_LCD_Data(hex_data[unit_digit]);    
	  break;
	  default:
	     Error_or_Warning_Proc("26.01", WARNING_OCCURED, ERR_LCD_DISP_NUM_FORMAT_CODE);
		     /* Warning invalid lcd_disp flag */
	    ;
	}   	
}
 
