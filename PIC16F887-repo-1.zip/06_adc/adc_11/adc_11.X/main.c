/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    :  when EXTR_INTP_SW is pressed on for odd number of times, then ADC starts conversion for channel 0 and 
when EXTR_INTP_SW is  pressed on for even number of times, then  ADC starts conversion for channel 1.  
After ADC conversion is over and then after time delay for specific time duration, ADC is ready to start next conversion.
use ADC interrupt, Timer1 overflow interrupt and external interrupt and use 2 different potentiometer, which as act as sensor.
 Each potentiometer analog value corresponding digital value representive ie if analog value is 5V then Digital value  = 5V.
and display in percentage in terms of max digital value ie if analog value = 5.0 V, then Digital value  = 5V and percentage = 100%.
Use internal  Vref+ and Vref- to ADC channel 0 and external Vref+ and Vref- to ADC channel 1.
                     									 	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 												
                       
                       
CHANGE LOGS           : 

*****************************************************************************/

#include "main.h"
#include "port.h"
#include "timer.h"
#include "adc.h"
#include "lcd.h"
#include "uart.h"

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.
// 'C' source line config statements
#pragma config FOSC = XT    // Oscillator Selection bits (XT oscillator)
#pragma config WDTE = OFF   // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF  // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = OFF  // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = OFF    // Low-Voltage In-Circuit Serial Programming Enable bit
#pragma config CPD = OFF    // Data EEPROM Memory Code Protection bit
#pragma config WRT = OFF    // Flash Program Memory Write Enable bits
#pragma config CP = OFF     // Flash Program Memory Code Protection bit

void LCD_Const_Disp();
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void main()
{	
   LCD_PORT_GPIO = 0x00;
   LCD_PORT = 0x00;   
   TRISE = 0x00;
   PORTE = 0x00;
   TRISBbits.TRISB2 = 0;
   TRISBbits.TRISB3 = 0;
   TRISBbits.TRISB4 = 0;
   ANSEL = 0b00000011;
   ANSELH = 0x00;  
    
   /* commited due to stack overflow  */
   /* LCD_Init(); 	
   LCD_Const_Disp(); */
   UART_Init();
   
   ADC_READY_LED = LED_ON;
   ADC_CH0_PROC_OVER_LED  = LED_ON;
   TIME_WAIT_LED = LED_OFF; 
   
   #ifdef TRACE
     UART_Transmit_Str("GIE & INTE interrupt enabled \r");
   #endif
   INTCONbits.INTE = 1; //Enables the INT pin external interrupt
   INTCONbits.GIE = 1;  //Enables all unmasked interrupts    
  
   while(1)
   {
      	   
   }   
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void LCD_Const_Disp()
{
	const char signal_rep_disp[] = "V";
	
	Goto_XY_LCD_Disp(NUM_LINE1, NUM_COL1);
	Data_Str_Disp_LCD("ADC Channel 0 Output");	       
    Goto_XY_LCD_Disp(NUM_LINE3, NUM_COL1);
	Data_Str_Disp_LCD("ADC Channel 1 Output");
	Goto_XY_LCD_Disp(SIGCH0_LINE_NUM,SIGNAL_DECPT_COL_NUM );
	Write_LCD_Data('.');
	Goto_XY_LCD_Disp(SIGCH1_LINE_NUM,SIGNAL_DECPT_COL_NUM);
	Write_LCD_Data('.');
    Goto_XY_LCD_Disp(SIGCH0_LINE_NUM,SIGNAL_DISP_COL_NUM);
	Data_Str_Disp_LCD(signal_rep_disp);	
	Goto_XY_LCD_Disp(SIGCH1_LINE_NUM,SIGNAL_DISP_COL_NUM );
	Data_Str_Disp_LCD(signal_rep_disp);	
	Goto_XY_LCD_Disp(SIGCH0_LINE_NUM,PERCENT_DECPT_COL_NUM);
	Write_LCD_Data('.');
    Goto_XY_LCD_Disp(SIGCH1_LINE_NUM,PERCENT_DECPT_COL_NUM);
	Write_LCD_Data('.');
	Goto_XY_LCD_Disp(SIGCH0_LINE_NUM,PERCENT_DISP_COL_NUM);
	Write_LCD_Data('%');
	Goto_XY_LCD_Disp(SIGCH1_LINE_NUM,PERCENT_DISP_COL_NUM);
	Write_LCD_Data('%');
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
