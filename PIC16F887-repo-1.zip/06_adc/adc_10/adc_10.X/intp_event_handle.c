/**************************************************************************
   FILE          :    intp_event_Handle.c
 
   PURPOSE       :  interrupt Event Handler Library
 
   AUTHOR        :    K.M.Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #include "main.h"
 #include "port.h"
 #include "lcd.h"
 #include "uart.h"
 #include "adc.h"
 #include "io_conf.h"
 #include "appl_conf.h" 

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void External_Interrupt_Occured_Appl_Proc()
{	
   
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void Timer1_Req_Time_Expiry_Appl_Proc()
{	
    
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void ADC_Conv_Over_Appl_Proc(unsigned long adc_value_channel)
{	
    static unsigned int num_adc_conv_over_occured = 0;
    unsigned long analog_val_in_digital_int_ch[2], analog_val_in_digital_frac_ch[2];
	unsigned int percent_int_ch[2], percent_frac_ch[2];	
		
	ADC_READY_LED = LED_ON;		 
	 #ifdef TRACE
        UART_Transmit_Str("ADC_READY LED is ON \r");
     #endif	
	switch(adc_cur_channel)
	{
	          case ADC_CH_00:
	             ADC_CH0_PROC_OVER_LED  = LED_ON;
				 #ifdef TRACE
                    UART_Transmit_Str("ADC_CH0_PROC_OVER_LED is ON \r");
                 #endif
	             analog_val_in_digital_ch[0] = adc_value_channel;
	             Encoded_To_Actual_Analog_Val_Calc(analog_val_in_digital_ch[0], FULL_SCALE_ANALOG_VAL_CH0, MIN_ANALOG_VALUE_CH0,\
		            &analog_val_in_digital_int_ch[0],&analog_val_in_digital_frac_ch[0] );
		         UART_Transmit_Str("ADC Channel 0 Output : "); 
	             //Goto_XY_LCD_Disp(SIGCH0_LINE_NUM, NUM_COL1);
	             UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, analog_val_in_digital_int_ch[0]);
		         UART_Transmit_Char('.');
	             //Goto_XY_LCD_Disp(SIGCH0_LINE_NUM, SIGNAL_FRAC_COL_NUM);
	             UART_Transmit_Num(DISP_FLAG_NUM_DIGIT1, analog_val_in_digital_frac_ch[0]);
		         UART_Transmit_Str("V , ");
		  
	             Encoded_To_Percent_Calc(analog_val_in_digital_ch[0],&percent_int_ch[0],&percent_frac_ch[0] );
	             //Goto_XY_LCD_Disp(SIGCH0_LINE_NUM, PERCENT_INT_COL_NUM);
	             UART_Transmit_Num(DISP_FLAG_NUM_DIGIT3,percent_int_ch[0] );
		         UART_Transmit_Char('.');
	             //Goto_XY_LCD_Disp(SIGCH0_LINE_NUM, PERCENT_FRAC_COL_NUM);
	             UART_Transmit_Num(DISP_FLAG_NUM_DIGIT1,percent_frac_ch[0] );
		         UART_Transmit_Str("% \r");
	          break;
              case ADC_CH_01: 
	             analog_val_in_digital_ch[1] = adc_value_channel;
	     
	             Encoded_To_Actual_Analog_Val_Calc(analog_val_in_digital_ch[1], FULL_SCALE_ANALOG_VAL_CH1, MIN_ANALOG_VALUE_CH1,\
		            &analog_val_in_digital_int_ch[1],&analog_val_in_digital_frac_ch[1] );
		         UART_Transmit_Str("ADC Channel 1 Output : "); 
	             //Goto_XY_LCD_Disp(SIGCH1_LINE_NUM, NUM_COL1);
	             UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, analog_val_in_digital_int_ch[1]);
		         UART_Transmit_Char('.');
	             //Goto_XY_LCD_Disp(SIGCH1_LINE_NUM, SIGNAL_FRAC_COL_NUM);
	             UART_Transmit_Num(DISP_FLAG_NUM_DIGIT1, analog_val_in_digital_frac_ch[1]);
		         UART_Transmit_Str("V , ");
		  
	             Encoded_To_Percent_Calc(analog_val_in_digital_ch[1],&percent_int_ch[1],&percent_frac_ch[1] );
	             //Goto_XY_LCD_Disp(SIGCH1_LINE_NUM, PERCENT_INT_COL_NUM);
	             UART_Transmit_Num(DISP_FLAG_NUM_DIGIT3,percent_int_ch[1] );
		         UART_Transmit_Char('.');
	             //Goto_XY_LCD_Disp(SIGCH1_LINE_NUM, PERCENT_FRAC_COL_NUM);
	             UART_Transmit_Num(DISP_FLAG_NUM_DIGIT1,percent_frac_ch[1] );
		         UART_Transmit_Str("% \r");
              break;  
              default:         
            	#ifdef TRACE_ERROR
		           UART_Transmit_Str("ERR: invalid ADC channel : ");
		           UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, adc_cur_channel);
		           UART_Transmit_Char('\r');
		        #endif	
	}  
	 ADC_READY_LED = LED_OFF;
     #ifdef TRACE
        UART_Transmit_Str("ADC_READY LED is OFF \r");
     #endif		
	if(++num_adc_conv_over_occured % 2 == 1)
    {
		ADC_Start_Conv(ADC_INTP_SERVICE, ADC_CLK_SRC_OSC_32, ADC_CHANNEL_SEL, ADC_CH_01, ADC_RESULT_RIGHT_FMT, ADC_VREF_NEG_SRC_EXTR, ADC_VREF_PLUS_SRC_EXTR); 
	}
    else
	{
		ADC_CH0_PROC_OVER_LED  = LED_OFF;
		#ifdef TRACE
           UART_Transmit_Str("ADC_CH0_PROC_OVER_LED is OFF \r");
        #endif	
		ADC_Start_Conv(ADC_INTP_SERVICE, ADC_CLK_SRC_OSC_32, ADC_CHANNEL_SEL, ADC_CH_00, ADC_RESULT_RIGHT_FMT, ADC_VREF_NEG_SRC_INTR, ADC_VREF_PLUS_SRC_INTR); 
	}
   
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
