/**************************************************************************
   FILE          :    appl_conf.h
 
   PURPOSE       :   main application configuration Header
 
   AUTHOR        :    K.M.Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _APPL_CONF_H
 #define _APPL_CONF_H 
 
/*------------------------------- LCD disp conf ------------------------------------------*/

#define SIGCH0_LINE_NUM           (NUM_LINE2)
#define SIGCH1_LINE_NUM           (NUM_LINE4)
#define SIGNAL_DECPT_COL_NUM      (NUM_COL1 + 4)
#define SIGNAL_FRAC_COL_NUM       (SIGNAL_DECPT_COL_NUM + 1)
#define SIGNAL_DISP_COL_NUM       (SIGNAL_FRAC_COL_NUM + 1)    
#define PERCENT_INT_COL_NUM       (SIGNAL_DISP_COL_NUM + 4)
#define PERCENT_DECPT_COL_NUM     (PERCENT_INT_COL_NUM + 3)
#define PERCENT_FRAC_COL_NUM      (PERCENT_DECPT_COL_NUM + 1) 
#define PERCENT_DISP_COL_NUM      (PERCENT_FRAC_COL_NUM + 2) 

/* -------------------------------Timer state conf ---------------------------------------*/


/* ---------------------------------- ADC input signal val conf -------------------------- */

#define MAX_ANALOG_VALUE_CH0           (5U)
#define MIN_ANALOG_VALUE_CH0           (0U)
#define FULL_SCALE_ANALOG_VAL_CH0     (MAX_ANALOG_VALUE_CH0 - MIN_ANALOG_VALUE_CH0)

/* external Vref+ pin voltage = MAX_ANALOG_VALUE_CH1 and  external Vref- pin voltage = MIN_ANALOG_VALUE_CH1 */
#define MAX_ANALOG_VALUE_CH1           (4U)  
#define MIN_ANALOG_VALUE_CH1           (0U)
#define FULL_SCALE_ANALOG_VAL_CH1     (MAX_ANALOG_VALUE_CH1 - MIN_ANALOG_VALUE_CH1)

/* ------------------------------- application conf --------------------------------------*/


#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
