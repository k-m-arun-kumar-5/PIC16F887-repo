/* ********************************************************************
FILE                   : eeprom5.c

PROGRAM DESCRIPTION    : A varible num of digits of a number is  fed by keypad and then ENTER_SW is pressed. Enter_SW terminates input
 and last 3 digits entered is saved in EEPROM. When power reboots occurs at any time, same state is retained and resume from that
state. Last X digits, where 1 <= X <= 4, can be configured by MACRO defination. NOTE: Entered number is stored in RAM and EEPROM in big endian format by our implementation, last digits is stored in each EEPROM and each RAM in little endian format by our implementation,
 and  last digits is stored in EEPROMs and RAMs in big endian format by our implementation. 
 eg num entered = 12345, then in ram_num_in_mul_4digits[0] = 1234 and ram_num_in_mul_4digits[1]= 5000 
and eeprom_num_in_mul_2digit[0] = 12, eeprom_num_in_mul_2digit[1] = 34, eeprom_num_in_mul_2digit[2] = 50, eeprom_num_in_mul_2digit[3] = 00
and if NUM_LAST_DIGITS = 3, then last 3 digits of num entered = 345, then eeprom_last_digits[0] = 03 and eeprom_last_digits[1] = 45 and ram_last_digits[0] = 0345 and remove leading zeros,
EEPROM_LAST_DIGITS_ADDR + 0 = (0X00) = addr of data = eeprom_last_digits[0] and EEPROM_LAST_DIGITS_ADDR + 1 =(0X01) = addr of data = eeprom_last_digits[1]

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : to check  for power off and then power on simulation in proteus ( press button - stop simulation,
  then press button - advanced simulation by one frame )and then press button - run simulation 
                                  
                       
CHANGE LOGS           : 

*****************************************************************************/  

//#define HI_TECH_COMPILER
#ifdef HI_TECH_COMPILER
  #include <pic.h>
  __CONFIG(0x2CE4);
#else // XC8 compiler
  #include <xc.h>
#endif
#include <string.h>
#define KEY_PRESSED                              (1) 
#define KEY_NOT_PRESSED                          (0)
#define STATE_YES                                 'y'
#define STATE_NO                                  'n'

#define MAX_ROW_KEYPAD                         4
#define MAX_COL_KEYPAD                         3
#define  KEYPAD_PHONE_COL1                    RB0
#define  KEYPAD_PHONE_COL2                    RB1
#define  KEYPAD_PHONE_COL3                    RB2
#define  KEYPAD_PHONE_ROWA                    RB3
#define  KEYPAD_PHONE_ROWB                    RB4
#define  KEYPAD_PHONE_ROWC                    RB5
#define  KEYPAD_PHONE_ROWD                    RB6

#define RS_PIN                                 RD0
#define RW_PIN                                 RD1
#define EN_PIN                                 RD2
#define LCD_PORT                              PORTC

#define ENTER_SW                               RA0
#define BACKSPACE_SW                           RA1 
#define DISP_SW                                RA2
#define RESET_SW                               RA3                                                     


#define UNIT_PLACE_VALUE                       (1UL)
#define TENS_PLACE_VALUE                       (10UL)
#define HUNDREDS_PLACE_VALUE                   (100UL)
#define THOUSANDS_PLACE_VALUE                  (1000UL)
#define TEN_THOUSANDS_PLACE_VALUE              (10000UL)
                
#define DISP_FLAG_NUM_DIGIT1                   (1)
#define DISP_FLAG_NUM_DIGIT2                   (2)
#define DISP_FLAG_NUM_DIGIT3                   (3)
#define DISP_FLAG_NUM_DIGIT4                   (4)
#define DISP_FLAG_NUM_DIGIT5                   (5)
#define DISP_FLAG_HEX_DIGIT1                   (6)
#define DISP_FLAG_HEX_DIGIT2                   (7)
#define DISP_FLAG_HEX_DIGIT3                   (8)
#define DISP_FLAG_HEX_DIGIT4                   (9) 

/* for 20 * 4 LCD disp */                             
#define BEGIN_LOC_LINE1                      (0X80)
#define BEGIN_LOC_LINE2                      (0xC0)
#define BEGIN_LOC_LINE3                      (0x94) 
#define BEGIN_LOC_LINE4                      (0xD4)
#define END_LOC_LINE1                        (0x93)
#define END_LOC_LINE2                        (0xD3)
#define END_LOC_LINE3                        (0xA7) 
#define END_LOC_LINE4                        (0xE7)

/* num cols = num of chars in a line */
#define MAX_COUNT_DELAY_TIME_LCDPULSE       (1000UL)
#define MAX_AVAIL_NUM_COLS                    (20)
#define CONFIGURE_MAX_NUM_LINES               (4)
#define MAX_AVAIL_NUM_LINES                   (4) 
#define MAX_AVAIL_NUM_CHARS_IN_LCD        (MAX_AVAIL_NUM_COLS * MAX_AVAIL_NUM_LINES) 
#define CONFIGURE_MAX_NUM_COLS             (MAX_AVAIL_NUM_COLS)
#define CONFIGURE_MAX_NUM_CHARS_IN_LCD    (CONFIGURE_MAX_NUM_LINES * CONFIGURE_MAX_NUM_COLS ) 

#define EACH_RAM_UNITS_POS                  (0U)
#define EACH_RAM_THOUSANDS_POS              (1U)
#define EACH_RAM_HUNDREDS_POS               (2U)
#define EACH_RAM_TENS_POS                   (3U) 

#define EEPROM_TO_RAM_PART1                 (0U)
#define EEPROM_TO_RAM_PART2                 (1U)  

#define MAX_NUM_CHARS_INPUT_DATA          (7U)  
#define ASCII_CODE_ZERO_CHAR              (0x30u)

#define EACH_EEPROM_NUM_IN_2DIGIT         (2U)
#define EACH_RAM_NUM_IN_4DIGIT            (4U) 
#define EACH_EEPROM_FACTOR_IN_EACH_RAM    (EACH_RAM_NUM_IN_4DIGIT /EACH_EEPROM_NUM_IN_2DIGIT)

#define LAST_4DIGITS                      (4U)
#define LAST_3DIGITS                      (3U)
#define LAST_2DIGITS                      (2U)
#define LAST_1DIGIT                       (1U)

#define MAX_ELEMENTS_LAST_DIGITS_EEPROM_IN_2DIGITS     ( LAST_4DIGITS / EACH_EEPROM_NUM_IN_2DIGIT)
#define MAX_ELEMENTS_LAST_DIGITS_RAM_IN_4DIGITS        ( LAST_4DIGITS / EACH_RAM_NUM_IN_4DIGIT)

/* enter num in RAM occupies every 4 digits of num occupies 1 word with big Endian Format in RAM. 
To save EEPROM data memory, every 2 digits of num occupies 1 byte with num in integer format and store nums in EEPROM with big endian format */
#if ((MAX_NUM_CHARS_INPUT_DATA % EACH_EEPROM_NUM_IN_2DIGIT) == 0) 
	#define MAX_ELEMENTS_EEPROM_NUM_IN_2DIGITS     (MAX_NUM_CHARS_INPUT_DATA / EACH_EEPROM_NUM_IN_2DIGIT)
#else 
	#define MAX_ELEMENTS_EEPROM_NUM_IN_2DIGITS     ((MAX_NUM_CHARS_INPUT_DATA / EACH_EEPROM_NUM_IN_2DIGIT) + 1)
#endif
/* retrieved num from EEPROM which every 2 digits of num occupies 1 byte, num in RAM occupies every 4 digits of num occupies 1 word with num in integer format */
#if ((MAX_NUM_CHARS_INPUT_DATA % EACH_RAM_NUM_IN_4DIGIT) == 0) 
	#define MAX_ELEMENTS_CUR_NUM_IN_4DIGITS     (MAX_NUM_CHARS_INPUT_DATA / EACH_RAM_NUM_IN_4DIGIT)
#else 
	#define MAX_ELEMENTS_CUR_NUM_IN_4DIGITS     ((MAX_NUM_CHARS_INPUT_DATA / EACH_RAM_NUM_IN_4DIGIT) + 1)
#endif

#define INVALID_DATA               (0)
#define ALL_LINES                  (0)
#define NUM_LINE1                  (1)
#define NUM_LINE2                  (2)
#define NUM_LINE3                  (3)
#define NUM_LINE4                  (4)
#define NUM_COL1                   (1)

#define ENTER_NUM_MSG_LINE_NUM     (NUM_LINE1)
#define ENTER_NUM_LINE_NUM         (NUM_LINE2)
#define SAVED_LAST_DIGITS_LINE_NUM  (NUM_LINE3)

#define NUM_LAST_DIGITS_COL_NUM     (NUM_COL1 + 5)
#define DIGITS_MSG_COL_NUM          (NUM_LAST_DIGITS_COL_NUM + 1)
#define SAVED_LAST_DIGITS_COL_NUM   (NUM_COL1 + 14) 

/* in process of input digits stage */
#define INPUT_DIGITS_STAGE           (0U)
/* just in stage after valid enter sw pressed  */
#define ENTERED_DATA_STAGE          (1U)
/* just in stage after valid disp sw pressed  */
#define DISP_LAST_DIGITS_STAGE      (2U)  
    
#define EEPROM_LAST_DIGITS_ADDR       (0x00)
#define EEPROM_CUR_STAGE_ADDR         (0x02)
#define EEPROM_NUM_DIGITS_ADDR        (0x03)
/* entered num in hexa decimal format */
#define EEPROM_NUM_FIRST_2DIGITS_ADDR  (0x04)

/* max NUM_LAST_DIGITS = LAST_4DIGITS */
#define NUM_LAST_DIGITS                (LAST_3DIGITS)

void Delay_Time_ByCount(unsigned int Delay_Time_Count_count);
void LCD_Init();
void LCD_Pulse ();
void Write_LCD_Command (const unsigned int Write_LCD_Command);
void Write_LCD_Data(const char lcd_disp_ch);
void Data_Str_Disp_LCD(const char *lcd_disp_str);
void Data_Num_Disp_LCD(const unsigned int lcd_datanum_disp_format, const unsigned long lcd_disp_data_int);
void Max_Last_4Digits_LCD_Disp();
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num);
void Goto_XY_LCD_Input(const unsigned int start_line_num, const unsigned int start_col_num);
void From_Loc_to_XY_LCD(const unsigned int loc_lcd, unsigned int * const loc_lcd_line_num, unsigned int * const loc_lcd_col_num );
void From_XY_To_Loc_LCD(const unsigned int start_line_num, const unsigned int start_col_num, unsigned int * const lcd_loc);

void Retain_Entered_Data_Disp();
void Input_Key_Proc();
void Get_Entered_Key_No_Long_Press(const char cur_pressed_key);
void Entered_Backspace_Sw_No_Long_Press_Proc();
void Is_Numchars_Within_Limit();
void Num_in_4Digit_To_Str( const unsigned int input_num_in_4digit, const unsigned int num_digits_occupied );
void Retrieve_Datas_EEPROM_To_RAM();
void Save_Enter_Num_RAM_To_EEPROM();
void Retain_Stage_Proc();
void Saved_Max_Last_4Digits_Calc();

const char enter_num_msg_disp[] = "Enter Num:", num_entered_msg_disp[] = "Num Entered:", last_msg_disp[] = "Last ", digits_msg_disp[] = " Digits:"; 

const char keypad_char[]   = {'1','2', '3', '4', '5', '6','7','8','9','*', '0', '#'};
unsigned int cur_disp_lcd_loc = BEGIN_LOC_LINE1, cur_input_lcd_loc = BEGIN_LOC_LINE2, num_digits_entered_cur_data = 0; 
char entered_cur_input_data[MAX_NUM_CHARS_INPUT_DATA + 1]  ;
unsigned char cur_pressed_key = '\0';
char key_or_sw_input_enable_flag = STATE_YES, max_input_num_chars_flag = STATE_NO, need_input_flag = STATE_YES, reset_sw_enable_flag = STATE_YES,\
 enter_sw_enable_flag = STATE_NO, backspace_sw_enable_flag = STATE_NO, disp_sw_enable_flag = STATE_NO, keypad_keys_enable_flag = STATE_YES, \
 lcd_avail_loc_within_limit = STATE_YES, cur_data_can_also_input_nonnum_key = STATE_NO ;
unsigned int saved_last_digits[MAX_ELEMENTS_LAST_DIGITS_EEPROM_IN_2DIGITS]; 
 unsigned int cur_stage = INPUT_DIGITS_STAGE, eeprom_cur_stage, eeprom_num_in_mul_2digit[MAX_ELEMENTS_EEPROM_NUM_IN_2DIGITS], eeprom_num_digits_entered, ram_last_digits[MAX_ELEMENTS_LAST_DIGITS_RAM_IN_4DIGITS], \
eeprom_last_digits[MAX_ELEMENTS_LAST_DIGITS_EEPROM_IN_2DIGITS], ram_num_4digit_cur_index = 0, eeprom_num_2digits_cur_index = 0, eeprom_to_ram_cur_part, max_fit_size_eeprom_num_in_mul_2digit,\
 max_size_ram_num_in_mul_4digit, eeprom_last_digits_cur_index = 0, ram_last_digits_cur_index =0 ; 
unsigned long int ram_num_in_mul_4digits[MAX_ELEMENTS_CUR_NUM_IN_4DIGITS], cur_digit_pos_place_val_in_4digit = THOUSANDS_PLACE_VALUE, cur_numdigit_pos_in_4digits; 

void Reset_Process()
{
	memset(entered_cur_input_data, '\0', sizeof(entered_cur_input_data)/sizeof(char));     
	need_input_flag = STATE_YES; 
	key_or_sw_input_enable_flag =STATE_YES;
	reset_sw_enable_flag = STATE_YES;
    enter_sw_enable_flag = STATE_NO;
    backspace_sw_enable_flag = STATE_NO;
    disp_sw_enable_flag = STATE_NO;
    keypad_keys_enable_flag = STATE_YES;
	lcd_avail_loc_within_limit = STATE_YES;
	for(eeprom_last_digits_cur_index = 0; eeprom_last_digits_cur_index < MAX_ELEMENTS_LAST_DIGITS_EEPROM_IN_2DIGITS; ++eeprom_last_digits_cur_index)
	{
	   if( eeprom_last_digits[eeprom_last_digits_cur_index] != 0)
	   {
	      eeprom_write(EEPROM_LAST_DIGITS_ADDR + eeprom_last_digits_cur_index, 0);
	      eeprom_last_digits[eeprom_last_digits_cur_index] = 0;
	   }
	}
	for(ram_last_digits_cur_index = 0; ram_last_digits_cur_index < MAX_ELEMENTS_LAST_DIGITS_RAM_IN_4DIGITS; ++ram_last_digits_cur_index)
	{
	   ram_last_digits[ram_last_digits_cur_index] = 0;
	}
	if(eeprom_num_digits_entered % EACH_EEPROM_NUM_IN_2DIGIT)
	{
		max_fit_size_eeprom_num_in_mul_2digit = (eeprom_num_digits_entered / EACH_EEPROM_NUM_IN_2DIGIT) + 1;
	}
    else
	{
		max_fit_size_eeprom_num_in_mul_2digit = (eeprom_num_digits_entered / EACH_EEPROM_NUM_IN_2DIGIT);
	}		
	for( eeprom_num_2digits_cur_index= 0; eeprom_num_2digits_cur_index < max_fit_size_eeprom_num_in_mul_2digit; ++eeprom_num_2digits_cur_index)
	{
		if(eeprom_num_in_mul_2digit[eeprom_num_2digits_cur_index] != 0)
        {
	      eeprom_write(EEPROM_NUM_FIRST_2DIGITS_ADDR + eeprom_num_2digits_cur_index, 0);
	      eeprom_num_in_mul_2digit[eeprom_num_2digits_cur_index] = 0;	
        }
	}
	if(eeprom_num_digits_entered % EACH_RAM_NUM_IN_4DIGIT)
	{
		max_size_ram_num_in_mul_4digit = (eeprom_num_digits_entered / EACH_RAM_NUM_IN_4DIGIT) + 1;
	}
    else
	{
		max_size_ram_num_in_mul_4digit = (eeprom_num_digits_entered / EACH_RAM_NUM_IN_4DIGIT);
	}	
	for(ram_num_4digit_cur_index =0; ram_num_4digit_cur_index < max_size_ram_num_in_mul_4digit; ++ram_num_4digit_cur_index)
	{
		ram_num_in_mul_4digits[ram_num_4digit_cur_index] = 0;
	}
	ram_num_4digit_cur_index = 0;
	eeprom_num_2digits_cur_index = 0;
	cur_digit_pos_place_val_in_4digit = THOUSANDS_PLACE_VALUE;
	if(eeprom_cur_stage != 0)
	{
	   eeprom_write(EEPROM_CUR_STAGE_ADDR, 0);
	   eeprom_cur_stage = 0;
	}
	cur_stage = eeprom_cur_stage;
	if(eeprom_num_digits_entered != 0)
	{
	   eeprom_write(EEPROM_NUM_DIGITS_ADDR, 0);
	   eeprom_num_digits_entered = 0;
	}
	Write_LCD_Command(0x01); //clear display
   	num_digits_entered_cur_data = eeprom_num_digits_entered;
	Goto_XY_LCD_Disp(ENTER_NUM_MSG_LINE_NUM, NUM_COL1);
    Data_Str_Disp_LCD(enter_num_msg_disp);
    Goto_XY_LCD_Input(ENTER_NUM_LINE_NUM, NUM_COL1);
    Write_LCD_Command(0x0E); // display on , cursor on   	
}	
/*------------------------------------------------------------*
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 1   
-*------------------------------------------------------------*/

void main()
{    
      	  
      TRISA = 0x0F;
      PORTA = 0x00;
	  TRISB = 0x07;
	  PORTB = 0x00;
      TRISC = 0x00;
      PORTC = 0x00;
      TRISD  = 0x00;
      PORTD = 0x00;
      TRISE = 0x00;
      PORTE = 0x00;
      ANSEL = 0x00;
      ANSELH = 0x00;
      LCD_Init();
	  Retrieve_Datas_EEPROM_To_RAM();	   
      Retain_Stage_Proc();
      for(;;)
      {            
          Input_Key_Proc();         	
      } 
  }
  void Retain_Stage_Proc()
  {
        switch(cur_stage)
		{
		   case INPUT_DIGITS_STAGE:
		      Goto_XY_LCD_Disp(ENTER_NUM_MSG_LINE_NUM, NUM_COL1);
	          Data_Str_Disp_LCD(enter_num_msg_disp);
		      key_or_sw_input_enable_flag = STATE_YES;
			  keypad_keys_enable_flag = STATE_YES;
			  if(eeprom_num_digits_entered > 0)
			  {
                 enter_sw_enable_flag = STATE_YES;
			     backspace_sw_enable_flag = STATE_YES;	
			  }
			   Retain_Entered_Data_Disp(); 
			  /* only for num chars fits within same line */
			  Goto_XY_LCD_Input(ENTER_NUM_LINE_NUM, NUM_COL1 + eeprom_num_digits_entered );
			  Write_LCD_Command(0x0E); // display on, cursor on
		   break;
		   case ENTERED_DATA_STAGE:
		      Write_LCD_Command(0x0C); // display on, cursor OFF
		      Goto_XY_LCD_Disp(ENTER_NUM_MSG_LINE_NUM, NUM_COL1);
	          Data_Str_Disp_LCD(num_entered_msg_disp);
			  Retain_Entered_Data_Disp();  
		      disp_sw_enable_flag = STATE_YES;
			  keypad_keys_enable_flag = STATE_NO;			           	  
		   break;
		   case DISP_LAST_DIGITS_STAGE:
		      Write_LCD_Command(0x0C); // display on, cursor OFF
			  Goto_XY_LCD_Disp(ENTER_NUM_MSG_LINE_NUM, NUM_COL1);
	          Data_Str_Disp_LCD(num_entered_msg_disp);	
              Retain_Entered_Data_Disp();		  
		       Goto_XY_LCD_Disp(SAVED_LAST_DIGITS_LINE_NUM, NUM_COL1);
			  Data_Str_Disp_LCD(last_msg_disp);
              Goto_XY_LCD_Disp(SAVED_LAST_DIGITS_LINE_NUM, NUM_LAST_DIGITS_COL_NUM);
              Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT1, NUM_LAST_DIGITS);
              Goto_XY_LCD_Disp(SAVED_LAST_DIGITS_LINE_NUM, DIGITS_MSG_COL_NUM);
			  Data_Str_Disp_LCD(digits_msg_disp); 			  
              Max_Last_4Digits_LCD_Disp();			  
		      reset_sw_enable_flag = STATE_YES; 
		      keypad_keys_enable_flag = STATE_NO;			 
		   break;  
		   default:
			   /* error invalid cur stage to retrieve */
			 ;
		}  
  } 
  void Input_Key_Proc()
  {
         unsigned int eeprom_last_digits_mul_2digits, remainder_eeprom_last_digits_in_mul_2digit;
         
	     if(key_or_sw_input_enable_flag == STATE_YES)
          { 
              Is_Numchars_Within_Limit();  
			  
	          KEYPAD_PHONE_ROWA = 1;
              KEYPAD_PHONE_ROWB  = 0;
              KEYPAD_PHONE_ROWC  = 0;
              KEYPAD_PHONE_ROWD  = 0; 
              if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
              {
		         cur_pressed_key = keypad_char[0];//latest pressed key                			 
		         if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                 {
				     while(KEYPAD_PHONE_COL1 ==KEY_PRESSED);
					 Get_Entered_Key_No_Long_Press(cur_pressed_key); 		            		  
                 }
			  }	 
              if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
              {
		           cur_pressed_key = keypad_char[1];//latest pressed key
				   if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                   {
		             	 while(KEYPAD_PHONE_COL2 ==KEY_PRESSED);
		                Get_Entered_Key_No_Long_Press(cur_pressed_key); 				
		           } 		  
              } 
              if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
              {
	        	   cur_pressed_key = keypad_char[2];//latest pressed key				
	        	   if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                   {
		               while(KEYPAD_PHONE_COL3 ==KEY_PRESSED);
		               Get_Entered_Key_No_Long_Press(cur_pressed_key); 		
		           } 		  
              } 
              KEYPAD_PHONE_ROWA = 0;
              KEYPAD_PHONE_ROWB  = 1;
              KEYPAD_PHONE_ROWC  = 0;
              KEYPAD_PHONE_ROWD  = 0; 
              if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
              {
		           cur_pressed_key = keypad_char[3];//latest pressed key				  
		           if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                   {		            	 
                      while(KEYPAD_PHONE_COL1 ==KEY_PRESSED);
		              Get_Entered_Key_No_Long_Press(cur_pressed_key); 			               					
		           } 		  
              } 
              if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
              {
	       	       cur_pressed_key = keypad_char[4];//latest pressed key				  
                   if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                   {		              	 
                       while(KEYPAD_PHONE_COL2 ==KEY_PRESSED);
		               Get_Entered_Key_No_Long_Press(cur_pressed_key); 
		           } 		  
              } 
              if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
              {
	           	  cur_pressed_key = keypad_char[5];//latest pressed key				  
	          	  if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                  {		            	  
                      while(KEYPAD_PHONE_COL3 ==KEY_PRESSED);
                      Get_Entered_Key_No_Long_Press(cur_pressed_key); 		            	    						
		           } 		  
              }  
               KEYPAD_PHONE_ROWA = 0;
               KEYPAD_PHONE_ROWB  = 0;
               KEYPAD_PHONE_ROWC  = 1;
               KEYPAD_PHONE_ROWD  = 0; 
               if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
               {
	           	  cur_pressed_key = keypad_char[6];//latest pressed key
				  if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                  {
		           	 while(KEYPAD_PHONE_COL1 ==KEY_PRESSED);
		             Get_Entered_Key_No_Long_Press(cur_pressed_key); 		             	   				
		           } 		  
               } 
               if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
               {
	              cur_pressed_key = keypad_char[7];//latest pressed key			 
	              if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                  {	            		 
                      while(KEYPAD_PHONE_COL2 ==KEY_PRESSED);
	                  Get_Entered_Key_No_Long_Press(cur_pressed_key); 	            		    				
	              } 		  
               } 
               if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
               {
	               cur_pressed_key = keypad_char[8];//latest pressed key
	          	   if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                   {
	        	   	 while(KEYPAD_PHONE_COL3 ==KEY_PRESSED);
	         	     Get_Entered_Key_No_Long_Press(cur_pressed_key);
				   }
               } 
               KEYPAD_PHONE_ROWA = 0;
               KEYPAD_PHONE_ROWB  = 0;
               KEYPAD_PHONE_ROWC  = 0;
               KEYPAD_PHONE_ROWD  = 1; 
               if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
               {
	              cur_pressed_key = keypad_char[9];//latest pressed key					   
	              if(keypad_keys_enable_flag == STATE_YES && cur_data_can_also_input_nonnum_key == STATE_YES&& max_input_num_chars_flag ==STATE_NO )
                  {	            		
                      while(KEYPAD_PHONE_COL1 ==KEY_PRESSED);
		              Get_Entered_Key_No_Long_Press(cur_pressed_key);			
		          } 		  
               } 
               if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
               {
		            cur_pressed_key = keypad_char[10];//latest pressed key						
		            if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                    {
		             	  while(KEYPAD_PHONE_COL2 ==KEY_PRESSED);
		                  Get_Entered_Key_No_Long_Press(cur_pressed_key);			
		             } 		  
               }                                               
               if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
               {
	           	   cur_pressed_key = keypad_char[11];//latest pressed key						  
	          	   if(keypad_keys_enable_flag == STATE_YES && cur_data_can_also_input_nonnum_key == STATE_YES && max_input_num_chars_flag ==STATE_NO )
                    {	                  		 
                        while(KEYPAD_PHONE_COL3 ==KEY_PRESSED);
		                 Get_Entered_Key_No_Long_Press(cur_pressed_key);					
		            } 		  
                }    
                if(ENTER_SW == KEY_PRESSED)
                {
	               	 if(enter_sw_enable_flag == STATE_YES)
				     {	                   	    
	                     max_input_num_chars_flag = STATE_NO;								
                         while(ENTER_SW == KEY_PRESSED );
					  /* PROCESS FOR ENTER SW */
                         if(num_digits_entered_cur_data > 0)
				         {
			                 entered_cur_input_data[num_digits_entered_cur_data] = '\0';
							 Write_LCD_Command(0x0C); // display on, cursor OFF
							 Goto_XY_LCD_Disp(ENTER_NUM_MSG_LINE_NUM, NUM_COL1);
	                         Data_Str_Disp_LCD(num_entered_msg_disp);				             
							 cur_stage = ENTERED_DATA_STAGE;
							 if(cur_stage != eeprom_cur_stage)
							 {
								 eeprom_write(EEPROM_CUR_STAGE_ADDR,cur_stage);
								 eeprom_cur_stage = cur_stage;
							 }
							 Saved_Max_Last_4Digits_Calc();
							 for(eeprom_last_digits_cur_index = MAX_ELEMENTS_LAST_DIGITS_EEPROM_IN_2DIGITS -1, eeprom_last_digits_mul_2digits = 1 ; \
							  ((eeprom_last_digits_mul_2digits  - 1)* EACH_EEPROM_NUM_IN_2DIGIT) <= NUM_LAST_DIGITS; --eeprom_last_digits_cur_index, ++eeprom_last_digits_mul_2digits)
	                         {
								 
								//SHOULD_REMOVE
                                /* Goto_XY_LCD_Disp(4,17 + (eeprom_last_digits_cur_index * EACH_EEPROM_NUM_IN_2DIGIT));
                                 Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, saved_last_digits[eeprom_last_digits_cur_index]); */
                               
	                            if( saved_last_digits[eeprom_last_digits_cur_index ] != eeprom_last_digits[eeprom_last_digits_cur_index])
	                            {
	                               eeprom_write(EEPROM_LAST_DIGITS_ADDR + eeprom_last_digits_cur_index , saved_last_digits[eeprom_last_digits_cur_index]);
	                               eeprom_last_digits[eeprom_last_digits_cur_index] = saved_last_digits[eeprom_last_digits_cur_index];
	                            }
	                         }
														 
							 //SHOULD_REMOVE
							/* Goto_XY_LCD_Disp(4,1);
	                         Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT4,ram_num_in_mul_4digits[0]);
                             Goto_XY_LCD_Disp(4,5);
	                         Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT4,ram_num_in_mul_4digits[1]); 
							 Goto_XY_LCD_Disp(4,10);
	                         Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2,eeprom_last_digits[0]);
                             Goto_XY_LCD_Disp(4,12);
	                         Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2,eeprom_last_digits[1]); */
							 
							 //reset_sw_enable_flag = STATE_NO; 
				             enter_sw_enable_flag = STATE_NO;
                             backspace_sw_enable_flag = STATE_NO;
						     keypad_keys_enable_flag = STATE_NO;
							 disp_sw_enable_flag = STATE_YES; 
				          }                                         		 
                       }
				  }							 
                  if(BACKSPACE_SW ==KEY_PRESSED )		 
                  {                            
					  if(backspace_sw_enable_flag == STATE_YES)
					  {						        
                          while(BACKSPACE_SW == KEY_PRESSED ); 
	                      /* Process for valid Backspace */
			              if(num_digits_entered_cur_data > 0)
			               {
                                Entered_Backspace_Sw_No_Long_Press_Proc();			  
                           } 					  
                      }
				   }		 
                   if(DISP_SW ==KEY_PRESSED )		 
                   {
                       if(disp_sw_enable_flag == STATE_YES)
					   {
                           while(DISP_SW == KEY_PRESSED ); 
						   cur_stage = DISP_LAST_DIGITS_STAGE;
                           if(cur_stage != eeprom_cur_stage)
						   {
						      eeprom_write(EEPROM_CUR_STAGE_ADDR,cur_stage);
							  eeprom_cur_stage = cur_stage;
						   }
                           Write_LCD_Command(0x0C); // display on, cursor OFF    						   
                           Goto_XY_LCD_Disp(SAVED_LAST_DIGITS_LINE_NUM, NUM_COL1);
			               Data_Str_Disp_LCD(last_msg_disp);
                           Goto_XY_LCD_Disp(SAVED_LAST_DIGITS_LINE_NUM, NUM_LAST_DIGITS_COL_NUM);
                           Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT1, NUM_LAST_DIGITS);
                           Goto_XY_LCD_Disp(SAVED_LAST_DIGITS_LINE_NUM, DIGITS_MSG_COL_NUM);
			               Data_Str_Disp_LCD(digits_msg_disp); 	
                           Max_Last_4Digits_LCD_Disp();
                           reset_sw_enable_flag = STATE_YES;						   
                       }					  
                    }
					if(RESET_SW ==KEY_PRESSED )
                    {
	                     if(reset_sw_enable_flag == STATE_YES)
					      {	  
	                          while(RESET_SW == KEY_PRESSED ); 
	                          cur_stage = INPUT_DIGITS_STAGE;
							  if(cur_stage != eeprom_cur_stage)
							  {
								 eeprom_write(EEPROM_CUR_STAGE_ADDR,cur_stage);
								 eeprom_cur_stage = cur_stage;
							  }	
							  Reset_Process();
					      }							
                    }       					
           }                	  
  }
 void Retain_Entered_Data_Disp()
 {
	unsigned int num_digits_in_4digits; 
	
	if(eeprom_num_digits_entered)
	{
       max_size_ram_num_in_mul_4digit = eeprom_num_digits_entered / EACH_RAM_NUM_IN_4DIGIT; 			  
	   for(ram_num_4digit_cur_index = 0; ram_num_4digit_cur_index < max_size_ram_num_in_mul_4digit; ++ram_num_4digit_cur_index)
	   {
	  	   Num_in_4Digit_To_Str(ram_num_in_mul_4digits[ram_num_4digit_cur_index], EACH_RAM_NUM_IN_4DIGIT);  
	   }
	   num_digits_in_4digits = eeprom_num_digits_entered % EACH_RAM_NUM_IN_4DIGIT;
	   if(num_digits_in_4digits)
	   {
	      Num_in_4Digit_To_Str(ram_num_in_mul_4digits[ram_num_4digit_cur_index], num_digits_in_4digits);		     
	   }		  
       /* only for num chars fits within same line */
	   Goto_XY_LCD_Disp(ENTER_NUM_LINE_NUM, NUM_COL1);
	   Data_Str_Disp_LCD(entered_cur_input_data);
	}	
 }	 
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 10  
-*------------------------------------------------------------*/ 
void Save_Enter_Num_RAM_To_EEPROM()
{
	 unsigned int save_num_in_two_2digits;	 
		
     //SHOULD_REMOVE
	/* Goto_XY_LCD_Disp(4,1);
	 Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT4, ram_num_in_mul_4digits[0]);
	 Goto_XY_LCD_Disp(4,5);
	 Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT4, ram_num_in_mul_4digits[1]);
   	 Goto_XY_LCD_Disp(4,10);
	 Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT4, cur_digit_pos_place_val_in_4digit);
	 Goto_XY_LCD_Disp(4,15);
	 Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT1, ram_num_4digit_cur_index ); */
	 
	  eeprom_num_2digits_cur_index 	=  (num_digits_entered_cur_data - 1) / EACH_EEPROM_NUM_IN_2DIGIT;   
	  eeprom_to_ram_cur_part = (eeprom_num_2digits_cur_index )% EACH_EEPROM_FACTOR_IN_EACH_RAM;		  
	  
       /* entered number is stored in RAM and EEPROM in big endian format by our implementation */	 
	  switch(eeprom_to_ram_cur_part)
	  {
		 //0
		case EEPROM_TO_RAM_PART1:
		   save_num_in_two_2digits = (ram_num_in_mul_4digits[ram_num_4digit_cur_index] % TEN_THOUSANDS_PLACE_VALUE )/HUNDREDS_PLACE_VALUE;		  
		 break;
		 //1
		 case EEPROM_TO_RAM_PART2:
		   save_num_in_two_2digits  = ram_num_in_mul_4digits[ram_num_4digit_cur_index] % HUNDREDS_PLACE_VALUE;
		 break;
	  }
	 if(save_num_in_two_2digits != eeprom_num_in_mul_2digit[eeprom_num_2digits_cur_index])
	  {
		  eeprom_write(EEPROM_NUM_FIRST_2DIGITS_ADDR + eeprom_num_2digits_cur_index, save_num_in_two_2digits);
		  eeprom_num_in_mul_2digit[eeprom_num_2digits_cur_index] = save_num_in_two_2digits;
	  }
	  if(num_digits_entered_cur_data != eeprom_num_digits_entered)
	  {
		  eeprom_write(EEPROM_NUM_DIGITS_ADDR, num_digits_entered_cur_data);
		  eeprom_num_digits_entered = num_digits_entered_cur_data;
	  }
	  
	/*   //SHOULD_REMOVE
	  Goto_XY_LCD_Disp(4,1); 
	  Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, ram_num_4digit_cur_index);
	  Goto_XY_LCD_Disp(4,4);
	  Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT4, ram_num_in_mul_4digits[0]);
	  Goto_XY_LCD_Disp(4,8);
	  Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT4, ram_num_in_mul_4digits[1]);
      Goto_XY_LCD_Disp(4,13);
	  Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT1, eeprom_num_2digits_cur_index );
	  Goto_XY_LCD_Disp(4,15);
	  Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, eeprom_num_in_mul_2digit[eeprom_num_2digits_cur_index] ); 
	  Goto_XY_LCD_Disp(4,18); 
	  Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, eeprom_num_digits_entered ); */
	  
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 10  
-*------------------------------------------------------------*/ 
void Retrieve_Datas_EEPROM_To_RAM()
{
	unsigned int MSB_ram_num_part, remainder_eeprom_num_2digits_cur_index, LSB_ram_last_2digits, remainder_eeprom_last_digits_in_mul_2digit, eeprom_last_digits_mul_2digits;
	
	ram_last_digits_cur_index = MAX_ELEMENTS_LAST_DIGITS_RAM_IN_4DIGITS - 1;
	
	for(eeprom_last_digits_cur_index = MAX_ELEMENTS_LAST_DIGITS_EEPROM_IN_2DIGITS - 1, eeprom_last_digits_mul_2digits = 1; \
	  ((eeprom_last_digits_mul_2digits  - 1)* EACH_EEPROM_NUM_IN_2DIGIT) <= NUM_LAST_DIGITS ; --eeprom_last_digits_cur_index, ++eeprom_last_digits_mul_2digits )
	{
	   eeprom_last_digits[eeprom_last_digits_cur_index]  =  eeprom_read(EEPROM_LAST_DIGITS_ADDR + eeprom_last_digits_cur_index);
	   
	   /* //SHOULD_REMOVE	   
	    Goto_XY_LCD_Disp(4,1 + (eeprom_last_digits_cur_index * EACH_EEPROM_NUM_IN_2DIGIT));
	    Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, eeprom_last_digits[eeprom_last_digits_cur_index]); */ 
		
	   eeprom_to_ram_cur_part = (eeprom_last_digits_mul_2digits  % EACH_EEPROM_FACTOR_IN_EACH_RAM); 
	   switch(eeprom_to_ram_cur_part)
	   {
		   //1
		   case EEPROM_TO_RAM_PART2:
		     LSB_ram_last_2digits = eeprom_last_digits[eeprom_last_digits_cur_index]; 			
	   	   break;
		   //0
		   case EEPROM_TO_RAM_PART1:
		     ram_last_digits[ram_last_digits_cur_index] = eeprom_last_digits[eeprom_last_digits_cur_index] * HUNDREDS_PLACE_VALUE + LSB_ram_last_2digits;
			 if(eeprom_last_digits_mul_2digits * EACH_EEPROM_NUM_IN_2DIGIT < NUM_LAST_DIGITS)
				--ram_last_digits_cur_index;
		   break;	 
       }			
	}
	remainder_eeprom_last_digits_in_mul_2digit = ((--eeprom_last_digits_mul_2digits * EACH_EEPROM_NUM_IN_2DIGIT) - NUM_LAST_DIGITS);
	switch(remainder_eeprom_last_digits_in_mul_2digit)
	{
	     //1
		 case 1:
		    eeprom_to_ram_cur_part = (eeprom_last_digits_mul_2digits  % EACH_EEPROM_FACTOR_IN_EACH_RAM);
		    switch(eeprom_to_ram_cur_part)
			{
				 //1
		        case EEPROM_TO_RAM_PART2:
		          ram_last_digits[ram_last_digits_cur_index] = LSB_ram_last_2digits ;
				break;
                //0
		        case EEPROM_TO_RAM_PART1:				
			      ram_last_digits[ram_last_digits_cur_index] = eeprom_last_digits[eeprom_last_digits_cur_index + 1 ] * HUNDREDS_PLACE_VALUE + LSB_ram_last_2digits ;
			    break;
			}
		 break;	
	} 
	
	/* //SHOULD_REMOVE
	Goto_XY_LCD_Disp(4,6);
	Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT4, ram_last_digits[ram_last_digits_cur_index]); */
	
	eeprom_cur_stage = eeprom_read(EEPROM_CUR_STAGE_ADDR);
	cur_stage = eeprom_cur_stage;
	eeprom_num_digits_entered = eeprom_read(EEPROM_NUM_DIGITS_ADDR);
	num_digits_entered_cur_data = eeprom_num_digits_entered;
	memset(entered_cur_input_data, '\0', sizeof(entered_cur_input_data)/sizeof(char));  	 
	max_fit_size_eeprom_num_in_mul_2digit = eeprom_num_digits_entered / EACH_EEPROM_NUM_IN_2DIGIT;	
    ram_num_4digit_cur_index = 0;	
	for( eeprom_num_2digits_cur_index = 0; eeprom_num_2digits_cur_index <= max_fit_size_eeprom_num_in_mul_2digit; ++eeprom_num_2digits_cur_index)
	{
	   eeprom_num_in_mul_2digit[eeprom_num_2digits_cur_index] = eeprom_read(EEPROM_NUM_FIRST_2DIGITS_ADDR + eeprom_num_2digits_cur_index);  
	   
	   /* //SHOULD_REMOVE
        Goto_XY_LCD_Disp(4,1 + eeprom_num_2digits_cur_index * EACH_EEPROM_NUM_IN_2DIGIT );
	    Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, eeprom_num_in_mul_2digit[eeprom_num_2digits_cur_index]); */ 
		
	   eeprom_to_ram_cur_part = (eeprom_num_2digits_cur_index )% EACH_EEPROM_FACTOR_IN_EACH_RAM;
       switch(eeprom_to_ram_cur_part )
       {
		   //0
		   case EEPROM_TO_RAM_PART1:
		      MSB_ram_num_part = eeprom_num_in_mul_2digit[eeprom_num_2digits_cur_index];
		   break;
		   //1
		   case EEPROM_TO_RAM_PART2:
             ram_num_in_mul_4digits[ram_num_4digit_cur_index] =  MSB_ram_num_part * HUNDREDS_PLACE_VALUE + eeprom_num_in_mul_2digit[eeprom_num_2digits_cur_index];
			 
			/* //SHOULD_REMOVE
             Goto_XY_LCD_Disp(4,1 + ram_num_4digit_cur_index * EACH_RAM_NUM_IN_4DIGIT );
	         Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT4, ram_num_in_mul_4digits[ram_num_4digit_cur_index]); */			 
			 
			 if( eeprom_num_2digits_cur_index * EACH_EEPROM_NUM_IN_2DIGIT < num_digits_entered_cur_data)
			   ++ram_num_4digit_cur_index;
           break;			 
	   }	  
	}
	remainder_eeprom_num_2digits_cur_index= (eeprom_num_digits_entered % EACH_EEPROM_NUM_IN_2DIGIT);
	if(remainder_eeprom_num_2digits_cur_index)
	{
	   eeprom_num_2digits_cur_index -= 2; 
	   eeprom_num_2digits_cur_index += (remainder_eeprom_num_2digits_cur_index );
	 
	  /* //SHOULD_REMOVE
	   Goto_XY_LCD_Disp(4,20);
	   Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT1,eeprom_num_2digits_cur_index ); */
	  
	   eeprom_to_ram_cur_part = max_fit_size_eeprom_num_in_mul_2digit % EACH_EEPROM_FACTOR_IN_EACH_RAM;
	   switch(eeprom_to_ram_cur_part)
	   {
		  //0
		 case EEPROM_TO_RAM_PART1:		
		    ram_num_in_mul_4digits[ram_num_4digit_cur_index] = eeprom_num_in_mul_2digit[eeprom_num_2digits_cur_index] * HUNDREDS_PLACE_VALUE;
		
		   /* //SHOULD_REMOVE
            Goto_XY_LCD_Disp(4,1 + ram_num_4digit_cur_index * EACH_RAM_NUM_IN_4DIGIT );
	       Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT4, ram_num_in_mul_4digits[ram_num_4digit_cur_index]); */
		   
		 break;
	  }	
   }	 
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 11  
-*------------------------------------------------------------*/
void Get_Entered_Key_No_Long_Press(const char key_data)
{
	/* make sure that entered key is within max available lcd loc and line, currently cur_data_input_max_num_chars_allocated 
	 sures that entered key is within max available lcd loc and within max line */
	 unsigned int cur_input_loc_line_num, cur_input_loc_col_num, next_input_loc_line_num, next_input_loc_col_num,i;
	
     Write_LCD_Command(cur_input_lcd_loc);
     Write_LCD_Data(key_data);	 
	 Write_LCD_Command(0x0E);// insert cursor on at cur_input_lcd_loc
	     
	 From_Loc_to_XY_LCD(cur_input_lcd_loc, &cur_input_loc_line_num, &cur_input_loc_col_num);
	 if(cur_input_loc_line_num == CONFIGURE_MAX_NUM_LINES && cur_input_loc_col_num == CONFIGURE_MAX_NUM_COLS)
	 {	 
		/* reached  end of max configured line and valid key is pressed, retain same loc position */ 		
	 }
	 else
	 {
		 /* put cur input lcd loc to next location */
		 if(cur_input_loc_col_num == CONFIGURE_MAX_NUM_COLS)
		 {	 
			next_input_loc_line_num = cur_input_loc_line_num + 1;
			next_input_loc_col_num = NUM_COL1;
		 }
         else
         {
			 next_input_loc_line_num = cur_input_loc_line_num;
			 next_input_loc_col_num = cur_input_loc_col_num + 1;
		 }	
		 From_XY_To_Loc_LCD(next_input_loc_line_num, next_input_loc_col_num, &cur_input_lcd_loc);		
         entered_cur_input_data[num_digits_entered_cur_data] =key_data; 
		 ++num_digits_entered_cur_data;
        if(key_data >= '0' && key_data <= '9')
	    {		
           cur_numdigit_pos_in_4digits = (num_digits_entered_cur_data) % EACH_RAM_NUM_IN_4DIGIT; 
           ram_num_4digit_cur_index = (num_digits_entered_cur_data - 1) / EACH_RAM_NUM_IN_4DIGIT;	
		   switch(cur_numdigit_pos_in_4digits)
		   {
			   //0
			   case EACH_RAM_UNITS_POS: 
			    cur_digit_pos_place_val_in_4digit = UNIT_PLACE_VALUE;
				ram_num_in_mul_4digits[ram_num_4digit_cur_index] += ((key_data - '0') * cur_digit_pos_place_val_in_4digit);                
			   break;
			   //1
               case EACH_RAM_THOUSANDS_POS:
                cur_digit_pos_place_val_in_4digit = THOUSANDS_PLACE_VALUE;
				ram_num_in_mul_4digits[ram_num_4digit_cur_index] += ((key_data - '0') * cur_digit_pos_place_val_in_4digit); 
			    break;
				//2
               case EACH_RAM_HUNDREDS_POS:
                cur_digit_pos_place_val_in_4digit = HUNDREDS_PLACE_VALUE;
			    ram_num_in_mul_4digits[ram_num_4digit_cur_index] += ((key_data - '0') * cur_digit_pos_place_val_in_4digit); 
			   break;
			   //3
               case EACH_RAM_TENS_POS:
                cur_digit_pos_place_val_in_4digit = TENS_PLACE_VALUE;
				ram_num_in_mul_4digits[ram_num_4digit_cur_index] += ((key_data - '0') * cur_digit_pos_place_val_in_4digit); 
			   break;				   
		   } 
		   
		   //SHOULD_REMOVE
		  /* entered_cur_input_data[num_digits_entered_cur_data] ='\0'; 		   
		   Goto_XY_LCD_Disp(4,9);
		   Data_Str_Disp_LCD(entered_cur_input_data); */
		   
          /* //SHOULD_REMOVE
           Goto_XY_LCD_Disp(4,15);
           Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT1, ram_num_4digit_cur_index ); */  
	    }
	 } 
	   Save_Enter_Num_RAM_To_EEPROM();
	   
	  /* keep track of cur_input_lcd_loc as baskspace we need to -- it and also disp timeouts with.
 	  LCD automatically increments due to loc_command(0x06)in our case as after eg Write_LCD_Command(0x80)
	  ie set DDRAM */      
      enter_sw_enable_flag = STATE_YES;
      backspace_sw_enable_flag = STATE_YES;
} 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 12   
-*------------------------------------------------------------*/
void Entered_Backspace_Sw_No_Long_Press_Proc()
{
	unsigned int cur_input_loc_line_num, cur_input_loc_col_num, previous_input_loc_line_num, previous_input_loc_col_num;
	unsigned int deleted_digit, deleted_digit_place_value_in_4digit;	
	
	lcd_avail_loc_within_limit = STATE_YES;	       	
    if(num_digits_entered_cur_data > 0 && num_digits_entered_cur_data <= MAX_NUM_CHARS_INPUT_DATA )
    {
	    From_Loc_to_XY_LCD(cur_input_lcd_loc, &cur_input_loc_line_num, &cur_input_loc_col_num);
	   if(cur_input_loc_line_num == NUM_LINE1 && cur_input_loc_col_num == NUM_COL1)
	   {	 
		 /* reached begin of line 1 and valid backspace is pressed, retain same loc position */ 
	   }
	   else
	   {
		 /* put cur input lcd loc to one location back from current loc */
		 if(cur_input_loc_col_num == NUM_COL1)
		 {	 
			 previous_input_loc_line_num = cur_input_loc_line_num - 1;
			 previous_input_loc_col_num = CONFIGURE_MAX_NUM_COLS;
		 }
         else
         {
			 previous_input_loc_line_num = cur_input_loc_line_num;
			 previous_input_loc_col_num = cur_input_loc_col_num - 1;
		 }	
		 From_XY_To_Loc_LCD(previous_input_loc_line_num, previous_input_loc_col_num, &cur_input_lcd_loc);	
	  
	      /* deleted digit should be NUMERIC character */
		 deleted_digit = entered_cur_input_data[num_digits_entered_cur_data - 1] - '0';
		  
		 /* do clear last char operation */
		 entered_cur_input_data[num_digits_entered_cur_data] = '\0'; 
		  /* to get key at previous location */
         Write_LCD_Command(cur_input_lcd_loc);
       
         Write_LCD_Data(' '); 
         Write_LCD_Command(0x10); //shift cursor to left 
		 --num_digits_entered_cur_data;
         cur_numdigit_pos_in_4digits = (num_digits_entered_cur_data ) % EACH_RAM_NUM_IN_4DIGIT;
		 ram_num_4digit_cur_index = (num_digits_entered_cur_data) / EACH_RAM_NUM_IN_4DIGIT;	
		
		  switch(cur_numdigit_pos_in_4digits)
		 {
			 //0
			case EACH_RAM_UNITS_POS:
			  deleted_digit_place_value_in_4digit = THOUSANDS_PLACE_VALUE;
			  ram_num_in_mul_4digits[ram_num_4digit_cur_index] = 0;
			  if(num_digits_entered_cur_data)
			  {
                cur_digit_pos_place_val_in_4digit = UNIT_PLACE_VALUE; 
                --ram_num_4digit_cur_index;
			  }				
              else
                cur_digit_pos_place_val_in_4digit = THOUSANDS_PLACE_VALUE;  				  
			  break;
			  //1
			case EACH_RAM_THOUSANDS_POS:
              deleted_digit_place_value_in_4digit = HUNDREDS_PLACE_VALUE;
			  ram_num_in_mul_4digits[ram_num_4digit_cur_index] -= (deleted_digit * (deleted_digit_place_value_in_4digit));
              cur_digit_pos_place_val_in_4digit = THOUSANDS_PLACE_VALUE; 			  
			  break;
			  //2
			case EACH_RAM_HUNDREDS_POS:
			  deleted_digit_place_value_in_4digit = TENS_PLACE_VALUE;
			  ram_num_in_mul_4digits[ram_num_4digit_cur_index] -= (deleted_digit * (deleted_digit_place_value_in_4digit)); 
              cur_digit_pos_place_val_in_4digit = HUNDREDS_PLACE_VALUE; 	 			  
			  break;
			  //3
			case EACH_RAM_TENS_POS: 
              deleted_digit_place_value_in_4digit = UNIT_PLACE_VALUE;
			  ram_num_in_mul_4digits[ram_num_4digit_cur_index] -= (deleted_digit * (deleted_digit_place_value_in_4digit)); 
              cur_digit_pos_place_val_in_4digit  = TENS_PLACE_VALUE;			  
              break;  
		 }
		 
		/* //SHOULD_REMOVE
		 Goto_XY_LCD_Disp(4,15);
		// Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT4, deleted_digit * deleted_digit_place_value_in_4digit);
		Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT1, deleted_digit ); */
		
		 Save_Enter_Num_RAM_To_EEPROM();		  
	  }  
	  Write_LCD_Command(cur_input_lcd_loc);
      Write_LCD_Command(0x0E);	
   }
}
 
void Num_in_4Digit_To_Str( const unsigned int input_num_in_4digit, const unsigned int num_digits_occupied )
{
	static unsigned int num_str_cur_index = 0;
	unsigned int cur_digit_index = 0, cur_digit, cur_num = input_num_in_4digit % TEN_THOUSANDS_PLACE_VALUE, cur_digit_place_value = THOUSANDS_PLACE_VALUE;
	char digit_to_char;
	
	for(cur_digit_index = 0; cur_digit_index < num_digits_occupied; ++cur_digit_index)
	{
	   cur_digit = cur_num / cur_digit_place_value;
	   switch(cur_digit)
	   {
		   case 0:
		     digit_to_char = '0';
		   break;
           case 1:
		     digit_to_char = '1';
		   break;
           case 2:
		     digit_to_char = '2';
		   break;
           case 3:
		     digit_to_char = '3';
		   break;	
           case 4:
		     digit_to_char = '4';
		   break;
           case 5:
		     digit_to_char = '5';
		   break;			   
           case 6:;
		     digit_to_char = '6';
		   break;
           case 7:
		     digit_to_char = '7';
		   break;	
           case 8:
		     digit_to_char = '8';
		   break;
           case 9:
		     digit_to_char = '9';
		   break;
           default:
             ;
             /* invalid num digit */			 
	   }
	   entered_cur_input_data[num_str_cur_index] = digit_to_char;
	   cur_num %= cur_digit_place_value;
	   cur_digit_place_value /= 10;	  
	  ++num_str_cur_index; 
   }
   entered_cur_input_data[num_str_cur_index] = '\0';
}    
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 10  
-*------------------------------------------------------------*/
void Is_Numchars_Within_Limit()
{
 	/* num char < valid char as when num chars <= max valid, and num char == max valid, then you can entry key and 
	and num char  =  max valid + 1, now you cannot input key */	
	   
	if(num_digits_entered_cur_data < MAX_NUM_CHARS_INPUT_DATA)
        max_input_num_chars_flag = STATE_NO;
     else
	 {
        max_input_num_chars_flag = STATE_YES; 
		/* warning:  num of input data chars has reached max num of chars allocated for cur input data  */
     } 
    	 
}
void Saved_Max_Last_4Digits_Calc()
{
	ram_last_digits_cur_index = MAX_ELEMENTS_LAST_DIGITS_RAM_IN_4DIGITS - 1;
	switch(NUM_LAST_DIGITS)
	{	
	   case LAST_4DIGITS:
		 switch(eeprom_num_digits_entered)
	     {
		   case 1:
		     saved_last_digits[0] = 0;
		     saved_last_digits[1] = (entered_cur_input_data[eeprom_num_digits_entered - 1] - '0');
			 ram_last_digits[ram_last_digits_cur_index] = saved_last_digits[0] * HUNDREDS_PLACE_VALUE + saved_last_digits[1];
		   break;
		   case 2:
		     saved_last_digits[0] = 0; 
		     saved_last_digits[1] = ((entered_cur_input_data[eeprom_num_digits_entered - 2] - '0') * TENS_PLACE_VALUE) + (entered_cur_input_data[eeprom_num_digits_entered - 1] - '0');
			 ram_last_digits[ram_last_digits_cur_index] = saved_last_digits[0] * HUNDREDS_PLACE_VALUE + saved_last_digits[1];
		   break;	
		   case 3: 
             saved_last_digits[0] = (entered_cur_input_data[eeprom_num_digits_entered - 3] - '0');
             saved_last_digits[1] = ((entered_cur_input_data[eeprom_num_digits_entered - 2] - '0') * TENS_PLACE_VALUE) + (entered_cur_input_data[eeprom_num_digits_entered - 1] - '0');
			 ram_last_digits[ram_last_digits_cur_index] = saved_last_digits[0] * HUNDREDS_PLACE_VALUE + saved_last_digits[1];
           break;
		   default: 
             saved_last_digits[0] = ((entered_cur_input_data[eeprom_num_digits_entered - 4] - '0') * TENS_PLACE_VALUE) + (entered_cur_input_data[eeprom_num_digits_entered - 3] - '0');
             saved_last_digits[1] = ((entered_cur_input_data[eeprom_num_digits_entered - 2] - '0') * TENS_PLACE_VALUE) + (entered_cur_input_data[eeprom_num_digits_entered - 1] - '0');
			 ram_last_digits[ram_last_digits_cur_index] = saved_last_digits[0] * HUNDREDS_PLACE_VALUE + saved_last_digits[1];
	     }
       break;
       case LAST_3DIGITS:
		 switch(eeprom_num_digits_entered)
	     {	  
		     case 1:
		       saved_last_digits[0] = 0;
		       saved_last_digits[1] = (entered_cur_input_data[eeprom_num_digits_entered - 1] - '0');
			   ram_last_digits[ram_last_digits_cur_index] = saved_last_digits[0] * HUNDREDS_PLACE_VALUE + saved_last_digits[1];
		    break;
			case 2:
		       saved_last_digits[0] = 0; 
		       saved_last_digits[1] = ((entered_cur_input_data[eeprom_num_digits_entered - 2] - '0') * TENS_PLACE_VALUE) + (entered_cur_input_data[eeprom_num_digits_entered - 1] - '0');
			   ram_last_digits[ram_last_digits_cur_index] = saved_last_digits[0] * HUNDREDS_PLACE_VALUE + saved_last_digits[1];
		     break;	
			default: 
               saved_last_digits[0] = (entered_cur_input_data[eeprom_num_digits_entered - 3] - '0');
               saved_last_digits[1] = ((entered_cur_input_data[eeprom_num_digits_entered - 2] - '0') * TENS_PLACE_VALUE) + (entered_cur_input_data[eeprom_num_digits_entered - 1] - '0');
			   ram_last_digits[ram_last_digits_cur_index] = saved_last_digits[0] * HUNDREDS_PLACE_VALUE + saved_last_digits[1];
	     }
       break;
       case LAST_2DIGITS:
		 switch(eeprom_num_digits_entered)
	     {
		    case 1:
		       saved_last_digits[0] = 0;
		       saved_last_digits[1] = (entered_cur_input_data[eeprom_num_digits_entered - 1] - '0');
			   ram_last_digits[ram_last_digits_cur_index] = saved_last_digits[0] * HUNDREDS_PLACE_VALUE + saved_last_digits[1];
		    break;
			default:			
		       saved_last_digits[0] = 0; 
		       saved_last_digits[1] = ((entered_cur_input_data[eeprom_num_digits_entered - 2] - '0') * TENS_PLACE_VALUE) + (entered_cur_input_data[eeprom_num_digits_entered - 1] - '0');
			   ram_last_digits[ram_last_digits_cur_index] = saved_last_digits[0] * HUNDREDS_PLACE_VALUE + saved_last_digits[1];
		     break;	
	     }
       break;
       case LAST_1DIGIT:
		 switch(eeprom_num_digits_entered)
	     {
		    default:
		       saved_last_digits[0] = 0;
		       saved_last_digits[1] = (entered_cur_input_data[eeprom_num_digits_entered - 1] - '0');
			   ram_last_digits[ram_last_digits_cur_index] = saved_last_digits[0] * HUNDREDS_PLACE_VALUE + saved_last_digits[1];
	     }
       break;		   
	}
	
	
	
}
void Max_Last_4Digits_LCD_Disp()
{
	unsigned int remainder_eeprom_last_digits_in_mul_2digit, eeprom_last_digits_mul_2digits ;	
	
    ram_last_digits_cur_index = MAX_ELEMENTS_LAST_DIGITS_RAM_IN_4DIGITS - 1;	
	switch(NUM_LAST_DIGITS)
	{
		case LAST_4DIGITS:
		   Goto_XY_LCD_Disp(SAVED_LAST_DIGITS_LINE_NUM, SAVED_LAST_DIGITS_COL_NUM);
		   Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT4, ram_last_digits[ram_last_digits_cur_index]);
		break;
		case LAST_3DIGITS:
		   Goto_XY_LCD_Disp(SAVED_LAST_DIGITS_LINE_NUM, SAVED_LAST_DIGITS_COL_NUM);
		   Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT3, ram_last_digits[ram_last_digits_cur_index]);
		break;
		case LAST_2DIGITS:
		   Goto_XY_LCD_Disp(SAVED_LAST_DIGITS_LINE_NUM, SAVED_LAST_DIGITS_COL_NUM);
		   Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, ram_last_digits[ram_last_digits_cur_index]);
		break;
		case LAST_1DIGIT:
		   Goto_XY_LCD_Disp(SAVED_LAST_DIGITS_LINE_NUM, SAVED_LAST_DIGITS_COL_NUM);
		   Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT1, ram_last_digits[ram_last_digits_cur_index]);
		break;
	}
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void LCD_Init()
{
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x38);
    Write_LCD_Command(0x01);
    Write_LCD_Command(0x0E); //insert cursor on at cur_input_lcd_loc
	//Write_LCD_Command(0x0C);
    Write_LCD_Command(0x06);                                       
}     

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 23   
-*------------------------------------------------------------*/
  void Write_LCD_Command (unsigned int cmd)
  {
	  unsigned long int  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  
       RW_PIN = 0;
       RS_PIN = 0; 
       LCD_PORT = cmd;
      // LCD_Pulse();
	  EN_PIN = 1;
	  while(time_delay--);
    // Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
      EN_PIN = 0;
	  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  while(time_delay--);
   //  Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
 }
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 24   
-*------------------------------------------------------------*/
 void Write_LCD_Data(const char ch)
{
	unsigned long int  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	// performance degraded if many data is written to LCD, to check if write loc is within avail disp loc
	// if(lcd_avail_loc_within_limit == STATE_YES) 
	{	
      RW_PIN = 0;
      RS_PIN = 1;
      LCD_PORT =ch;
     // LCD_Pulse();
      EN_PIN = 1;
	  while(time_delay--);
    // Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
     EN_PIN = 0;
	 time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	 while(time_delay--);
   //  Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);	 
	}
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 25   
-*------------------------------------------------------------*/

void Data_Str_Disp_LCD(const char *char_ptr)
{ 
       while(*char_ptr)
       {
            Write_LCD_Data(*(char_ptr++));
       }
     
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 27  
-*------------------------------------------------------------*/
void Delay_Time_ByCount( unsigned int time_delay)
{
       while(time_delay--);
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 26  
-*------------------------------------------------------------*/
void Data_Num_Disp_LCD(const unsigned int lcd_datanum_disp_format, const unsigned long lcd_disp_data_int)
{
    unsigned int tens_thousand_digit,thousands_digit, hundreds_digit,tens_digit, unit_digit;
    unsigned long num = lcd_disp_data_int;
    char num_data[] ={'0','1','2','3','4','5','6','7','8','9'};  
	char hex_data[] ={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'}; 
    switch(lcd_datanum_disp_format)
	{
	  case DISP_FLAG_NUM_DIGIT5: 
	      num = lcd_disp_data_int;
		  tens_thousand_digit = (unsigned int)(num / (unsigned long)(TEN_THOUSANDS_PLACE_VALUE));
          Write_LCD_Data(num_data[tens_thousand_digit]);
	  case DISP_FLAG_NUM_DIGIT4:
	      num = lcd_disp_data_int % TEN_THOUSANDS_PLACE_VALUE;
	      thousands_digit = (unsigned int)(num / (unsigned long)(THOUSANDS_PLACE_VALUE));
	      Write_LCD_Data(num_data[thousands_digit]); 
	  case DISP_FLAG_NUM_DIGIT3: 
		  num = lcd_disp_data_int % THOUSANDS_PLACE_VALUE;
	      hundreds_digit = (unsigned int) (num / (unsigned long) (HUNDREDS_PLACE_VALUE));
	      Write_LCD_Data(num_data[hundreds_digit]);
	  case DISP_FLAG_NUM_DIGIT2:
          num = lcd_disp_data_int % HUNDREDS_PLACE_VALUE;
          tens_digit = (unsigned int) (num / TENS_PLACE_VALUE);
          Write_LCD_Data(num_data[tens_digit]); 		  
	  case DISP_FLAG_NUM_DIGIT1:
	     unit_digit = (unsigned int) (lcd_disp_data_int % TENS_PLACE_VALUE);
         Write_LCD_Data(num_data[unit_digit]); 
	  break;
	  case DISP_FLAG_HEX_DIGIT4:
	      /*  ( 16 * 16 * 16 *16 )  = 0 as divide by zero warning */
	      //num = lcd_disp_data_int % ( 16 * 16 * 16 *16 );
          thousands_digit = (unsigned int)(num / (unsigned long) (16 * 16 * 16));
	      Write_LCD_Data(hex_data[thousands_digit]);
	  case DISP_FLAG_HEX_DIGIT3:
	      num = lcd_disp_data_int %(unsigned long)(16 * 16 * 16);
	      hundreds_digit = (unsigned int) (num / (unsigned long) (16 * 16));
	      Write_LCD_Data(hex_data[hundreds_digit]);
	  case DISP_FLAG_HEX_DIGIT2:
	      num = lcd_disp_data_int %(unsigned long)(16 * 16);
          tens_digit = (unsigned int) (num / 16);
          Write_LCD_Data(hex_data[tens_digit]);
	  case DISP_FLAG_HEX_DIGIT1: 
	      unit_digit = (unsigned int) (lcd_disp_data_int % 16);
          Write_LCD_Data(hex_data[unit_digit]);    
	  break;
	  default:
	       /* Warning invalid lcd_disp flag */
	    ;
	}   	
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 29   
-*------------------------------------------------------------*/
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num)
{
	/* max 4 lines and 20 columns */
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1, error_disp_start_loc; 
	lcd_avail_loc_within_limit = STATE_YES;
	
   if(start_line_num <= CONFIGURE_MAX_NUM_LINES && start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
      switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE4;
		   break;		 
	 }	
      cur_disp_lcd_loc = cur_disp_lcd_loc + start_col_lcd;
      Write_LCD_Command(cur_disp_lcd_loc);       
   }
   else
   {
	   /* error due to invalid lcd DISP loc  */
	     lcd_avail_loc_within_limit = STATE_NO;		
		       		
   }	   
} 
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 30   
-*------------------------------------------------------------*/ 
void Goto_XY_LCD_Input(unsigned int start_line_num,unsigned int start_col_num)
{
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1; 
	
	/* max 4 lines and 20 columns */
	lcd_avail_loc_within_limit = STATE_YES;
	if( start_line_num <= CONFIGURE_MAX_NUM_LINES &&  start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
     switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_input_lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   cur_input_lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   cur_input_lcd_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   cur_input_lcd_loc = BEGIN_LOC_LINE4;
		   break; 		  
	 }
	 cur_input_lcd_loc = cur_input_lcd_loc + start_col_lcd;
     Write_LCD_Command(cur_input_lcd_loc); 	 	   
  }
  else
  {
	   /* error due to invalid Lcd loc  */	
	   lcd_avail_loc_within_limit = STATE_NO;
	  	  
  }	  
} 
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 31   
-*------------------------------------------------------------*/
void From_XY_To_Loc_LCD(const unsigned int start_line_num, const unsigned int start_col_num, unsigned int * const lcd_loc)
{
	/* max 4 lines and 20 columns */
	   
	lcd_avail_loc_within_limit = STATE_YES;
	
   if(start_line_num <= CONFIGURE_MAX_NUM_LINES && start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
      switch(start_line_num)
	 {
		 case NUM_LINE1:
		   *lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   *lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   *lcd_loc= BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		  *lcd_loc = BEGIN_LOC_LINE4;
		   break;		 
	 }	
      *lcd_loc = *lcd_loc + start_col_num - 1;           
   }
   else
   {
	    lcd_avail_loc_within_limit = STATE_NO;
		/* error: due to loc_lcd's line num > max configured line nums */			 
	   		
   }	   
} 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void From_Loc_to_XY_LCD(const unsigned int loc_lcd, unsigned int * const loc_lcd_line_num, unsigned int * const loc_lcd_col_num  )
{
	/* loc_lcd's corrosponding line num and col num */
	
	lcd_avail_loc_within_limit = STATE_YES;
	
	if(CONFIGURE_MAX_NUM_LINES <= MAX_AVAIL_NUM_LINES)
	{	
    	if(loc_lcd >= BEGIN_LOC_LINE1 && loc_lcd <= END_LOC_LINE1)
	    {
		     *loc_lcd_line_num = NUM_LINE1;
	         *loc_lcd_col_num = loc_lcd + 1 - BEGIN_LOC_LINE1;		    
	    }
       if(loc_lcd >= BEGIN_LOC_LINE2 && loc_lcd <= END_LOC_LINE2)
	   {
	     	*loc_lcd_line_num = NUM_LINE2;
		    *loc_lcd_col_num = loc_lcd + 1 - BEGIN_LOC_LINE2; 		
	   }     
	   if(loc_lcd >= BEGIN_LOC_LINE3 && loc_lcd <= END_LOC_LINE3)
	   {
		   	*loc_lcd_line_num = NUM_LINE3;
		  	*loc_lcd_col_num = loc_lcd + 1 - BEGIN_LOC_LINE3;			
	   }
       if(loc_lcd >= BEGIN_LOC_LINE4 && loc_lcd <= END_LOC_LINE4)
	   {
		  	*loc_lcd_line_num = NUM_LINE4;
		   	*loc_lcd_col_num = loc_lcd + 1 - BEGIN_LOC_LINE4;				
	   }	  
   } 
   else
   {
	   /* error: configured max lines > 4 */
	   
   }      
}
