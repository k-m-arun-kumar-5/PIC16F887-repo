/* ********************************************************************
FILE                   : eeprom1.c

PROGRAM DESCRIPTION    :  DISPLAY periodic hexa digit in a 7 segment LED of  common cathode  for every sw press and power is off and 
when power is on, displays digit, which was displayed just before power went off and continue the process.
Changed data or important data in ram is saved in EEPROM, so even when power goes OFF and when power is on
retrieve data from eeprom to ram and resume from the retained process where power goes off 

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : to check  for power off and then power on simulation in proteus ( press button - stop simulation,
  then press button - advanced simulation by one frame )and then press button - run simulation 
                                  
                       
CHANGE LOGS           : 

*****************************************************************************/  
#include <pic.h>
#define  INC_SW                    RA0
#define  SEVEN_SEG_PORT           (PORTC)
#define  EEPROM_DIGIT_ADDR        (0x00U)

unsigned int digit; 
void  main()
{
    unsigned int digit_disp[]   = {0x3F, 0x06, 0x5B, 0x4F,0x66,0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71};
   	TRISA = 0x01;
    PORTA = 0x00;
    TRISC = 0x00;
	PORTC = 0X00;
    ANSEL = 0x00;
    ANSELH = 0x00;	
	 /* read EEPROM at EEPROM address: EEPROM_DIGIT_ADDR and save EEPROM_DIGIT_ADDR's data to digit variable(in RAM) */
	   digit = eeprom_read(EEPROM_DIGIT_ADDR);
	SEVEN_SEG_PORT = digit_disp[digit];
	
    for(;;)
    {
        if(INC_SW == 1)
        {
            while(INC_SW == 1);
			SEVEN_SEG_PORT = digit_disp[++digit];
			/* Write digit variable(in RAM) data to EEPROM at EEPROM address:EEPROM_DIGIT_ADDR    */
            eeprom_write(EEPROM_DIGIT_ADDR, digit);
       }
       if(digit >= 16)
           digit  = 0;      
    }                                                                              
}
