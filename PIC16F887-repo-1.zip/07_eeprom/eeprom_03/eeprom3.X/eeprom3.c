 /* ********************************************************************
FILE                   : eeprom3.c

PROGRAM DESCRIPTION    :   DISPLAY increment number in a LCD for every time INC_SW s pressed and when SET_SW is pressed save number in EEPROM and 
display saved number in LCD and start from num 0 with fixed delay with auto incrementing to saved set number,
 when reached saved set number, NUM_MATCH_LED is ON. RESET_SW is used to restart the process. 
 While in auto incrementing to saved set number, even when power reboot(power is off and then power is on), 
 resume from where auto increment gets interrupted due to power off. Changed data or important data in ram is saved in EEPROM, so even when power reboots
retrieve data from eeprom to ram and resume from the retained process where power gone off 

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : to check  for power off and then power on simulation in proteus ( press button - stop simulation,
  then press button - advanced simulation by one frame )and then press button - run simulation.  Added feature with base code from eeprom2.c 
  
                                  
                       
CHANGE LOGS           : 

*****************************************************************************/   
  
#include <pic.h>

#define  INC_SW                    RA0
#define  SET_SW                    RA1
#define  RESET_SW                  RA2
#define  NUM_MATCH_LED             RA3

#define RS_PIN                                 RD0
#define RW_PIN                                 RD1
#define EN_PIN                                 RD2
#define LCD_PORT                              PORTC

#define SWITCH_PRESSED_ON                       (1)
#define SWITCH_NOT_PRESSED                      (0)
#define LED_ON                                  (1)
#define LED_OFF                                 (0) 
#define STATE_YES                               ('y')
#define STATE_NO                                ('n')

#define DISP_FLAG_NUM_DIGIT1                   (1U)
#define DISP_FLAG_NUM_DIGIT2                   (2U)
#define DISP_FLAG_NUM_DIGIT3                   (3U)
#define DISP_FLAG_NUM_DIGIT4                   (4U)
#define DISP_FLAG_NUM_DIGIT5                   (5U)
#define DISP_FLAG_HEX_DIGIT1                   (6U)
#define DISP_FLAG_HEX_DIGIT2                   (7U)
#define DISP_FLAG_HEX_DIGIT3                   (8U)
#define DISP_FLAG_HEX_DIGIT4                   (9U) 

/* for 20 * 4 LCD disp */                             
#define BEGIN_LOC_LINE1                      (0X80)
#define BEGIN_LOC_LINE2                      (0xC0)
#define BEGIN_LOC_LINE3                      (0x94) 
#define BEGIN_LOC_LINE4                      (0xD4)
#define END_LOC_LINE1                        (0x93)
#define END_LOC_LINE2                        (0xD3)
#define END_LOC_LINE3                        (0xA7) 
#define END_LOC_LINE4                        (0xE7)

/* num cols = num of chars in a line */
#define MAX_COUNT_DELAY_TIME_LCDPULSE     (100UL)
#define MAX_AVAIL_NUM_COLS                    (20U)
#define CONFIGURE_MAX_NUM_LINES               (4U)
#define MAX_AVAIL_NUM_LINES                   (4U) 
#define MAX_AVAIL_NUM_CHARS_IN_LCD        (MAX_AVAIL_NUM_COLS * MAX_AVAIL_NUM_LINES) 
#define CONFIGURE_MAX_NUM_COLS             (MAX_AVAIL_NUM_COLS)
#define CONFIGURE_MAX_NUM_CHARS_IN_LCD    (CONFIGURE_MAX_NUM_LINES * CONFIGURE_MAX_NUM_COLS ) 
#define MAX_NUM_CHARS_INPUT_DATA          (MAX_AVAIL_NUM_COLS)  

#define INVALID_DATA               (0U)
#define ALL_LINES                  (0U)
#define NUM_LINE1                  (1U)
#define NUM_LINE2                  (2U)
#define NUM_LINE3                  (3U)
#define NUM_LINE4                  (4U)
#define NUM_COL1                   (1U)

#define SW_INC_LINE_NUM            (NUM_LINE1)
#define SAVED_SET_NUM_LINE_NUM     (NUM_LINE2)
#define AUTO_INC_LINE_NUM          (NUM_LINE3)

#define SW_INC_STATUS_COL_NUM      (NUM_COL1 + 9)
#define SAVED_SET_NUM_COL_NUM           (NUM_COL1 + 9)
#define AUTO_INC_COL_NUM           (NUM_COL1 + 9)

#define TMR1_OFF_STATE             (0U)
#define TMR1_INC_DISP_STATE        (1U)
 
#define _XTAL_FREQ                (4000000UL)
// TIMER1 expires every 50ms and  
#define TIMER1_TICK_MSEC          (50UL) 
#define TIME_UNIT_SEC_TO_MSEC      (1000UL)
#define OSC_PER_INST                (4)
#define INC1                  (unsigned long)((unsigned long)(_XTAL_FREQ * TIMER1_TICK_MSEC) / (unsigned long)(OSC_PER_INST * TIME_UNIT_SEC_TO_MSEC))

#define TIME_UPDATE                     (500UL) 
#define CUR_STAGE_TIME_FACTOR_PER_SEC   (1000UL/TIME_UPDATE)
#define UPDATE_TIME1_CUR_STAGE          (TIME_UPDATE/TIMER1_TICK_MSEC)
 

#define  EEPROM_SET_INC_NUM_ADDR        (0x00)
#define  EEPROM_AUTO_INC_NUM_ADDR       (0x01)

void Delay_Time_ByCount(unsigned int Delay_Time_Count_count);
void LCD_Init();
void LCD_Pulse ();
void Write_LCD_Command (const unsigned int Write_LCD_Command);
void Write_LCD_Data(const char lcd_disp_ch);
void Data_Str_Disp_LCD(const char *lcd_disp_str);
void Data_Num_Disp_LCD(const unsigned int lcd_datanum_disp_format, const unsigned long lcd_disp_data_int);
void LCD_Const_Disp();
void Datas_LCD_Disp();
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num);

void Run_Timer1(const unsigned int set_timer1_mode );
void Prescale_Timer1();
void Stop_Timer1();
void Cur_Stage_Time_Run_Proc();
void Cur_Stage_Time_Proc();
void Reset_Process();

void Retrive_Saved_EEPROM_Datas();

unsigned int prescale_timer1 = 0x01, prescale_shift_timer1= 0, timer1_mode = TMR1_OFF_STATE;
unsigned long int num_calls_timer1 = 0, timer1_init = 0;
unsigned int count_update_cur_stage_per_sec = 0, cur_stage_time_left;

unsigned int cur_disp_lcd_loc = BEGIN_LOC_LINE1;
char reset_sw_enable_flag = STATE_YES, reset_pressed_flag, cur_stage_time_enable_flag = STATE_NO,\
         cur_stage_time_expiry_flag = STATE_NO, set_sw_enable_flag = STATE_YES, inc_sw_enable_flag = STATE_YES, \
		 run_timer1_once_after_reboot_flag = STATE_YES, inc_sw_pressed_flag = STATE_NO;
unsigned int sw_inc_cur_num, auto_inc_num, saved_set_sw_num, saved_auto_inc_num;

void  main()
{
	TRISA = 0x07;
    PORTA = 0x00;
	TRISB = 0x00;
	PORTB = 0x00;
    TRISC = 0x00;
	PORTC = 0X00;
	TRISD = 0x00;
	PORTD = 0x00;
    ANSEL = 0x00;
    ANSELH = 0x00;	
	LCD_Init(); 
	LCD_Const_Disp();	
	Retrive_Saved_EEPROM_Datas();
    Datas_LCD_Disp();
	
    for(;;)
    {
		if(reset_sw_enable_flag == STATE_YES && RESET_SW == SWITCH_PRESSED_ON)
		{
			while(RESET_SW == SWITCH_PRESSED_ON);
			Reset_Process();
			reset_pressed_flag = STATE_YES;
			reset_sw_enable_flag = STATE_NO;			  
        }
		if(set_sw_enable_flag == STATE_YES && saved_set_sw_num == 0 && SET_SW == SWITCH_PRESSED_ON )
		{
			while( SET_SW == SWITCH_PRESSED_ON );
			saved_set_sw_num = sw_inc_cur_num;
			eeprom_write(EEPROM_SET_INC_NUM_ADDR, saved_set_sw_num);			
			Goto_XY_LCD_Disp(SAVED_SET_NUM_LINE_NUM, SAVED_SET_NUM_COL_NUM);  
            Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT3, saved_set_sw_num);				
			cur_stage_time_expiry_flag = STATE_NO;
			cur_stage_time_enable_flag = STATE_YES;
			cur_stage_time_left = saved_set_sw_num;			
			Run_Timer1(TMR1_INC_DISP_STATE);
		}
		if(run_timer1_once_after_reboot_flag == STATE_YES && saved_auto_inc_num < saved_set_sw_num)
		{
			NUM_MATCH_LED = LED_OFF;
			Goto_XY_LCD_Disp(SAVED_SET_NUM_LINE_NUM, SAVED_SET_NUM_COL_NUM);  
            Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT3, saved_set_sw_num);
			cur_stage_time_expiry_flag = STATE_NO;
			cur_stage_time_enable_flag = STATE_YES;
			cur_stage_time_left = saved_set_sw_num - saved_auto_inc_num;
			Run_Timer1(TMR1_INC_DISP_STATE);
			run_timer1_once_after_reboot_flag = STATE_NO;
		}
		if(timer1_mode != TMR1_OFF_STATE && cur_stage_time_expiry_flag == STATE_NO && cur_stage_time_enable_flag == STATE_YES)
			Cur_Stage_Time_Run_Proc();
		if(cur_stage_time_expiry_flag == STATE_YES || (inc_sw_pressed_flag == STATE_NO && saved_auto_inc_num == saved_set_sw_num))
		{
			Stop_Timer1();
			NUM_MATCH_LED = LED_ON;
			reset_sw_enable_flag = STATE_YES;
		}
        if(inc_sw_enable_flag == STATE_YES && INC_SW == SWITCH_PRESSED_ON)
        {
			NUM_MATCH_LED = LED_OFF;
            while(INC_SW == SWITCH_PRESSED_ON);
			++sw_inc_cur_num;
			Goto_XY_LCD_Disp(SW_INC_LINE_NUM, SW_INC_STATUS_COL_NUM);
			Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT3,sw_inc_cur_num );
			if(sw_inc_cur_num>= 255UL)
              sw_inc_cur_num  = 0;  
		    inc_sw_pressed_flag = STATE_YES;
       }
    }                                                                              
}
void Retrive_Saved_EEPROM_Datas()
{
	saved_set_sw_num = eeprom_read(EEPROM_SET_INC_NUM_ADDR); 
	saved_auto_inc_num = eeprom_read(EEPROM_AUTO_INC_NUM_ADDR);    
	auto_inc_num = saved_auto_inc_num;
	if(saved_set_sw_num == 0)
		inc_sw_enable_flag = STATE_YES;
	else
		inc_sw_enable_flag = STATE_NO;	 
}
void Reset_Process()
{
	Stop_Timer1();
	NUM_MATCH_LED = LED_OFF;
	reset_sw_enable_flag = STATE_YES;
    cur_stage_time_expiry_flag = STATE_NO;
    cur_stage_time_enable_flag = STATE_NO;
    set_sw_enable_flag = STATE_YES;
	inc_sw_enable_flag = STATE_YES;
	inc_sw_pressed_flag = STATE_NO;
	//erase saved eeprom datas
	eeprom_write(EEPROM_SET_INC_NUM_ADDR, 0);
	eeprom_write(EEPROM_AUTO_INC_NUM_ADDR, 0);
	saved_set_sw_num = 0;
	auto_inc_num = 0;
	saved_auto_inc_num = 0;
    sw_inc_cur_num = 0;
	Write_LCD_Command(0x01);
	LCD_Const_Disp();
    Datas_LCD_Disp();
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 7   
-*------------------------------------------------------------*/
void Cur_Stage_Time_Run_Proc()
{	
    while(TMR1IF == 0); 	
	TMR1IF = 0;	
	timer1_init = (65536) - (INC1/prescale_timer1); 
    TMR1H = timer1_init / 256UL;
    TMR1L = timer1_init % 256UL; 	
    if(++num_calls_timer1 >= UPDATE_TIME1_CUR_STAGE)
     {
	     Cur_Stage_Time_Proc();                			 
         num_calls_timer1 = 0;        
     }	
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 6  
-*------------------------------------------------------------*/
void Cur_Stage_Time_Proc()
{	
	const char time_msg_disp[] = "T:";	
	 
   if(++count_update_cur_stage_per_sec % CUR_STAGE_TIME_FACTOR_PER_SEC  == 0 )
   { 
       count_update_cur_stage_per_sec = 0; 
       if(cur_stage_time_left == 0)
        {
		   cur_stage_time_expiry_flag = STATE_YES;	
           return;		   
	    } 
        --cur_stage_time_left; 
        ++auto_inc_num; 
		saved_auto_inc_num = auto_inc_num;		
	    eeprom_write(EEPROM_AUTO_INC_NUM_ADDR,saved_auto_inc_num );
		Goto_XY_LCD_Disp(AUTO_INC_LINE_NUM, AUTO_INC_COL_NUM ); 
        Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT3, saved_auto_inc_num); 		
    }  
 }  
void LCD_Const_Disp()
{
	const char sw_inc_msg_disp[] = "  SW INC:", auto_inc_msg_disp[] = "AUTO INC:", save_set_num_msg_disp[] = " SET NUM:";	
	
	Goto_XY_LCD_Disp(SW_INC_LINE_NUM, NUM_COL1);
	Data_Str_Disp_LCD(sw_inc_msg_disp);	
	Goto_XY_LCD_Disp(SAVED_SET_NUM_LINE_NUM, NUM_COL1);
	Data_Str_Disp_LCD(save_set_num_msg_disp);	
    Goto_XY_LCD_Disp(AUTO_INC_LINE_NUM, NUM_COL1);
	Data_Str_Disp_LCD(auto_inc_msg_disp);	
}
void Datas_LCD_Disp()
{
    Goto_XY_LCD_Disp(SAVED_SET_NUM_LINE_NUM, SAVED_SET_NUM_COL_NUM);
	Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT3,saved_set_sw_num );
	Goto_XY_LCD_Disp(AUTO_INC_LINE_NUM, AUTO_INC_COL_NUM );     
    Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT3, saved_auto_inc_num);
	Goto_XY_LCD_Disp(SW_INC_LINE_NUM, SW_INC_STATUS_COL_NUM);
	Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT3,sw_inc_cur_num );
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 15  
-*------------------------------------------------------------*/
void Run_Timer1(const unsigned int set_timer1_mode )
{
	// Stop_Timer1();
     /*internal timer1 clock  with 1:1 prescale,Timer1 counts when gate(T1G) is high 
     Timer1 counting is controlled by the Timer1 Gate function and no gate input is feed
     and enable timer1*/
	 
	 timer1_mode = set_timer1_mode;
	  /* for T1G gate based  timer 1 running control, Timer1 runs when T1G is high. If T1G is low, timer1 pauses counting */
	 // T1CON =0xC5; 

	 /*internal timer1 clock  with 1:1 prescale, gate(T1G) control for Timer1 is disabled  and enable timer1 and Timer1 runs */
      T1CON =0x85;   
      prescale_timer1 = 0x01;
      prescale_shift_timer1= 0;
      Prescale_Timer1();
      timer1_init = (65536UL) - (INC1/prescale_timer1); 
      TMR1H = timer1_init / 256UL;
      TMR1L = timer1_init % 256UL; 	  
      num_calls_timer1 = 0; 
      count_update_cur_stage_per_sec = 0;    
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 16  
-*------------------------------------------------------------*/
void Stop_Timer1()
{
	if(timer1_mode != TMR1_OFF_STATE)
	{	
	   timer1_mode = TMR1_OFF_STATE;
	   T1CON = 0x80;
	}   
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 17  
-*------------------------------------------------------------*/
void Prescale_Timer1()
{
   if(T1CKPS0 == 1)
   {
      prescale_shift_timer1 |= 0x01;           
   }
   if(T1CKPS1 == 1)
   {
     prescale_shift_timer1 |= 0x02;
   }  
   prescale_timer1 = prescale_timer1  << prescale_shift_timer1;                                                      
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 29   
-*------------------------------------------------------------*/
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num)
{
	/* max 4 lines and 20 columns */
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1, error_disp_start_loc; 
		
   if(start_line_num <= CONFIGURE_MAX_NUM_LINES && start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
      switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE4;
		   break;		 
	 }	
      cur_disp_lcd_loc = cur_disp_lcd_loc + start_col_lcd;
      Write_LCD_Command(cur_disp_lcd_loc);       
   }
   else
   {
	   /* error due to invalid lcd DISP loc  */    
		        		
   }	   
}

 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void LCD_Init()
{
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x38);
    Write_LCD_Command(0x01);
    Write_LCD_Command(0x0E); //insert cursor on at cur_disp_lcd_loc
	//Write_LCD_Command(0x0C);
    Write_LCD_Command(0x06);                                       
}     

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 23   
-*------------------------------------------------------------*/
  void Write_LCD_Command (unsigned int cmd)
  {
	  unsigned long int  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  
       RW_PIN = 0;
       RS_PIN = 0; 
       LCD_PORT = cmd;
      // LCD_Pulse();
	  EN_PIN = 1;
	  while(time_delay--);
    // Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
      EN_PIN = 0;
	  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  while(time_delay--);
   //  Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
 }
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 24   
-*------------------------------------------------------------*/
 void Write_LCD_Data(const char ch)
{
	unsigned long int  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	// performance degraded if many data is written to LCD, to check if write loc is within avail disp loc
	// if(lcd_avail_loc_within_limit == STATE_YES) 
	{	
      RW_PIN = 0;
      RS_PIN = 1;
      LCD_PORT =ch;
     // LCD_Pulse();
      EN_PIN = 1;
	  while(time_delay--);
    // Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
     EN_PIN = 0;
	 time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  while(time_delay--);
   //  Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);	 
	}
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 25   
-*------------------------------------------------------------*/

void Data_Str_Disp_LCD(const char *char_ptr)
{ 
       while(*char_ptr)
       {
            Write_LCD_Data(*(char_ptr++));
       }
     
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 27  
-*------------------------------------------------------------*/
void Delay_Time_ByCount( unsigned int time_delay)
{
       while(time_delay--);
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 26  
-*------------------------------------------------------------*/
void Data_Num_Disp_LCD(const unsigned int lcd_datanum_disp_format, const unsigned long lcd_disp_data_int)
{
    unsigned int tens_thousand_digit,thousands_digit, hundreds_digit,tens_digit, unit_digit;
    unsigned long num = lcd_disp_data_int;
    char num_data[] ={'0','1','2','3','4','5','6','7','8','9'};  
	char hex_data[] ={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'}; 
    switch(lcd_datanum_disp_format)
	{
	  case DISP_FLAG_NUM_DIGIT5: 
		  num =  lcd_disp_data_int % 100000;
		  tens_thousand_digit = (unsigned int)(num / (unsigned long)(10000));
          Write_LCD_Data(num_data[tens_thousand_digit]);
	  case DISP_FLAG_NUM_DIGIT4:
	      num = lcd_disp_data_int % 10000;
	      thousands_digit = (unsigned int)(num / (unsigned long)(1000));
	      Write_LCD_Data(num_data[thousands_digit]); 
	  case DISP_FLAG_NUM_DIGIT3: 
		  num = lcd_disp_data_int % 1000;
	      hundreds_digit = (unsigned int) (num / (unsigned long) (100));
	      Write_LCD_Data(num_data[hundreds_digit]);
	  case DISP_FLAG_NUM_DIGIT2:
          num = lcd_disp_data_int % 100;
          tens_digit = (unsigned int) (num / 10);
          Write_LCD_Data(num_data[tens_digit]); 		  
	  case DISP_FLAG_NUM_DIGIT1:
	     unit_digit = (unsigned int) (lcd_disp_data_int % 10);
         Write_LCD_Data(num_data[unit_digit]); 
	  break;
	  case DISP_FLAG_HEX_DIGIT4:
	      /*  ( 16 * 16 * 16 *16 )  = 0 as divide by zero warning */
	      //num = lcd_disp_data_int % ( 16 * 16 * 16 *16 );
          thousands_digit = (num / (16 * 16 * 16));
	      Write_LCD_Data(hex_data[thousands_digit]);
	  case DISP_FLAG_HEX_DIGIT3:
	      num = lcd_disp_data_int %(unsigned long)(16 * 16 * 16);
	      hundreds_digit = (unsigned int) (num / (unsigned long) (16 * 16));
	      Write_LCD_Data(hex_data[hundreds_digit]);
	  case DISP_FLAG_HEX_DIGIT2:
	      num = lcd_disp_data_int %(unsigned long)(16 * 16);
          tens_digit = (unsigned int) (num / 16);
          Write_LCD_Data(hex_data[tens_digit]);
	  case DISP_FLAG_HEX_DIGIT1: 
	      unit_digit = (unsigned int) (lcd_disp_data_int % 16);
          Write_LCD_Data(hex_data[unit_digit]);    
	  break;
	  default:
	     /* Warning invalid lcd_disp flag */
	    ;
	}   	
}
