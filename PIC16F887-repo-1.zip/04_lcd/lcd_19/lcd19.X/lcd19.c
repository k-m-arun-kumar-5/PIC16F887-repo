/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : Custom character generation and display custom character in LCD
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  : 


USED          :                           										
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include <xc.h>
#define RS_PIN                           RE0
#define RW_PIN                           RE1
#define EN_PIN                           RE2
#define LCD_PORT                         PORTD
#define LCD_PORT_GPIO                    TRISD 

#define EACH_DIGIT_DISP_DELAY_BY_COUNT    (30000UL)
#define LCD_ENABLE_PULSE_WIDTH            (1000ul)
#define NUM_CUSTOM_CHARS                  (8u)

void Delay_Time_By_Count(unsigned long int);
void LCD_Write_Pulse();
void LCD_Read_Pulse();
unsigned int Read_LCD_Command();
void Write_LCD_Command_Cannot_Check_BF(const unsigned int lcd_cmd);
void Write_LCD_Command (const unsigned int);
void Write_LCD_Data(const char);
void Data_Str_LCD_Disp(const char * );
void LCD_Init();
void Check_LCD_Busy();
void Custom_Character_Store();
void Display_Custom_Chars();
unsigned int read_command;

/********************************Character pattern (CGRAM datas) array to hold custom character patterns for 5 * 7 font *************************************/
unsigned char character_array[][8] = {{0x0E,0x11,0x0E,0x04,0x1F,0x04,0x1B,0x00},    // boy
                                      {0x00,0x00,0x1E,0x13,0x13,0x0C,0x1F,0x00},    // cup
                                      {0x00,0x0A,0x0A,0x00,0x11,0x0E,0x06,0x00},    // simley
                                      {0x00,0x00,0x1B,0x1F,0x0E,0x04,0x00,0x00},    // love
                                      {0x00,0x19,0x1A,0x04,0x0B,0x13,0x00,0x00},    // percentage
                                      {0x1F,0x11,0x0A,0x04,0x0A,0x15,0x1F,0x00},    // hour glass
                                      {0x00,0x1B,0x15,0x11,0x11,0x1F,0x00,0x00},    // mail folder
                                      {0x0E, 0x11, 0x1F, 0x15, 0x1F, 0x0A,0x0A}};   // android robo
void main()
{
	TRISE = 0x00;
	PORTE = 0x00;
    LCD_PORT_GPIO = 0x00;
    LCD_PORT = 0x00;
    ANSEL = 0x00;
    ANSELH = 0x00;
    LCD_Init();
    Custom_Character_Store();
	
    for(;;)
    {
         Display_Custom_Chars();		          
    }
}

void Custom_Character_Store()
{
    unsigned char cur_cusom_char_code =0, char_pattern_line_pos =0;
	
	//Set CGRAM address where we want to store custom char pattern
    //Write_LCD_Command(0x48);            
    //Delay_Time_By_Count(1000UL);         // Delay of 1millisec
 
    /**Store the custom character patterns in CGRAM area**/
    while(cur_cusom_char_code < NUM_CUSTOM_CHARS)		
    {
	  /* Set CGRAM address where we want to store custom char pattern and after setting, CGRAM address will automatically incremented or decremented
 		set by entry mode set, for every write to CGRAM */
        Write_LCD_Command(0x40 + (cur_cusom_char_code * NUM_CUSTOM_CHARS ));  
        for(char_pattern_line_pos =0; char_pattern_line_pos < 8; ++char_pattern_line_pos)
        {
		   /* data is written to CGRAM and automatically increment CGRAM address by 1 to current char pattern's next line position.
		     Incremented or decremented is set by entry mode set */
            Write_LCD_Data(character_array[cur_cusom_char_code][char_pattern_line_pos]);
        }
        ++cur_cusom_char_code;
    }
}
void Display_Custom_Chars()
{
     Write_LCD_Command(0x80);  // Force cursor to beginning of 1st line, if the number is 0x83 then force the cursor to 53rd position         
     Write_LCD_Data(0x00);     // DDRAM data = Character code = 0x00, locate the first character in CGRAM
     Write_LCD_Data(' ');      // space
     Write_LCD_Data(0x01);     // locate the second character in CGRAM
     Write_LCD_Data(' ');      // space
     Write_LCD_Data(0x02);     // locate the third character in CGRAM
     Write_LCD_Data(' ');      // space
     Write_LCD_Data(0x03);     // locate the fourth character in CGRAM
     Write_LCD_Data(' ');      // space
     Write_LCD_Data(0x04);     // locate the fifth character in CGRAM
     Write_LCD_Data(' ');      // space
     Write_LCD_Data(0x05);     // locate the sixth character in CGRAM
     Write_LCD_Data(' ');      // space
     Write_LCD_Data(0x06);     // locate the seventh character in CGRAM
     Write_LCD_Data(' ');      // space
     Write_LCD_Data(0x07);     // locate the eight character in CGRAM     
     Write_LCD_Data(' ');      // space 	
}
void LCD_Init()
{
	/* wait for more than 15ms after LCD VSS rises to 4.5V, Busy Flag in LCD (BF) cannot be checked */
	Delay_Time_By_Count(15000UL);
    Write_LCD_Command_Cannot_Check_BF(0x30);
	/* wait for more than 4.1 ms, Busy Flag in LCD (BF) cannot be checked */
	Delay_Time_By_Count(4100UL);
    Write_LCD_Command_Cannot_Check_BF(0x30);
	/* wait for more than 100 us, Busy Flag in LCD (BF) cannot be checked */
	Delay_Time_By_Count(100);
    Write_LCD_Command_Cannot_Check_BF(0x30);
	Write_LCD_Command(0x38);
	Write_LCD_Command(0x01);
	Write_LCD_Command(0x0E);
	Write_LCD_Command(0x06);  
	
}  
void LCD_Write_Pulse()
{
    EN_PIN = 1;
    Delay_Time_By_Count(LCD_ENABLE_PULSE_WIDTH);
    EN_PIN = 0;
    Delay_Time_By_Count(LCD_ENABLE_PULSE_WIDTH);
}
void LCD_Read_Pulse()
{
    EN_PIN = 0;
    Delay_Time_By_Count(LCD_ENABLE_PULSE_WIDTH);
    EN_PIN = 1;
    Delay_Time_By_Count(LCD_ENABLE_PULSE_WIDTH);	
}
void Write_LCD_Command_Cannot_Check_BF(const unsigned int lcd_cmd)
{
   RW_PIN = 0;
   RS_PIN = 0; 
   LCD_PORT = lcd_cmd;
   LCD_Write_Pulse();
}

void Check_LCD_Busy()
{
    LCD_PORT_GPIO = 0xFF;
	LCD_PORT = 0x00;
	RW_PIN = 1;
    RS_PIN = 0;
    
    /* busy flag = Bit 7 in LCD PORT, if busy flag == 1, wait till busy flag = 0, then any operation on LCD can be done */
   while(((read_command = Read_LCD_Command()) & 0x80) == 0x80)
   {
	   LCD_Read_Pulse();
	   LCD_Read_Pulse();
	   EN_PIN = 0;
	   Delay_Time_By_Count(LCD_ENABLE_PULSE_WIDTH);
   }	   
}
void Write_LCD_Command(const unsigned int lcd_cmd)
{
   Check_LCD_Busy();
   LCD_PORT_GPIO = 0x00;
   LCD_PORT = 0x00;
   RW_PIN = 0;
   RS_PIN = 0; 
   LCD_PORT = lcd_cmd;
   LCD_Write_Pulse();
}
 void Write_LCD_Data(const char lcd_data)
{
	 Check_LCD_Busy();
	 LCD_PORT_GPIO = 0x00; 
     LCD_PORT = 0x00;	 
     RW_PIN = 0;
     RS_PIN = 1;
     LCD_PORT = lcd_data;
     LCD_Write_Pulse();
}
void Data_Str_LCD_Disp(const char *char_ptr)
{ 
       while(*char_ptr)
       {	           
           Write_LCD_Data(*(char_ptr++));		  
       }
}
void Delay_Time_By_Count(unsigned long int time_delay)
{
     while(time_delay--);
}
unsigned int Read_LCD_Command()
{
	 LCD_Write_Pulse();
	 read_command = LCD_PORT;	 
     return read_command;
}

