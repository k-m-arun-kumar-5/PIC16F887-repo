/* ********************************************************************
FILE                   : lcd1.c

PROGRAM DESCRIPTION    :  display  periodic number from 0 to 9 in LCD at a static location

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
             Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                   
                       
CHANGE LOGS           : 

*****************************************************************************/ 

#include <pic.h>
#define RS_PIN                           RE0
#define RW_PIN                           RE1
#define EN_PIN                           RE2

#define LCD_PORT                         PORTD
#define LCD_PORT_GPIO                    TRISD 

#define _XTAL_FREQ       (4000000)
 __CONFIG(0x2ce4); 
 
void delay_time(unsigned int);
void pulse ();
 void lcd_command (unsigned int);
void lcd_data(char);
void data_str(const char * );
void lcd_init(); 
void main()
{
         char ch = '0';
         
          LCD_PORT_GPIO =  0x00;          
          LCD_PORT = 0x00;
		  TRISE = 0x00;
          PORTE = 0x00;
        ANSEL = 0x00;
        ANSELH = 0x00;
        lcd_init(); 
      
          for(;;)
          {
             for(ch = '0'; ch <= '9' ;  ch++)
            {
                  lcd_command (0x80); 
                  lcd_data( ch); 
                  __delay_ms(3000);
               
           }
                     
           }
}
void lcd_init()
{
    lcd_command(0x30);
    lcd_command(0x30);
    lcd_command(0x30);
    lcd_command(0x38);
    lcd_command(0x01);
    lcd_command(0x0E);
    lcd_command(0x06);                                       
}  
void pulse()
{
        EN_PIN = 1;
        delay_time(1000);
         EN_PIN = 0;
        delay_time(1000);
}
  void lcd_command (unsigned int cmd)
       {
         RW_PIN = 0;
         RS_PIN = 0; 
         LCD_PORT = cmd;
         pulse();
       }
 void lcd_data(char ch)
{
     RW_PIN = 0;
     RS_PIN = 1;
     LCD_PORT =ch;
     pulse();
}
void data_str(const char *char_ptr)
{ 
       while(*char_ptr)
       {
                lcd_data(*(char_ptr++));
       }
}

void delay_time(unsigned int time_delay)
{
         while(time_delay--);
}
