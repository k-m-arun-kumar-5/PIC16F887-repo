/* ********************************************************************
FILE                   : lcd1.c

PROGRAM DESCRIPTION    :  display a character 'A' in LCD

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
             Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                   
                       
CHANGE LOGS           : 

*****************************************************************************/ 
#include <pic.h>
#define RS_PIN  RD0
#define RW_PIN RD1
#define EN_PIN RD2
#define LCD_PORT  PORTC
void delay_time(unsigned int);
void pulse ();
 void lcd_type ();
void display_on();
void address();
 void display_data(); 
 void lcd_init();
void main()
{
          TRISD =  0x00; 
          TRISC = 0x00;
         PORTC = 0x00;
         PORTD = 0x00;
        ANSEL = 0x00;
        ANSELH = 0x00;
		
        lcd_type();
        display_on();
        address();  
       display_data();
}

void pulse()
{
        EN_PIN = 1;
        delay_time(1000);
         EN_PIN = 0;
        delay_time(1000);
}
  void lcd_type ()
       {
         RW_PIN = 0;
         RS_PIN = 0; 
         LCD_PORT = 0x38;
         pulse();
       }

void display_on()
{  
       RW_PIN = 0;
        RS_PIN = 0; 
        LCD_PORT = 0x0E;
        pulse();  
}
void address()
{
         RW_PIN = 0;
        RS_PIN = 0;
         LCD_PORT = 0x80;
        pulse();
}
 void display_data()
{
     RW_PIN = 0;
     RS_PIN = 1;
     LCD_PORT ='A';
    pulse();
}
void delay_time(unsigned int time_delay)
{
         while(time_delay--);
}

















