/* ********************************************************************
FILE                   : lcd13.c

PROGRAM DESCRIPTION    : display  periodic number from 0 to 9 in LCD at a static location and also with corresponding  number in words and use busy flag in LCD rather than time delay, wherever applicable, for to do next operation on LCD

AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
                                   
CHANGE LOGS           : 

*****************************************************************************/  
#include <xc.h>
#define RS_PIN                           RC0
#define RW_PIN                           RC1
#define EN_PIN                           RC2
#define LCD_PORT                         PORTD
#define LCD_PORT_GPIO                    TRISD 

#define EACH_DIGIT_DISP_DELAY_BY_COUNT    (30000UL)
#define LCD_ENABLE_PULSE_WIDTH            (1000ul)

void Delay_Time_By_Count(unsigned long int);
void LCD_Write_Pulse();
void LCD_Read_Pulse();
unsigned int Read_LCD_Command();
void Write_LCD_Command_Cannot_Check_BF(const unsigned int lcd_cmd);
void Write_LCD_Command (const unsigned int);
void Write_LCD_Data(const char);
void Data_Str_LCD_Disp(const char * );
void LCD_Init();
void Check_LCD_Busy();

unsigned int read_command;
void main()
{
    char unit_ch = '0';
    char num_words[][6] = {"ZERO ", "ONE  ", "TWO  ", "THREE", "FOUR ", "FIVE ", "SIX  ", "SEVEN", "EIGHT", "NINE "};
    unsigned int num = 0;
	
    TRISC =  0x00; 
	PORTC = 0x00;
    LCD_PORT_GPIO = 0x00;
    LCD_PORT = 0x00;
    ANSEL = 0x00;
    ANSELH = 0x00;
    LCD_Init();
      
    for(;;)
    {
       for(unit_ch = '0', num = 0; unit_ch <= '9'; unit_ch++, num++)
       {
		  Write_LCD_Command(0x80); 		  
          Write_LCD_Data(unit_ch); 
		  Write_LCD_Command(0xC0);		  
          Data_Str_LCD_Disp(num_words[num]);
          Delay_Time_By_Count(EACH_DIGIT_DISP_DELAY_BY_COUNT);
       }     
    }
}
void LCD_Init()
{
	/* wait for more than 15ms after LCD VSS rises to 4.5V, Busy Flag in LCD (BF) cannot be checked */
	Delay_Time_By_Count(15000UL);
    Write_LCD_Command_Cannot_Check_BF(0x30);
	/* wait for more than 4.1 ms, Busy Flag in LCD (BF) cannot be checked */
	Delay_Time_By_Count(4100UL);
    Write_LCD_Command_Cannot_Check_BF(0x30);
	/* wait for more than 100 us, Busy Flag in LCD (BF) cannot be checked */
	Delay_Time_By_Count(100);
    Write_LCD_Command_Cannot_Check_BF(0x30);
	Write_LCD_Command(0x38);
	Write_LCD_Command(0x01);
	Write_LCD_Command(0x0E);
	Write_LCD_Command(0x06);  
	
}  
void LCD_Write_Pulse()
{
    EN_PIN = 1;
    Delay_Time_By_Count(LCD_ENABLE_PULSE_WIDTH);
    EN_PIN = 0;
    Delay_Time_By_Count(LCD_ENABLE_PULSE_WIDTH);
}
void LCD_Read_Pulse()
{
    EN_PIN = 0;
    Delay_Time_By_Count(LCD_ENABLE_PULSE_WIDTH);
    EN_PIN = 1;
    Delay_Time_By_Count(LCD_ENABLE_PULSE_WIDTH);	
}
void Write_LCD_Command_Cannot_Check_BF(const unsigned int lcd_cmd)
{
   RW_PIN = 0;
   RS_PIN = 0; 
   LCD_PORT = lcd_cmd;
   LCD_Write_Pulse();
}

void Check_LCD_Busy()
{
    LCD_PORT_GPIO = 0xFF;
	LCD_PORT = 0x00;
	RW_PIN = 1;
    RS_PIN = 0;
    
    /* busy flag = Bit 7 in LCD PORT, if busy flag == 1, wait till busy flag = 0, then any operation on LCD can be done */
   while(((read_command = Read_LCD_Command()) & 0x80) == 0x80)
   {
	   LCD_Read_Pulse();
	   LCD_Read_Pulse();
	   EN_PIN = 0;
	   Delay_Time_By_Count(LCD_ENABLE_PULSE_WIDTH);
   }	   
}
void Write_LCD_Command(const unsigned int lcd_cmd)
{
   Check_LCD_Busy();
   LCD_PORT_GPIO = 0x00;
   LCD_PORT = 0x00;
   RW_PIN = 0;
   RS_PIN = 0; 
   LCD_PORT = lcd_cmd;
   LCD_Write_Pulse();
}
 void Write_LCD_Data(const char lcd_data)
{
	 Check_LCD_Busy();
	 LCD_PORT_GPIO = 0x00; 
     LCD_PORT = 0x00;	 
     RW_PIN = 0;
     RS_PIN = 1;
     LCD_PORT = lcd_data;
     LCD_Write_Pulse();
}
void Data_Str_LCD_Disp(const char *char_ptr)
{ 
       while(*char_ptr)
       {	           
           Write_LCD_Data(*(char_ptr++));		  
       }
}
void Delay_Time_By_Count(unsigned long int time_delay)
{
     while(time_delay--);
}
unsigned int Read_LCD_Command()
{
	 LCD_Write_Pulse();
	 read_command = LCD_PORT;	 
     return read_command;
}

