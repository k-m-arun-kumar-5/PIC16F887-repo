/* ********************************************************************
FILE                   : lcd_07.c

PROGRAM DESCRIPTION    : a preset password and account number is set by default in code. 
Entered password in keypad is displayed in  LCD. Use RESET_SW to reset Process and start afresh.
USe Enter SW to end input and entered data is at end.
If entered account number is correct, then ask for PIN  and if entered PIN is correct,
then display Next stage. If account number is incorrect and ask to reenter account number.
After 3 failed iteration on entered account number, stop reenter of account number and display visit bank.
After 3 failed iteration on entered PIN number,stop reenter of PIN number and display visit bank.

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : base code for lcd14 code.
 
USED:              
             Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                   
                       
CHANGE LOGS           : 

*****************************************************************************/ 

#include <xc.h>
#include <string.h>
#define MAX_ROW  4
#define MAX_COL   3
#define _XTAL_FREQ 4000000
//__CONFIG(0X2CE4);

#define  KEYPAD_PHONE_COL1  RA0
#define  KEYPAD_PHONE_COL2  RA1
#define  KEYPAD_PHONE_COL3  RA2
#define  KEYPAD_PHONE_ROWA RA3
#define  KEYPAD_PHONE_ROWB RA4
#define  KEYPAD_PHONE_ROWC RA5
#define  KEYPAD_PHONE_ROWD RA6
#define  LONG_PRESS_KEY_LED_PIN RA7  
#define RS_PIN                                  RD0
#define RW_PIN                                 RD1
#define EN_PIN                                 RD2
#define ENTER_SW                               RD3
#define RESET_SW                               RD4 
#define BACKSPACE_SW                           RD5                                                       
#define LCD_PORT                          PORTC
#define MAX_TIMEOUT_KEY                   (50000UL)
#define ACCOUNT_TYPE                     01
#define PIN_TYPE                         02
void delay_time(unsigned int);
void pulse ();
void lcd_command (unsigned int);
void lcd_data(char);
void data_str(const char * );
void lcd_init();
void data_reset();
void entered_key(const unsigned int);
char disp_flag = 'y', input_flag = 'y', input_key_flag = 'y',timeout_key_flag = 'n' ;
unsigned int cur_loc = 0x80, num_char = 0;  
char data_type = ACCOUNT_TYPE;
char entered_data[16];
int failed_data_entry = 0; 
const int max_acc_reentry = 3, max_pin_reentry = 3;
int max_entry = 0;
const char account_str[] =  {"Enter Account"};
unsigned long int timeout_key = MAX_TIMEOUT_KEY; 
void main()
{
        char keypad_char[]   = {'1','2', '3', '4', '5', '6','7','8','9','*', '0', '#'};
        const char default_account[] = {"56789"};       
        const char pin_str[] = {"Enter PIN"}, default_pin[] = "1234";
        const char correct_pin_disp[] = "Successful Auth", incorrect_process_disp[] = "Visit Bank";
        const char incorrect_acc_disp[]= "Reenter Account",incorrect_pin_disp[] = "Reenter PIN";   
        const char max_acc_try_disp[]=  "Max Acc exceed", max_pin_try_disp[] = {"Max PIN exceed"};
       
                                                 
        TRISA = 0x07;
        TRISC = 0x00;
       TRISD  = 0x38;
       PORTA = 0x00;
       PORTC = 0x00;
       PORTD = 0x00;
       ANSEL = 0x00;
       ANSELH = 0x00;
       lcd_init();
       data_reset();
       
       for(;;)
      {                 
                if(failed_data_entry < max_entry)
                {             
                while(disp_flag == 'y' && input_flag == 'y')
                { 
                KEYPAD_PHONE_ROWA = 1;
                KEYPAD_PHONE_ROWB  = 0;
                KEYPAD_PHONE_ROWC  = 0;
                KEYPAD_PHONE_ROWD  = 0; 
                    if(KEYPAD_PHONE_COL1 == 1 && input_key_flag =='y' )
                   {
                         while(KEYPAD_PHONE_COL1 == 1 && (--timeout_key != 0 ) );
                          if(timeout_key == 0 )
                          {
                             LONG_PRESS_KEY_LED_PIN = 1;
                             timeout_key_flag = 'y';                                      
                          }
                          if(timeout_key_flag == 'n')
                          {   
                           entered_key(keypad_char[0]); 
                           LONG_PRESS_KEY_LED_PIN = 0;
                           timeout_key = MAX_TIMEOUT_KEY;                                            
                          }                                                                                                              
                   }
                   if (KEYPAD_PHONE_COL2 == 1 && input_key_flag =='y' )
                  {
                          while(KEYPAD_PHONE_COL2 == 1 && (--timeout_key  !=0));
                          if(timeout_key == 0)
                          {
                             LONG_PRESS_KEY_LED_PIN = 1;
                             timeout_key_flag = 'y';  
                          }
                         if(timeout_key_flag == 'n')
                          {   
                           entered_key(keypad_char[1]); 
                           LONG_PRESS_KEY_LED_PIN = 0;
                           timeout_key =  MAX_TIMEOUT_KEY; 
                          }
                                                    
                  }
                     if (KEYPAD_PHONE_COL3 == 1 && input_key_flag =='y')
                    {
                          while(KEYPAD_PHONE_COL3 == 1 && (--timeout_key  !=0));
                          if(timeout_key == 0)
                          {
                             LONG_PRESS_KEY_LED_PIN = 1;
                             timeout_key_flag = 'y';  
                          }
                         if(timeout_key_flag == 'n')
                          {   
                           entered_key(keypad_char[2]); 
                           LONG_PRESS_KEY_LED_PIN = 0;
                           timeout_key =  MAX_TIMEOUT_KEY; 
                          }
                                                                   
                   }  
                KEYPAD_PHONE_ROWA = 0;
                KEYPAD_PHONE_ROWB  = 1;
                KEYPAD_PHONE_ROWC  = 0;
                KEYPAD_PHONE_ROWD  = 0; 
                    if(KEYPAD_PHONE_COL1 == 1 && input_key_flag =='y' )
                     {
                        while(KEYPAD_PHONE_COL1 == 1 && (--timeout_key  !=0));
                          if(timeout_key == 0)
                          {
                             LONG_PRESS_KEY_LED_PIN = 1;
                             timeout_key_flag = 'y';  
                          }
                         if(timeout_key_flag == 'n')
                          {   
                           entered_key(keypad_char[3]); 
                           LONG_PRESS_KEY_LED_PIN = 0;
                           timeout_key =  MAX_TIMEOUT_KEY; 
                          }
                                                                
                    }
                   if (KEYPAD_PHONE_COL2 == 1 && input_key_flag =='y')
                    {
                      while(KEYPAD_PHONE_COL2 == 1 && (--timeout_key  !=0));
                          if(timeout_key == 0)
                          {
                             LONG_PRESS_KEY_LED_PIN = 1;
                             timeout_key_flag = 'y';  
                          }
                         if(timeout_key_flag == 'n')
                          {   
                           entered_key(keypad_char[4]); 
                           LONG_PRESS_KEY_LED_PIN = 0;
                           timeout_key =  MAX_TIMEOUT_KEY; 
                          }                
                                                                                                          
                    }
                     if (KEYPAD_PHONE_COL3 == 1 && input_key_flag =='y' )
                     {   
                         while(KEYPAD_PHONE_COL3 == 1 && (--timeout_key  !=0));
                          if(timeout_key == 0)
                          {
                             LONG_PRESS_KEY_LED_PIN = 1;
                             timeout_key_flag = 'y';  
                          }
                         if(timeout_key_flag == 'n')
                          {   
                           entered_key(keypad_char[5]); 
                           LONG_PRESS_KEY_LED_PIN = 0;
                           timeout_key =  MAX_TIMEOUT_KEY; 
                          }                       
                     }
                KEYPAD_PHONE_ROWA = 0;
                KEYPAD_PHONE_ROWB  = 0;
                KEYPAD_PHONE_ROWC  = 1;
                KEYPAD_PHONE_ROWD  = 0; 
                    if(KEYPAD_PHONE_COL1 == 1 && input_key_flag =='y' )
                   {
                       while(KEYPAD_PHONE_COL1 == 1 && (--timeout_key  !=0));
                          if(timeout_key == 0)
                          {
                             LONG_PRESS_KEY_LED_PIN = 1;
                             timeout_key_flag = 'y';  
                          }
                         if(timeout_key_flag == 'n')
                          {   
                           entered_key(keypad_char[6]); 
                           LONG_PRESS_KEY_LED_PIN = 0;
                           timeout_key =  MAX_TIMEOUT_KEY; 
                          }              						
                   }
                   if (KEYPAD_PHONE_COL2 == 1 && input_key_flag =='y')
                 {
                     while(KEYPAD_PHONE_COL2 == 1 && (--timeout_key  !=0));
                          if(timeout_key == 0)
                          {
                             LONG_PRESS_KEY_LED_PIN = 1;
                             timeout_key_flag = 'y';  
                          }
                         if(timeout_key_flag == 'n')
                          {   
                           entered_key(keypad_char[7]); 
                           LONG_PRESS_KEY_LED_PIN = 0;
                           timeout_key =  MAX_TIMEOUT_KEY; 
                          }    						
                 }  
                     if (KEYPAD_PHONE_COL3 == 1 && input_key_flag =='y')
                      { 
                         while(KEYPAD_PHONE_COL3 == 1 && (--timeout_key  !=0));
                          if(timeout_key == 0)
                          {
                             LONG_PRESS_KEY_LED_PIN = 1;
                             timeout_key_flag = 'y';  
                          }
                         if(timeout_key_flag == 'n')
                          {   
                           entered_key(keypad_char[8]); 
                           LONG_PRESS_KEY_LED_PIN = 0;
                           timeout_key =  MAX_TIMEOUT_KEY; 
                          }    							
                      } 
                KEYPAD_PHONE_ROWA = 0;
                KEYPAD_PHONE_ROWB  = 0;
                KEYPAD_PHONE_ROWC  = 0;
                KEYPAD_PHONE_ROWD  = 1; 
                /* if (KEYPAD_PHONE_COL1 == 1 && input_key_flag =='y')
                  {
                      entered_key(keypad_char[9]); 				
					  while(KEYPAD_PHONE_COL1 == 1);
					
                  }  */  
                   if (KEYPAD_PHONE_COL2 == 1 && input_key_flag =='y' )
                  {
                   	   while(KEYPAD_PHONE_COL2 == 1 && (--timeout_key  !=0));
                          if(timeout_key == 0)
                          {
                             LONG_PRESS_KEY_LED_PIN = 1;
                             timeout_key_flag = 'y';  
                          }
                         if(timeout_key_flag == 'n')
                          {   
                           entered_key(keypad_char[10]); 
                           LONG_PRESS_KEY_LED_PIN = 0;
                           timeout_key =  MAX_TIMEOUT_KEY; 
                          }
					
                  }                                                          
                /*  if (KEYPAD_PHONE_COL3 == 1 && input_key_flag =='y' )
                  {
                      entered_key(keypad_char[11]);  				
					  while(KEYPAD_PHONE_COL3 == 1);					 
                  }*/
                  if(ENTER_SW == 1)
                  {
                  
                  while(ENTER_SW == 1  && (--timeout_key!=0)); 
                  if(timeout_key ==0)   
                  {
                   LONG_PRESS_KEY_LED_PIN = 1;
                   timeout_key_flag = 'y';          
                  }
                  if(timeout_key_flag == 'n')
                  {
                   entered_data[num_char] = '\0'; 
                   LONG_PRESS_KEY_LED_PIN = 0;  
                   timeout_key =  MAX_TIMEOUT_KEY; 
                  } 
                  input_key_flag = 'y';                            
                  break;                   
                 }
                 if(cur_loc == 0xCF)
                    input_key_flag ='n';
                 else
                   input_key_flag ='y';
                 if(BACKSPACE_SW == 1)
                {
                  while(BACKSPACE_SW == 1  && (--timeout_key!=0)); 
                  if(timeout_key ==0)   
                  {
                   LONG_PRESS_KEY_LED_PIN = 1;
                   timeout_key_flag = 'y';          
                  }
                  if(timeout_key_flag == 'n')
                  {
                     if(cur_loc != 0xC0)
                     {
                       --cur_loc;
                       lcd_command(cur_loc);
                       --num_char;
                       lcd_data(' '); 
                       lcd_command(0x10); //shift cursor to left                            
                     }         
                   entered_data[num_char] = '\0'; 
                   LONG_PRESS_KEY_LED_PIN = 0;  
                   timeout_key =  MAX_TIMEOUT_KEY; 
                  }  
                }                            
                timeout_key_flag = 'n';     
            }
            if(disp_flag == 'y')
            { 
            lcd_command(0x01); //clear display
            lcd_command(0x0c); // display on , cursor and blinking off
                       
            switch(data_type)
            {
              case ACCOUNT_TYPE: 
              if(strcmp(entered_data,default_account)== 0)
             {
               data_str(pin_str);
               data_type = PIN_TYPE;
               failed_data_entry = 0;
               cur_loc = 0xC0;
               lcd_command(cur_loc);
               lcd_command(0x0e);
               max_entry = max_pin_reentry;                                                                    
             } 
             else
            {
               if(failed_data_entry < max_entry - 1 )
                 data_str(incorrect_acc_disp); 
               ++failed_data_entry;
               cur_loc = 0xC0;
                lcd_command(cur_loc);
               lcd_command(0x0e);
                                                 
            }
            break;
            case  PIN_TYPE:
            if(strcmp(entered_data,default_pin)== 0)
             {
               data_str(correct_pin_disp);
               failed_data_entry = 0;
               input_flag ='n';
               disp_flag = 'n';                                                                                     
             } 
            else
            {
             if(failed_data_entry < max_entry - 1 )
               data_str(incorrect_pin_disp); 
             ++failed_data_entry; 
             cur_loc = 0xC0;
             lcd_command(cur_loc);
             lcd_command(0x0e);                          
            }
            break;                                              
          }
          num_char = 0;
          memset(entered_data, sizeof(entered_data)/sizeof(char), '\0');                                                                       
      }                    
         }
         else
         {
           if(disp_flag == 'y')
           {                                             
           lcd_command(0x01); //clear display
           lcd_command(0x0c);
           switch(data_type)
           {
             case ACCOUNT_TYPE:
             data_str(max_acc_try_disp);
             cur_loc=0xC0;
             lcd_command(cur_loc);                       
             data_str(incorrect_process_disp);
             disp_flag = 'n';
             input_flag = 'n';                                           
             break;
             case PIN_TYPE:
             data_str(max_pin_try_disp);
             cur_loc=0xC0;
             lcd_command(cur_loc);
             data_str(incorrect_process_disp);
             disp_flag = 'n';
             input_flag = 'n';                                     
             break;
           }
          }                         
         }
            
     if(RESET_SW == 1)
     {
         
        while(RESET_SW == 1 && (--timeout_key != 0));
        if(timeout_key == 0)
        {
         LONG_PRESS_KEY_LED_PIN = 1;
         timeout_key_flag = 'y'; 
        }
        else
        {
           data_reset();                                                    
        }                                                          
     }
   } 
}
 void lcd_init()
{
    lcd_command(0x30);
    lcd_command(0x30);
    lcd_command(0x30);
    lcd_command(0x38);  
    lcd_command(0x0E);
    lcd_command(0x06);                                       
}     

void pulse()
{
        EN_PIN = 1;
        delay_time(1000);
         EN_PIN = 0;
        delay_time(1000);
}
  void lcd_command (unsigned int cmd)
       {
         RW_PIN = 0;
         RS_PIN = 0; 
         LCD_PORT = cmd;
         pulse();
       }
 void lcd_data(char ch)
{
     RW_PIN = 0;
     RS_PIN = 1;
     LCD_PORT =ch;
     pulse();
}
void data_str(const char *char_ptr)
{ 
       while(*char_ptr)
       {
                lcd_data(*(char_ptr++));
       }
}

void delay_time(unsigned int time_delay)
{
       while(time_delay--);
}
void data_reset()
{
  disp_flag = 'y';
  input_flag ='y';
  input_key_flag = 'y';
  timeout_key_flag = 'n';        
  data_type = ACCOUNT_TYPE;
  failed_data_entry = 0;
  lcd_command(0x01); //clear display
  lcd_command(0x0e); // display on , cursor and blinking on
  cur_loc = 0x80;
  lcd_command(cur_loc);
  data_str(account_str);
  cur_loc = 0xC0; 
 lcd_command(cur_loc);
  memset(entered_data, sizeof(entered_data)/sizeof(char), '\0');
  num_char = 0; 
  max_entry= max_acc_reentry;
  timeout_key = MAX_TIMEOUT_KEY;
  LONG_PRESS_KEY_LED_PIN = 0;        
}
void entered_key(const unsigned int key_data)
{
   lcd_command(cur_loc);
   switch(data_type)
   {
     case ACCOUNT_TYPE:
      lcd_data(key_data);
      break;
     case PIN_TYPE:
      lcd_data(key_data);
      delay_time(20000);
      lcd_command(cur_loc); 
      lcd_data('*');
      break;
   }
   entered_data[num_char] =key_data;
   ++num_char;
   ++cur_loc; 
}


