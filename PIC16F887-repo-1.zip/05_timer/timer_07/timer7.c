/* ********************************************************************
FILE                   : timer7.c

PROGRAM DESCRIPTION    :  Single traffic light control sequence using timer1 and using internal timer1 clock
If gate is feed to timer1, it should be 1 to run/continue traffic sequence. 
  If gate is 0, traffic sequence should pause

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : fix issue of timer to get precise time using timer. Use PIC16F887-repo->05_timer->timer17.X->timer.c as base code to get precise time using timer.

NOTE                  : 
                       
CHANGE LOGS           : 

*****************************************************************************/  
  
#include <pic.h>
#define RED_PIN                     RB0
#define YELLOW_PIN                  RB1
#define GREEN_PIN                   RB2  
#define RS_PIN                       RE0
#define RW_PIN                       RE1
#define EN_PIN                       RE2
#define LCD_PORT                     PORTD
#define FIRST_LINE                   (0x80)
#define SECOND_LINE                  (0xC0)
#define THIRD_LINE                   (0x94)
#define FOURTH_LINE                  (0xD4)  
#define LED_OFF                      (0)
#define LED_ON                       (1)  
#define TICK_MS  (50UL) // TIMER1 expires every 50ms
#define TIME_UNIT (1000UL)
#define OSC_PER_INST (4)
#define UPDATE_TIME (1000UL)/TICK_MS //UPDATE_TIME configured for 1 sec
#define _XTAL_FREQ   (4000000UL)
#define INC (unsigned int)((unsigned long)(_XTAL_FREQ * TICK_MS) / (unsigned long)(OSC_PER_INST * TIME_UNIT))
#define STOP_FSM    (1)
#define GO_FSM      (2)
#define WAIT_FSM    (3)

#define STOP_TIME    (20) // 20 sec on time
#define WAIT_TIME   (5) // 5 sec off time 
#define GO_TIME     (15)
// duration of Traffic Lights words display on and Blank display
#define MAX_TRAFFIC_DISP (2) 
#define DISP_TRAFFIC_FSM (1) 
#define DISP_BLANK_FSM   (2)                    
__CONFIG(0X2CE4);

void delay_time(unsigned int);
void pulse();
void lcd_command (unsigned int);
void lcd_data(char);
void data_str(const char * );
void data_2digit(unsigned int);
void lcd_init();
void Traffic_Init(unsigned int, unsigned int);
void Goto_XY_LCD(unsigned int line,unsigned int col);
void LCD_Const_Disp();
unsigned int prescale_timer1 = 0x01, prescale_shift= 0,num_sec = 0;
unsigned int timer1_init = 0;
unsigned long int num_calls = 0;
unsigned int traffic_fsm_state =STOP_FSM ;
const char led_on_disp[] = " ON", led_off_disp[] = "OFF", \
header_disp[]= "Traffic Lights",secs_disp[]={"Secs"},blank_disp[]={"              "}, \
red_disp[]= "RED   ", yellow_disp[]= {"YELLOW"}, green_disp[]={"GREEN "};
unsigned int cur_loc = FIRST_LINE;
unsigned int red_off_secs = 0, yellow_off_secs = 0, green_off_secs = 0;
unsigned int traffic_disp_sec =0, traffic_disp_fsm=DISP_TRAFFIC_FSM ; 
void Stop_Fsm_Proc();
void Wait_Fsm_Proc();
void Go_Fsm_Proc();
void Prescale_Timer1();     
void Timer1_Tick();
void Traffic_Fsm();
void Disp_Header_Fsm();
void Test_Goto_XY_LCD(unsigned int line,unsigned int col);
void data_2digit_hex(unsigned int data_int);
void Run_Timer1();
void main()
{
   TRISA = 0x00;
   PORTA = 0x00;
   TRISB = 0x00;
   PORTB = 0x00;
   TRISC = 0x00;
   PORTC = 0x00;
   TRISD = 0x00;
   PORTD = 0x00;
   TRISE = 0x00;
   PORTE = 0x00;  
   ANSEL =0X00;
   ANSELH=0X00;

   Run_Timer1();
   LCD_Const_Disp();
   Traffic_Init(STOP_FSM,DISP_TRAFFIC_FSM);       
   for(;;)
   {
     Timer1_Tick();
     //Test_Goto_XY_LCD(3,19);
  } 
}
void Run_Timer1()
{
/*internal timer1 clock  with 1:1 prescale,Timer1 counts when gate is high 
 Timer1 counting is controlled by the Timer1 Gate function */
   T1CON =0xC5;   
   prescale_timer1 =  0x01;
   prescale_shift= 0;
   Prescale_Timer();
   timer1_init = 65536 - (INC/prescale_timer1); 
   TMR1H = timer1_init / 256;
   TMR1L = timer1_init % 256;
}   
void Timer1_Tick()
{
     while(TMR1IF == 0);
     TMR1IF = 0;
     timer1_init = 65536 - (INC/prescale_timer1); 
     TMR1H = timer1_init / 256;
     TMR1L = timer1_init % 256; 
     if(++num_calls >= UPDATE_TIME)
     {
        Traffic_Fsm();
        num_calls = 0;        
     }       
} 
/* Every 1 second Traffic_Fsm() is called*/                                                                                                                                                                                                                                                                                                                      
void Traffic_Fsm()
{
    if(++traffic_disp_sec >= MAX_TRAFFIC_DISP)
    {
       traffic_disp_sec =0;
       Disp_Header_Fsm(); 
    }
       
    switch(traffic_fsm_state)
    {
      case STOP_FSM:
      ++num_sec;
      ++yellow_off_secs;
      ++green_off_secs;   
      if(num_sec >= STOP_TIME )
      {
        num_sec = 0;
        traffic_fsm_state = GO_FSM;
        green_off_secs =0;
        Go_Fsm_Proc(); 
        break;              
      }          
      Stop_Fsm_Proc();
      break;
     case GO_FSM:
      ++num_sec;  
      ++red_off_secs; 
      ++yellow_off_secs;               
      if(num_sec >= GO_TIME )
      {
        num_sec = 0;
        yellow_off_secs =0;
        traffic_fsm_state  =WAIT_FSM; 
        Wait_Fsm_Proc(); 
        break;               
      }
      Go_Fsm_Proc(); 
      break;        
      case WAIT_FSM:
      ++num_sec;
      ++red_off_secs;
      ++green_off_secs;                   
      if(num_sec >= WAIT_TIME )
      {
        num_sec = 0;
        red_off_secs = 0;
        traffic_fsm_state =STOP_FSM; 
        Stop_Fsm_Proc(); 
        break;               
      }
      Wait_Fsm_Proc(); 
      break;
    }    
}

void Prescale_Timer1()
{
   if(T1CKPS0 == 1)
   {
      prescale_shift |= 0x01;           
   }
   if(T1CKPS1 == 1)
   {
     prescale_shift |= 0x02;
   }  
   prescale_timer1 = prescale_timer1  << prescale_shift;                                                      
}
void lcd_init()
{
    lcd_command(0x30);
    lcd_command(0x30);
    lcd_command(0x30);
    lcd_command(0x38); 
    lcd_command(0x01);	
    lcd_command(0x0C);
    lcd_command(0x06);                                       
}     

void pulse()
{
        EN_PIN = 1;
        delay_time(100);
         EN_PIN = 0;
        delay_time(100);
}
  void lcd_command (unsigned int cmd)
 {
         RW_PIN =0;
         RS_PIN = 0; 
         LCD_PORT = cmd;
         pulse();
 }
 void lcd_data(char ch)
{
     RW_PIN = 0;
     RS_PIN = 1;
     LCD_PORT =ch;
     pulse();
} 
void data_str(const char *char_ptr)
{ 
       while(*char_ptr)
       {
           lcd_data(*(char_ptr++));
       }
}
void data_2digit(unsigned int data_int)
{
    unsigned int tens_digit, unit_digit,num;
    char num_data[] ={'0','1','2','3','4','5','6','7','8','9'}; 
    num = data_int %100;
    unit_digit = data_int % 10;
    tens_digit = num / 10;
    lcd_data(num_data[tens_digit]);
   // lcd_data(tens_digit + 30); // num in ascii code   
    lcd_data(num_data[unit_digit]); 
   // lcd_data(unit_digit + 30); // num in ascii code                                 
}
void data_2digit_hex(unsigned int data_int)
{
    unsigned int tens_digit, unit_digit,num;
    char hex_data[] ={'0','1','2','3','4','5','6','7','8','9', 'A','B','C','D','E','F'};  
	num = data_int %256;
    unit_digit = data_int % 16;
    tens_digit = num / 16;
    lcd_data(hex_data[tens_digit]);
    lcd_data(hex_data[unit_digit]);                                
}
void delay_time(unsigned int time_delay)
{
    while(time_delay--);
} 
void Goto_XY_LCD(unsigned int line,unsigned int col)
{
   if(line < 4 && col < 20 )
   {
     cur_loc = FIRST_LINE;
    if(line & 0x01)
       cur_loc = cur_loc | (1 << 6); 
    if(line & 0x02)
    {
      cur_loc = cur_loc | (1 << 2); 
      cur_loc = cur_loc | (1 << 4);     
    }    
    cur_loc = cur_loc + col;
    lcd_command(cur_loc);
   }
}
void Test_Goto_XY_LCD(unsigned int line,unsigned int col)
{
   if(line < 4 && col < 20 )
   {
     cur_loc = FIRST_LINE;
     if(line & 0x01)
       cur_loc = cur_loc | (1 << 6); 
    if(line & 0x02)
    {
      cur_loc = cur_loc | (1 << 2); 
      cur_loc = cur_loc | (1 << 4);     
    }    
    cur_loc = cur_loc + col;
    lcd_command(FIRST_LINE);
    data_2digit_hex(cur_loc);
   }
}
void LCD_Const_Disp()
{
  Goto_XY_LCD(1,0);
  data_str(red_disp);
  Goto_XY_LCD(1,16);
  data_str(secs_disp);
  Goto_XY_LCD(2,0);
  data_str(yellow_disp); 
  Goto_XY_LCD(2,16);
  data_str(secs_disp);
  Goto_XY_LCD(3,0);
  data_str(green_disp); 
  Goto_XY_LCD(3,16);
  data_str(secs_disp);      
}
void Traffic_Init(unsigned int traffic_fsm_init, unsigned int header_init_fsm)
{
   num_sec = 0;    
   traffic_fsm_state =traffic_fsm_init;  
   switch(traffic_fsm_state)
   {
    case STOP_FSM:
      red_off_secs = 0; 
      yellow_off_secs =0;
      green_off_secs = WAIT_TIME;
      Stop_Fsm_Proc();
      break;
    case GO_FSM:
      green_off_secs = 0;
      red_off_secs = 0; 
      yellow_off_secs = STOP_TIME;
      Go_Fsm_Proc();
      break;
    case WAIT_FSM:
      yellow_off_secs = 0;
      green_off_secs = 0;
      red_off_secs = GO_TIME;                                    
      Wait_Fsm_Proc();
      break;   
   }
   traffic_disp_sec =0;
   traffic_disp_fsm =header_init_fsm;
   switch(traffic_disp_fsm)
   {
     case DISP_TRAFFIC_FSM:
       Goto_XY_LCD(0,3);
       data_str(header_disp);
       break;
     case DISP_BLANK_FSM:
       Goto_XY_LCD(0,3); 
       data_str(blank_disp);  
       break; 
   }      
}
void Stop_Fsm_Proc()
{
   RED_PIN =LED_ON;
   YELLOW_PIN =LED_OFF;
   GREEN_PIN = LED_OFF;
   Goto_XY_LCD(1,8);
   data_str(led_on_disp);
   Goto_XY_LCD(1,12);
   data_2digit(STOP_TIME - num_sec);
   Goto_XY_LCD(2,8);
   data_str(led_off_disp);
   Goto_XY_LCD(2,12);
   data_2digit(STOP_TIME + GO_TIME - yellow_off_secs);
   Goto_XY_LCD(3,8);
   data_str(led_off_disp);
   Goto_XY_LCD(3,12);
   data_2digit(STOP_TIME + WAIT_TIME - green_off_secs);
}
void Wait_Fsm_Proc()
{
     RED_PIN =LED_OFF;
     YELLOW_PIN =LED_ON;
     GREEN_PIN = LED_OFF;
     Goto_XY_LCD(1,8);
   data_str(led_off_disp);
   Goto_XY_LCD(1,12);
   data_2digit(WAIT_TIME + GO_TIME - red_off_secs);
   Goto_XY_LCD(2,8);
   data_str(led_on_disp);
   Goto_XY_LCD(2,12);
   data_2digit(WAIT_TIME - num_sec);
   Goto_XY_LCD(3,8);
   data_str(led_off_disp);
   Goto_XY_LCD(3,12);
   data_2digit(STOP_TIME + WAIT_TIME - green_off_secs);     
}
void Go_Fsm_Proc()
{
     RED_PIN =LED_OFF;
     YELLOW_PIN =LED_OFF;
     GREEN_PIN = LED_ON;
     Goto_XY_LCD(1,8);
     data_str(led_off_disp);
     Goto_XY_LCD(1,12);
     data_2digit(WAIT_TIME + GO_TIME - red_off_secs);
     Goto_XY_LCD(2,8);
     data_str(led_off_disp);
     Goto_XY_LCD(2,12);
     data_2digit(STOP_TIME + GO_TIME - yellow_off_secs);
     Goto_XY_LCD(3,8);
     data_str(led_on_disp);
     Goto_XY_LCD(3,12);
     data_2digit(GO_TIME - num_sec);        
}

void Disp_Header_Fsm()
{
   switch(traffic_disp_fsm)
   {
     case DISP_TRAFFIC_FSM:
       traffic_disp_fsm =DISP_BLANK_FSM;
       Goto_XY_LCD(0,3);
       data_str(blank_disp);
       break;
     case DISP_BLANK_FSM:
       traffic_disp_fsm = DISP_TRAFFIC_FSM; 
       Goto_XY_LCD(0,3); 
       data_str(header_disp);  
       break; 
   }   
}
