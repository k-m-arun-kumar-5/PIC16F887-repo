/**************************************************************************
   FILE          :    appl_conf.h
 
   PURPOSE       :   main application configuration Header
 
   AUTHOR        :   K.M.Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _APPL_CONF_H
 #define _APPL_CONF_H 
 
/*------------------------------- LCD disp conf ------------------------------------------*/



/* -------------------------------Timer state conf ---------------------------------------*/

typedef enum {
	TMR1_STOP_STATE, TMR1_EXTR_INTP_LED_ON_STATE 
 } timer1_run_states;

/* ------------------------------- application conf --------------------------------------*/

#define REQ_TIME_NORMAL_LED_CHANGE_STATE_IN_MILLI_SEC   (5000UL)
#define REQ_TIME_EXTR_INTP_LED_ON_IN_MILLI_SEC          (8000UL)

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
