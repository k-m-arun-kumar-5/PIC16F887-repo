/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    :  use Timer1 Overflow Interrupt and use external interrupt and use EXTR_INTP_LED and NORMAL_LED. 
   use timer 1 delay time using Timer1 Overflow Interrupt logic for EXTR_INTP_LED and when EXTR_INTP_SW is pressed on, 
   flash EXTR_INTP_LED ON and pause  NORMAL_LED blinking, for a specific time duration and after that EXTR_INTP_LED is flashed off and NORMAL_LED resumes blinking.     
   When no external interrupt ie EXTR_INTP_SW is not pressed, NORMAL_LED blinks and EXTR_INTP_LED is flashed off.  
                      									 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : fix issue of timer to get precise time using timer. Use PIC16F887-repo->05_timer->timer17.X->timer.c as base code to get precise time using timer. 

NOTE                  :  Used for demonstration purpose only.
                         NOT POSSIBLE to pause NORMAL_LED blinking when external interrupt has occured and then use timer 1 delay time using Timer1 Overflow Interrupt.
                         because interrupt can occur at any time and after executed interrupt's ISR resume execute instruction, where uC paused  before execute ISR.
						 In this case use __delay_ms(), which consume instruction cycles, to solve this problem as solved in timer_15.                      								
                        
                       
CHANGE LOGS           : 

*****************************************************************************/
  

#include "main.h"
#include "port.h"
#include "lcd.h"
#include "timer.h"
#include "uart.h"
#include "io_conf.h"

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.
// 'C' source line config statements
#pragma config FOSC = XT    // Oscillator Selection bits (XT oscillator)
#pragma config WDTE = OFF   // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF  // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = OFF  // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = OFF    // Low-Voltage In-Circuit Serial Programming Enable bit
#pragma config CPD = OFF    // Data EEPROM Memory Code Protection bit
#pragma config WRT = OFF    // Flash Program Memory Write Enable bits
#pragma config CP = OFF     // Flash Program Memory Code Protection bit




/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void main()
{
		
   TRISA = 0x00;
   PORTA = 0x00;
   TRISE = 0x00;
   PORTE = 0x00;
   LCD_PORT_GPIO = 0x00;
   LCD_PORT = 0x00;
   
   ANSEL = 0x00;
   ANSELH = 0x00;  
   
   LCD_Init();
   UART_Init();
   INTF = 0;
   OPTION_REGbits.INTEDG = 1; // external Interrupt on rising edge of INT pin
   INTCONbits.INTE = 1; //Enables the INT pin external interrupt   
   INTCONbits.GIE = 1;  //Enables all unmasked interrupts  
   
   while(1)
   {
	    NORMAL_LED = LED_ON;
		#ifdef TRACE
	     UART_Transmit_Str("NORMAL LED is ON \r");
	   #endif
        __delay_ms(REQ_TIME_NORMAL_LED_CHANGE_STATE_IN_MILLI_SEC);
        NORMAL_LED = LED_OFF;
		#ifdef TRACE
	     UART_Transmit_Str("NORMAL LED is OFF \r");
	   #endif
        __delay_ms(REQ_TIME_NORMAL_LED_CHANGE_STATE_IN_MILLI_SEC);   		
   }   
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
