/**************************************************************************
   FILE          :    isr.c
 
   PURPOSE       :   Interrupt Service Routine Library
 
   AUTHOR        :   K.M.Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #include "main.h"
 #include "port.h"
 #include "timer.h"
 #include "uart.h" 
 #include "io_conf.h"
 #include "intp_event_handle.h" 
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void interrupt Interrupt_ISR() 
{
	//for demo, used for communication between ISR and retain data if exited from ie ISR as exit of a particular interrupt ISR may lead to exit of Interrupt_ISR() 
	static unsigned int check_static = 50; 
	// for demo, used in particular ISR for one instance only
	unsigned int check_local = 20;         
	
	ISR_LED  = LED_ON;
	if( INTCONbits.INTE == 1 && INTF == 1)           // external interrupt ISR - higher priority
	{	
	     /*if INTF is not cleared in software, and when EXTR_INTP_SW is pressed on and after execution of External Interrupt ISR,   
		 and even when EXTR_INTP_SW is released, External Interrupt ISR keeps on been executed, until INTF, which was set, 
		 when EXTR_INTP_SW was pressed on, is cleared in software */		 
		 INTF = 0;
	     INTCONbits.INTE = 0; //disable the INT pin external interrupt		
               		
	    #ifdef TRACE
	       UART_Transmit_Str("External Interrupt is occurred \r");
		   UART_Transmit_Str("INTE is disabled \r");
		   
           //SHOULD_REMOVE
		   UART_Transmit_Str("0: for demo purpose -  check_static : ");
           UART_Transmit_Num(DISP_FLAG_NUM_DIGIT3, check_static);
		   UART_Transmit_Str(" , check_local : ");
		   UART_Transmit_Num(DISP_FLAG_NUM_DIGIT3, check_local);
           UART_Transmit_Char('\r');
		   check_local = 40;
		   check_static = 100;
		   UART_Transmit_Str("1: for demo purpose -  check_static : ");
           UART_Transmit_Num(DISP_FLAG_NUM_DIGIT3, check_static);
		   UART_Transmit_Str(" , check_local : ");
		   UART_Transmit_Num(DISP_FLAG_NUM_DIGIT3, check_local);
           UART_Transmit_Char('\r');
		   
	    #endif 		
		External_Interrupt_Occured_Appl_Proc();		
		
		/* in External_Interrupt_Occured_Appl_Proc(), it runs Timer1_Run, on timer1 overflow interrupts, executes Timer1 ISR
		 and resumes in External Interrupt ISR, causing stack underflow and INT pin in logic contention, causing errors and inproper operation  */
		 
		/* //SHOULD_REMOVE
		   check_local = 60;
		   check_static = 150;
		   
		#ifdef TRACE  
           //SHOULD_REMOVE		
		   UART_Transmit_Str("2: for demo purpose -  check_static : ");
           UART_Transmit_Num(DISP_FLAG_NUM_DIGIT3, check_static);
		   UART_Transmit_Str(" , check_local : ");
		   UART_Transmit_Num(DISP_FLAG_NUM_DIGIT3, check_local);
           UART_Transmit_Char('\r');	
		   
	       UART_Transmit_Str("External Interrupt is executed \r");	    
	    #endif */		
	}
	if(TMR1IF == 1)     // timer1 overflow interrupt ISR - lower prority
	{
		  TMR1IF = 0;
		  TMR1H = timer1_init_val / 256UL;
          TMR1L = timer1_init_val % 256UL; 
		  //timer1 overflow for every TIMER1_TICK_IN_MILLI_SEC ie timer1_elapsed_num_overflow_1_update var is incremented for every TIMER1_TICK_IN_MILLI_SEC elapsed
          if(++timer1_elapsed_num_overflow_1_update >= timer1_1_update) 
          {
			  if(++timer1_elapsed_num_update >= timer1_req_time_max_update)
			  {
				  Timer1_Stop();
				  #ifdef TRACE
	                 UART_Transmit_Str("Timer1 is expired \r");
					 
                  //SHOULD_REMOVE
                      UART_Transmit_Str("3: for demo purpose - check_static : ");
                      UART_Transmit_Num(DISP_FLAG_NUM_DIGIT3, check_static);
		              UART_Transmit_Str(" , check_local : ");
		              UART_Transmit_Num(DISP_FLAG_NUM_DIGIT3, check_local);
                      UART_Transmit_Char('\r');
   					  check_static = 50; 
					  
	              #endif 
				  timer1_elapsed_num_update = 0;
                  timer1_elapsed_num_overflow_1_update = 0; 				  
                  Timer1_Req_Time_Expiry_Appl_Proc();  
			  }
              timer1_elapsed_num_overflow_1_update = 0;  			  
          }          		  
	 } 
	 ISR_LED  = LED_OFF;
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
