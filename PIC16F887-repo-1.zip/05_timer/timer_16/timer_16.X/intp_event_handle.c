/**************************************************************************
   FILE          :    intp_event_Handle.c
 
   PURPOSE       :  interrupt Event Handler Library
 
   AUTHOR        :  K.M.Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #include "main.h"
 #include "port.h"
 #include "lcd.h"
 #include "uart.h"
 #include "timer.h"
 #include "io_conf.h"
  
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void External_Interrupt_Occured_Appl_Proc()
{	
    EXTR_INTP_LED = LED_ON;	
	#ifdef TRACE
       UART_Transmit_Str("EXTR INTP LED is ON \r");	
	#endif
	Timer1_Run(TMR1_EXTR_INTP_LED_ON_STATE, REQ_TIME_EXTR_INTP_LED_ON_IN_MILLI_SEC, TMR1_INTP_SERVICE, TMR1_GATE_CTRL_DISABLE, TMR1_INPUT_CLK_PRESCALE_8, TMR1_LP_OSC_DISABLE, TMR1_CLK_SRC_INTR_OSC);   
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void Timer1_Req_Time_Expiry_Appl_Proc()
{	
    switch(timer1_last_run_state_before_stop)
	{
		case TMR1_EXTR_INTP_LED_ON_STATE:
		   EXTR_INTP_LED = LED_OFF;
		   
		   #ifdef TRACE
		     UART_Transmit_Str("EXTR INTP LED is OFF \r");	
	         UART_Transmit_Str("INTE is enabled \r");
	       #endif 
		    /* User software should ensure the appropriate interrupt flag bits are clear
              prior to enabling an interrupt. 
			  In this case, (external interrupt flag)INTF = 0, just before (external interrupt enable)INTE = 1.  */
		   INTF = 0;
		   OPTION_REGbits.INTEDG = 1; // external Interrupt on rising edge of INT pin
		   INTCONbits.INTE = 1; //enable the INT pin external interrupt 
		break;
		default:
		  ;		
	}	
}


/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
