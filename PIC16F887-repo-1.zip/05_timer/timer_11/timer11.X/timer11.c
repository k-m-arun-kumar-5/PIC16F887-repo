/* ********************************************************************
FILE                   : timer11.c

PROGRAM DESCRIPTION    :  initially, using INC_SW to increment time, DEC_SW to decrement time, 
  and ENTER_SW to enter the configured time in seconds and start Timer. Use RESET_SW to reset. 
  Corresponding Time configure should be displayed in LCD. LED ON and LED OFF time are equal duration.
  Once configured time, INC_SW, DEC_SW and ENTER_SW should not affect LED flashing.
  RESET_SW should stop timer and allow to configure the time duration in seconds.
  Start the LED flashing and and using timer0, periodically flash LED1 OFF 
 and LED2 ON for configured time in sec and LED1 ON and LED2 OFF for configured time in seconds 
 and display LED status in LCD with remaining time left in Led status. 

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : fix issue of timer to get precise time using timer. Use PIC16F887-repo->05_timer->timer17.X->timer.c as base code to get precise time using timer.

NOTE                  : modified from PIC16F887-repo->05_timer->timer4.c
                       
CHANGE LOGS           : 

*****************************************************************************/  
 
#define HI_TECH_COMPILER
#ifdef HI_TECH_COMPILER
  #include <pic.h>
  __CONFIG(0X2CE4);
#else // XC8 compiler
  #include <xc.h>
#endif
#include <string.h>
#define LED1_PIN               					RA0
#define LED2_PIN 								RA1
#define NO_KEY_PRESS_LED_PIN                    RA6
#define LONG_PRESS_KEY_LED_PIN                  RA7
#define INTERNAL_ERROR_LED_PIN                  RD7

#define INC_SW                                  RD3
#define DEC_SW                                  RD4
#define ENTER_SW                                RD5
#define RESET_SW                                RD6


#define RS_PIN                                	RD0
#define RW_PIN                                 	RD1
#define EN_PIN                                	RD2
#define LCD_PORT                               PORTC

#define KEY_PRESSED                              (1) 
#define KEY_NOT_PRESSED                          (0)
 
#define DISP_FLAG_NUM_DIGIT1                   (1u)
#define DISP_FLAG_NUM_DIGIT2                   (2u)
#define DISP_FLAG_NUM_DIGIT3                   (3u)
#define DISP_FLAG_NUM_DIGIT4                   (4u)
#define DISP_FLAG_NUM_DIGIT5                   (5u)
#define DISP_FLAG_HEX_DIGIT1                   (6u)
#define DISP_FLAG_HEX_DIGIT2                   (7u)
#define DISP_FLAG_HEX_DIGIT3                   (8u)
#define DISP_FLAG_HEX_DIGIT4                   (9u) 

 /* num cols = num of chars in a line */
#define MAX_COUNT_DELAY_TIME_LCDPULSE     (100U)
#define MAX_AVAIL_NUM_COLS                    (20u)
#define CONFIGURE_MAX_NUM_LINES               (4u)
#define MAX_AVAIL_NUM_LINES                   (4u) 
#define MAX_AVAIL_NUM_CHARS_IN_LCD        (MAX_AVAIL_NUM_COLS * MAX_AVAIL_NUM_LINES) 
#define CONFIGURE_MAX_NUM_COLS             (MAX_AVAIL_NUM_COLS)
#define CONFIGURE_MAX_NUM_CHARS_IN_LCD    (CONFIGURE_MAX_NUM_LINES * CONFIGURE_MAX_NUM_COLS ) 
#define MAX_NUM_CHARS_INPUT_DATA          (MAX_AVAIL_NUM_COLS)  

/* for 20 * 4 LCD disp */                             
#define BEGIN_LOC_LINE1                      (0X80u)
#define BEGIN_LOC_LINE2                      (0xC0u)
#define BEGIN_LOC_LINE3                      (0x94u) 
#define BEGIN_LOC_LINE4                      (0xD4u)
#define END_LOC_LINE1                        (0x93u)
#define END_LOC_LINE2                        (0xD3u)
#define END_LOC_LINE3                        (0xA7u) 
#define END_LOC_LINE4                        (0xE7u)

#define INVALID_DATA               (0u)
#define ALL_LINES                  (0u)
#define NUM_LINE1                  (1u)
#define NUM_LINE2                  (2u)
#define NUM_LINE3                  (3u)
#define NUM_LINE4                  (4u)
#define NUM_COL1                   (1u)

#define ENTER_SW_CODE                 ('E')
#define INC_SW_CODE                   ('I')
#define DEC_SW_CODE                   ('D')
#define RESET_SW_CODE                 ('R') 
#define NUM_CHARS_TRACE_CODE           (5)

#define TIMER1_TICK_MS  (50UL) // TIMER1 expires every 50ms
#define TIME_UNIT (1000UL)
#define OSC_PER_INST (4)
#define _XTAL_FREQ   (4000000UL)
#define INC1 (unsigned int)((unsigned long)(_XTAL_FREQ * TIMER1_TICK_MS) / (unsigned long)(OSC_PER_INST * TIME_UNIT))

#define LED_FSM_PERIOD                  (1000UL) 
#define LED_FSM_PERIOD_FACTOR_PER_SEC   (1000UL/LED_FSM_PERIOD)
//UPDATE_TIME1_NO_KEY_PRESS configured for 500 msec
#define UPDATE_TIME1_NO_KEY_PRESS          (NO_KEY_PRESS_PERIOD/TIMER1_TICK_MS)
#define UPDATE_TIME1_LED_FSM              (LED_FSM_PERIOD/TIMER1_TICK_MS) //UPDATE_TIME configured for 1 sec

#define NO_KEY_PRESS_PERIOD          (500UL) 
#define NO_KEY_PRESS_FACTOR_PER_SEC  (1000UL/NO_KEY_PRESS_PERIOD)
//UPDATE_TIME1_NO_KEY_PRESS configured for 500 msec
#define UPDATE_TIME1_NO_KEY_PRESS          (NO_KEY_PRESS_PERIOD/TIMER1_TICK_MS)

// every 500ms Long_Key_Press_Proc() is called if Timer1 runs
#define LONG_PRESS_KEY_PERIOD          (500UL)
#define LONG_PRESS_KEY_FACTOR_PER_SEC  (1000UL/LONG_PRESS_KEY_PERIOD)
//UPDATE_TIME1_LONG_PRESS_KEY configured for 500 msec
#define UPDATE_TIME1_LONG_PRESS_KEY  (LONG_PRESS_KEY_PERIOD/TIMER1_TICK_MS)

#define NO_ERROR_OCCURED               (0u)
#define WARNING_OCCURED                (1u)
#define ERROR_OCCURED                  (2u)
#define FATAL_OCCURED                  (3u)


/* codes for error or fatal errors , low 16 BIT */
#define NO_ERROR_CODE                              (0x0000UL)
#define ERR_SW_CODE                                (0x0001UL)
#define ERR_LCD_FSM_STATE_CODE                     (0x0002UL)
#define ERR_CUR_DISP_LOC_CODE                      (0x0004UL)
#define ERR_CUR_INPUT_LOC_CODE                     (0x0008UL)
#define ERR_TRY_TORUN_TMR1_ALREADY_RUNNING_CODE    (0x0010UL)
#define ERR_DISP_FSM_STATE_CODE                    (0x0020UL)
  
#define LED1_FSM_OFF    (1u)
#define LED1_FSM_ON     (2u)
#define LED_OFF         (0u)
#define LED_ON          (1u)

#define STATE_YES     'y'
#define STATE_NO      'n'

/* should status be displayed on or off for error, warning and current time left and its count of long key press, no key press, 
  time within auth process should succeed or failed,  time within PIN should be changed */
#define STATUS_DISP_ON                            (1U)  
#define STATUS_DISP_OFF                           (0U) 

#define TMR1_OFF_STATE             (0U)
#define TMR1_MODE_NO_KEY_PRESS     (1U)
#define TMR1_MODE_LONG_PRESS_KEY   (2U)
#define TMR1_MODE_LED_FSM          (3U) 

#define ANY_DATA_DISP                 (1U)
#define BLANK_LINE_DISP               (2U)
#define NO_KEY_PRESS_TIMEOUT_DISP     (3U)   
#define LONG_PRESS_TIMEOUT_DISP       (4U) 
#define LED_STATUS_DISP               (5U)    
#define ERROR_DISP                    (8U)
#define WARNING_DISP                  (9U)
#define FATAL_DISP                    (10U) 
  
//#define LED1_ON_TIME    2 // 2 sec on time
//#define LED1_OFF_TIME   2 // 2 sec off time                    
#define WRAP_SET_TIME                           (99u)


/* disp_status_time_or_error[] index ie disp_status_time_or_error[LONG_PRESS_TIME_STATUS_DISP_INDEX] = STATUS_DISP_ON, \
   then long press time status is displayed */
#define ERROR_STATUS_DISP_INDEX             (0U)
#define LONG_PRESS_TIME_STATUS_DISP_INDEX   (1U)
#define NO_KEY_PRESS_TIME_STATUS_DISP_INDEX (2U)

#define FAILED_SET_TIME_REASON_LINE_NUM   NUM_LINE1
#define LED_SEC_MSG_LINE_NUM             NUM_LINE1
#define LED_SEC_ENTRY_LINE_NUM           NUM_LINE2
#define LONG_PRESSKEY_TIMEOUT_LINE_NUM   NUM_LINE3
//#define NO_KEYPRESS_TIMEOUT_LINE_NUM     NUM_LINE3
#define NO_KEYPRESS_TIMEOUT_LINE_NUM     NUM_LINE4
#define ERROR_LINE_NUM                   NUM_LINE4 
#define ERROR_MIN_SEC_LINE_NUM           NUM_LINE2
#define LED1_STATUS_LINE_NUM             NUM_LINE2
#define LED2_STATUS_LINE_NUM             NUM_LINE3
#define LED_SEC_MSG_DISP_COL_NUM         (13U)  
#define LED_STATE_COL_NUM                 (6U)           
#define LED_TIME_LEFT_COL_NUM             (10U)                      

#define MAX_TIMEOUT_NO_KEY_PRESS               (10)  
#define MAX_TIMEOUT_LONG_PRESS_KEY              (5)  
#define MIN_SET_LED_TIME                        (2) 
#define MAX_COUNT_LONG_PRESSKEY_TIMEOUT        (3) 

enum status_fsm {INITIAL = 0, TIMEOUT_LONG_KEY_PRESS,TIMEOUT_NO_KEY_PRESS};
 
void Delay_Time_ByCount(unsigned int Delay_Time_Count_count);
void LCD_Pulse();
void Write_LCD_Command (const unsigned int lcd_command);
void Write_LCD_Data(const char lcd_disp_ch);
void Data_Str_Disp_LCD(const char *lcd_disp_str);
void Data_Num_Disp_LCD(const unsigned int lcd_datanum_disp_format, const unsigned long lcd_disp_data_int);
void LCD_Init();
void Goto_XY_LCD_Disp(unsigned int line,unsigned int col);
void Goto_XY_LCD_Disp_Err(const unsigned int start_line_num, const unsigned int start_col_num);
void Goto_XY_LCD_Input(unsigned int start_line_num,unsigned int start_col_num);
void Stoke_Rcvd_Tmr1_Long_Press_Proc();

void After_Switch_Stoke_Proc(const char pressed_key);
void Long_Press_Key_Proc();
void Check_Long_Pressed_Key();
void No_Key_Press_Proc();
void Check_No_Key_Press();
void Disp_Status_Fsm();
void Led_Init(unsigned int);
void LCD_Const_Disp();
void Init_Const_Data();
void Error_or_Warning_Proc(const char *error_trace, const unsigned int warn_or_error_format, const unsigned int warning_or_error_data);
void Prescale_Timer1();

enum status_fsm status_disp_fsm =INITIAL; 

unsigned int disp_status_time_or_error[] = {STATUS_DISP_ON, STATUS_DISP_ON, STATUS_DISP_ON};

/* currently displayed data in each line starts from 1 ie use array index as line num for us. index 0 can be used as all lines */
unsigned int cur_line_disp_data[] = {ANY_DATA_DISP, ANY_DATA_DISP, ANY_DATA_DISP, BLANK_LINE_DISP, BLANK_LINE_DISP};

unsigned int prescale_timer1 =  0x01, prescale_shift_timer1= 00,num_sec= 0;
unsigned long int num_calls_timer1 = 0, timer1_init = 0;
unsigned int count_update_long_press_per_sec = 0, count_update_no_key_per_sec = 0 ;
unsigned int led1_fsm_state = LED1_FSM_OFF;
const char led_on_msg_disp[] = " ON", led_off_msg_disp[] = "OFF";

unsigned int cur_disp_lcd_loc = BEGIN_LOC_LINE1, cur_input_lcd_loc = BEGIN_LOC_LINE2, set_ledtime=0;
char  cur_pressed_key_or_sw = '\0', need_input_flag = STATE_YES, reset_sw_enable_flag = STATE_NO, inc_sw_enable_flag = STATE_YES,\
 dec_sw_enable_flag = STATE_NO, enter_sw_enable_flag = STATE_NO, sw_input_enable_flag = STATE_YES, timeout_long_pressed_key_flag = STATE_NO, \
 timeout_nokey_press_flag = STATE_NO, disp_status_flag = STATE_NO, detect_presskey_flag = STATE_NO;

unsigned int timer1_mode = STATE_NO, no_press_key_flag = STATE_YES, long_pressed_key_flag= STATE_NO;
unsigned long int no_key_press_count = 0;
unsigned int time_left_no_key_press = MAX_TIMEOUT_NO_KEY_PRESS, time_left_long_press_key = MAX_TIMEOUT_LONG_PRESS_KEY;

const char time_set_msg_disp[]= {"INC/DEC Time"}, error_msg_disp[]={"ERROR:"}, min_time_msg_disp[]={"Min Time: "};
unsigned int count_long_press_key_timeout = 0;
unsigned long int error_or_warning_code = NO_ERROR_CODE; 
unsigned int lcd_avail_loc_within_limit = STATE_YES, internal_error_state = NO_ERROR_OCCURED;
	
const char secs_msg_disp[] = "Secs", timeout_long_press_msg_disp[] = {" TOUT:L Key "}, timeout_no_key_msg_disp[] = {"TOUT:NO Key "}, \
 line_blank_disp[] = {"                    "}, time_msg_disp[] = {"T"}, count_msg_disp[] = " C", error_line_msg_disp[] = " ERR ", \
 warning_msg_disp[] = " WRN ", fatal_msg_disp[] = " FTL "; 
 const char key_timeout_msg_disp[] =  "Timeout:" ,error_no_key_press_msg_disp[]="No Key",error_long_key_press_msg_disp[]="L Key";
unsigned int time_msg_disp_len , count_msg_disp_len, long_press_timeout_msg_disp_len,  start_col_long_press_timeout_msg_disp, start_col_long_press_time_disp, \
 start_col_long_press_count_msg_disp, start_col_long_press_count_disp, start_col_long_press_time_msg_disp, start_col_error_code, start_col_error_msg_disp, start_col_error_line_msg,
 start_col_no_key_time_msg_disp, start_col_no_key_time_disp, start_col_reason_timeout_msg_disp;
 
void Led1_on();
void Led1_off();     
void Fsm_Led_Proc();
void Fsm_Led();
void Disp_LED_Status();
void Reset_Process();
void Run_Timer1(const unsigned int );
void Stop_Timer1();
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 33   
-*------------------------------------------------------------*/
void main()
{
   TRISA = 0x00;
   PORTA = 0x00;
   TRISB = 0x00;
   PORTB = 0x00;
   TRISC = 0x00;
   PORTC = 0x00;
   TRISD = 0x78;
   PORTD = 0x00;
   TRISE = 0x00;
   PORTE = 0x00;
   
   ANSEL= 0X00;
   ANSELH=0X00;
   LCD_Init();
   Reset_Process();
   Init_Const_Data();
   Run_Timer1(TMR1_MODE_NO_KEY_PRESS);
   for(;;)
   {
     if(INC_SW == KEY_PRESSED)
     {
	   	 cur_pressed_key_or_sw = INC_SW_CODE;//latest pressed key/switch
	     if(sw_input_enable_flag == STATE_YES && inc_sw_enable_flag == STATE_YES)
		 {	 
	      	    Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
	            while(INC_SW == KEY_PRESSED )
                { 
                   Check_Long_Pressed_Key();
                   if(timeout_long_pressed_key_flag == STATE_YES)
                   {                                    
                         break;
                   }                  
		        }
		        After_Switch_Stoke_Proc(cur_pressed_key_or_sw); 	      		 
          }
	 }
	 if(DEC_SW == KEY_PRESSED)
     {
	   	 cur_pressed_key_or_sw = DEC_SW_CODE;//latest pressed key/switch
	     if(sw_input_enable_flag == STATE_YES && dec_sw_enable_flag == STATE_YES)
		 {	 
	      	    Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
	            while(DEC_SW == KEY_PRESSED )
                { 
                   Check_Long_Pressed_Key();
                   if(timeout_long_pressed_key_flag == STATE_YES)
                   {                                    
                         break;
                   }                  
		        }
		        After_Switch_Stoke_Proc(cur_pressed_key_or_sw); 	      		 
          }
	 }
     if(ENTER_SW == KEY_PRESSED)
     {
	   	 cur_pressed_key_or_sw = ENTER_SW_CODE;//latest pressed key/switch
	     if(sw_input_enable_flag == STATE_YES && enter_sw_enable_flag == STATE_YES)
		 {	 
	      	    Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
	            while(ENTER_SW == KEY_PRESSED )
                { 
                   Check_Long_Pressed_Key();
                   if(timeout_long_pressed_key_flag == STATE_YES)
                   {                                    
                         break;
                   }                  
		        }
		        After_Switch_Stoke_Proc(cur_pressed_key_or_sw); 	      		 
          }
	 }
     if(RESET_SW ==KEY_PRESSED )
     {
	     cur_pressed_key_or_sw = RESET_SW_CODE;//latest pressed key/switch
	     if(reset_sw_enable_flag == STATE_YES)
		 {	  
	          Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
              while(RESET_SW == KEY_PRESSED ) 
	          {  
                  Check_Long_Pressed_Key();
                  if(timeout_long_pressed_key_flag == STATE_YES)  
		          {                   	  		 
                        break;
                  } 		   
	          }
              After_Switch_Stoke_Proc(cur_pressed_key_or_sw);	
		 }							
     }
	 if(status_disp_fsm != INITIAL && cur_line_disp_data[ALL_LINES] == ANY_DATA_DISP )
     { 
	     Disp_Status_Fsm(); 
         cur_line_disp_data[ALL_LINES] = LED_STATUS_DISP;     
     }
     if(timer1_mode == TMR1_MODE_LED_FSM)
	 {
	    Fsm_Led_Proc();
	 }		 
     if(need_input_flag == STATE_YES && detect_presskey_flag != STATE_YES)
     { 
          Check_No_Key_Press();            
     }	     
  }
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 45  
-*------------------------------------------------------------*/
 void Stoke_Rcvd_Tmr1_Long_Press_Proc()   
 {
	 Stop_Timer1();
	 detect_presskey_flag = STATE_YES; // key press has been detected 	 
 }
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 7   
-*------------------------------------------------------------*/
void Check_No_Key_Press()
{
    if(timer1_mode == TMR1_OFF_STATE)
	{
        Run_Timer1(TMR1_MODE_NO_KEY_PRESS);		
    }
	if(timer1_mode == TMR1_MODE_NO_KEY_PRESS)
	{
		while(TMR1IF == 0);		                
		
		TMR1IF = 0;
		timer1_init = (65536) - (INC1/prescale_timer1); 
        TMR1H = timer1_init / 256;
        TMR1L = timer1_init % 256; 
		
        if(++num_calls_timer1 >= UPDATE_TIME1_NO_KEY_PRESS)
        {
		     No_Key_Press_Proc();                			 
             num_calls_timer1 = 0;        
       }	 
	}
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 45   
-*------------------------------------------------------------*/
void No_Key_Press_Proc()
{
    if(++count_update_no_key_per_sec % NO_KEY_PRESS_FACTOR_PER_SEC == 0 )
   { 
       count_update_no_key_per_sec = 0;
       --time_left_no_key_press;   	 
	   
       /* data is constant for a while, so if data is const,at lcd const data is displayed only once until const data at that line has changed */
	  if(disp_status_time_or_error[NO_KEY_PRESS_TIME_STATUS_DISP_INDEX] == STATUS_DISP_ON && \
	    cur_line_disp_data[NO_KEYPRESS_TIMEOUT_LINE_NUM] == BLANK_LINE_DISP)  
       {
		   Goto_XY_LCD_Disp(NO_KEYPRESS_TIMEOUT_LINE_NUM, NUM_COL1); 
		   Data_Str_Disp_LCD(timeout_no_key_msg_disp);
		   Goto_XY_LCD_Disp(NO_KEYPRESS_TIMEOUT_LINE_NUM, start_col_no_key_time_msg_disp );	
		   Data_Str_Disp_LCD(time_msg_disp);            
		   cur_line_disp_data[NO_KEYPRESS_TIMEOUT_LINE_NUM] = NO_KEY_PRESS_TIMEOUT_DISP;
		  /* to get data at cur_input_lcd_loc*/
           Write_LCD_Command(cur_input_lcd_loc);
	       Write_LCD_Command(0x0C);       		   
       }	   
	   
	   /* disp variable data every time at loc, if line has long press key data */
	  if( disp_status_time_or_error[NO_KEY_PRESS_TIME_STATUS_DISP_INDEX] == STATUS_DISP_ON && \
	     cur_line_disp_data[NO_KEYPRESS_TIMEOUT_LINE_NUM] == NO_KEY_PRESS_TIMEOUT_DISP)   
	   {
		   Goto_XY_LCD_Disp(NO_KEYPRESS_TIMEOUT_LINE_NUM, start_col_no_key_time_disp ); 
           Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, time_left_no_key_press);  
       }		   
       if(time_left_no_key_press == 0)
       {
		   timeout_nokey_press_flag = STATE_YES;
		   Stop_Timer1();
		   NO_KEY_PRESS_LED_PIN = LED_ON; 
	       cur_line_disp_data[ALL_LINES] = ANY_DATA_DISP;			    
	       status_disp_fsm =  TIMEOUT_NO_KEY_PRESS; 
	       disp_status_flag = STATE_YES;		    		  
           
               	  
      }	
   }  
}	
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 2   
-*------------------------------------------------------------*/
void Check_Long_Pressed_Key()
{
	unsigned long int count = 0; 
	
    //  Timer1_Tick(); // commited due to stack overflow, Timer1_Tick() contents are inserted as below
	 if(timer1_mode == TMR1_OFF_STATE)
	    Run_Timer1(TMR1_MODE_LONG_PRESS_KEY);	
    if(timer1_mode == TMR1_MODE_LONG_PRESS_KEY)
	 {
		 while(TMR1IF == 0);		                
		
		TMR1IF = 0;
		timer1_init = (65536) - (INC1/prescale_timer1); 
        TMR1H = timer1_init / 256;
        TMR1L = timer1_init % 256; 
		
        if(++num_calls_timer1 >= UPDATE_TIME1_LONG_PRESS_KEY)
        {
		     Long_Press_Key_Proc();                			 
             num_calls_timer1 = 0;        
        }	 
	}	   
} 

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 6  
-*------------------------------------------------------------*/
void Long_Press_Key_Proc()
{
   if(++count_update_long_press_per_sec % LONG_PRESS_KEY_FACTOR_PER_SEC == 0 )
   { 
       count_update_long_press_per_sec = 0;
       --time_left_long_press_key;   	 
	   
       /* data is constant for a while, so if data is const,at lcd const data is displayed only once until const data at that line has changed */
	  if(disp_status_time_or_error[LONG_PRESS_TIME_STATUS_DISP_INDEX] == STATUS_DISP_ON && \
	    cur_line_disp_data[LONG_PRESSKEY_TIMEOUT_LINE_NUM] == BLANK_LINE_DISP)  
       {
		   Goto_XY_LCD_Disp(LONG_PRESSKEY_TIMEOUT_LINE_NUM, NUM_COL1);
		   Write_LCD_Data(cur_pressed_key_or_sw);		     	 
		   Goto_XY_LCD_Disp(LONG_PRESSKEY_TIMEOUT_LINE_NUM, start_col_long_press_timeout_msg_disp); 
		   Data_Str_Disp_LCD(timeout_long_press_msg_disp);
		   Goto_XY_LCD_Disp(LONG_PRESSKEY_TIMEOUT_LINE_NUM, start_col_long_press_time_msg_disp );	
		   Data_Str_Disp_LCD(time_msg_disp); 
           Goto_XY_LCD_Disp(LONG_PRESSKEY_TIMEOUT_LINE_NUM, start_col_long_press_count_msg_disp);
		   Data_Str_Disp_LCD(count_msg_disp); 
		   cur_line_disp_data[LONG_PRESSKEY_TIMEOUT_LINE_NUM] = LONG_PRESS_TIMEOUT_DISP;
		  /* to get data at cur_input_lcd_loc*/
           Write_LCD_Command(cur_input_lcd_loc);
	       Write_LCD_Command(0x0C);       		   
      }
	   /* disp variable data every time at loc, if line has long press key data */
	  if( disp_status_time_or_error[LONG_PRESS_TIME_STATUS_DISP_INDEX] == STATUS_DISP_ON && \
	     cur_line_disp_data[LONG_PRESSKEY_TIMEOUT_LINE_NUM] == LONG_PRESS_TIMEOUT_DISP)   
	   {
		   Goto_XY_LCD_Disp(LONG_PRESSKEY_TIMEOUT_LINE_NUM, start_col_long_press_time_disp ); 
           Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, time_left_long_press_key);           
           Goto_XY_LCD_Disp(LONG_PRESSKEY_TIMEOUT_LINE_NUM, start_col_long_press_count_disp ); 
           Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, count_long_press_key_timeout);          
       }
       if(disp_status_time_or_error[NO_KEY_PRESS_TIME_STATUS_DISP_INDEX] == STATUS_DISP_ON && \
	     cur_line_disp_data[NO_KEYPRESS_TIMEOUT_LINE_NUM] == NO_KEY_PRESS_TIMEOUT_DISP)
	   {
		  Goto_XY_LCD_Disp(NO_KEYPRESS_TIMEOUT_LINE_NUM, NUM_COL1);	  
		  Data_Str_Disp_LCD(line_blank_disp);
          cur_line_disp_data[NO_KEYPRESS_TIMEOUT_LINE_NUM] = BLANK_LINE_DISP;	 
       }	   
       if(time_left_long_press_key == 0)
       {
		   timeout_long_pressed_key_flag = STATE_YES;		  
		   if(++count_long_press_key_timeout < MAX_COUNT_LONG_PRESSKEY_TIMEOUT)
		   {
			   time_left_long_press_key = MAX_TIMEOUT_LONG_PRESS_KEY;
               if(disp_status_time_or_error[LONG_PRESS_TIME_STATUS_DISP_INDEX] == STATUS_DISP_ON && \
			    cur_line_disp_data[LONG_PRESSKEY_TIMEOUT_LINE_NUM] == LONG_PRESS_TIMEOUT_DISP)		   
	           {
				   Goto_XY_LCD_Disp(LONG_PRESSKEY_TIMEOUT_LINE_NUM, start_col_long_press_time_disp ); 
                   Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, time_left_long_press_key); 
		           Goto_XY_LCD_Disp(LONG_PRESSKEY_TIMEOUT_LINE_NUM, start_col_long_press_count_disp ); 
                   Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, count_long_press_key_timeout);  
               }		   
		   }
		   else
		   {	   
	             LONG_PRESS_KEY_LED_PIN = LED_ON; 
			  	 cur_line_disp_data[ALL_LINES] = ANY_DATA_DISP;	
				 Stop_Timer1();
			     if(cur_pressed_key_or_sw != RESET_SW_CODE)
			     {	 
			      status_disp_fsm =  TIMEOUT_LONG_KEY_PRESS; 
	              disp_status_flag = STATE_YES;	  
                 
                }
                else
                {
				  /* process for reset sw operation after long key press error with last pressed is  reset sw  */
				  Reset_Process();
			   } 				  
		   }			  
      }	
   }  
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 16  
-*------------------------------------------------------------*/
void Stop_Timer1()
{
	if(timer1_mode != TMR1_OFF_STATE)
	{	
	   timer1_mode = TMR1_OFF_STATE;
	   T1CON = 0x80;
	}   
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 33   
-*------------------------------------------------------------*/
void Run_Timer1(const unsigned int set_timer1_mode )
{
  Stop_Timer1();  
  if(timer1_mode == TMR1_OFF_STATE)
  {
	/*internal timer1 clock  with 1:1 prescale,Timer1 counts when gate(T1G) is high 
     Timer1 counting is controlled by the Timer1 Gate function and no gate input is feed
     and enable timer1*/
	 
	  TMR1H = 0;
      TMR1L = 0;
	  TMR1IF = 0;
	  timer1_mode = set_timer1_mode;
	  /* for T1G gate based  timer 1 running control, Timer1 runs when T1G is high. If T1G is low, timer1 pauses counting */
	 // T1CON =0xC5; 

	 /*internal timer1 clock  with 1:1 prescale, gate(T1G) control for Timer1 is disabled  and enable timer1 and timer 1 runs Timer1 runs */
      T1CON =0x85;   
      prescale_timer1 = 0x01;
      prescale_shift_timer1= 0;
      Prescale_Timer1();
      timer1_init = (65536UL) - (INC1/prescale_timer1); 
      TMR1H = timer1_init / 256UL;
      TMR1L = timer1_init % 256UL; 
      num_calls_timer1 = 0;  
  }
  else
  {
	  /* dont run the timer1 if timer1 is already running  */
	  /* error: try to run timer1, which is not in off state */
	  Error_or_Warning_Proc("15.01", FATAL_OCCURED, ERR_TRY_TORUN_TMR1_ALREADY_RUNNING_CODE);
  }	  
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 33   
-*------------------------------------------------------------*/
void Fsm_Led_Proc()
{
	unsigned long int count = 0;
	 
		 while(TMR1IF == 0);	
		 
		TMR1IF = 0;
		timer1_init = (65536) - (INC1/prescale_timer1); 
        TMR1H = timer1_init / 256U;
        TMR1L = timer1_init % 256U; 
		
        if(++num_calls_timer1 >= UPDATE_TIME1_LED_FSM)
        {
		     Fsm_Led(); 
             			 
             num_calls_timer1 = 0;        
        }	 
		   
}            
 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 33   
-*------------------------------------------------------------*/
/* Every 1 second Fsm_Led() is called*/                                                                                                                                                                                                                                                                                                                      
void Fsm_Led()
{
    switch(led1_fsm_state)
    {
      case LED1_FSM_OFF:
      ++num_sec;                       
      Led1_off();
      if(num_sec >= set_ledtime )  //set_ledtime = LED1 off TIME
      {
        num_sec = 0;
        led1_fsm_state =LED1_FSM_ON;
        Led1_on();               
      }
      break;
      case LED1_FSM_ON:
       ++num_sec;                  
      Led1_on();
      if(num_sec >= set_ledtime ) //set_ledtime = LED1 ON TIME
      {
        num_sec = 0;
        led1_fsm_state =LED1_FSM_OFF; 
        Led1_off();                 
      }
      break; 
    }               
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 5   
-*------------------------------------------------------------*/  
void After_Switch_Stoke_Proc(const char pressed_sw)
{
	Stop_Timer1();
	time_left_no_key_press =MAX_TIMEOUT_NO_KEY_PRESS;
	detect_presskey_flag = STATE_NO;	
	if(timeout_long_pressed_key_flag == STATE_NO)
    {
		time_left_long_press_key = MAX_TIMEOUT_LONG_PRESS_KEY;
        if(disp_status_time_or_error[LONG_PRESS_TIME_STATUS_DISP_INDEX] == STATUS_DISP_ON && \
		 cur_line_disp_data[LONG_PRESSKEY_TIMEOUT_LINE_NUM] == LONG_PRESS_TIMEOUT_DISP)
	     {	   
              Goto_XY_LCD_Disp(LONG_PRESSKEY_TIMEOUT_LINE_NUM,NUM_COL1);
			  Data_Str_Disp_LCD(line_blank_disp);
	          cur_line_disp_data[LONG_PRESSKEY_TIMEOUT_LINE_NUM] = BLANK_LINE_DISP;		          
	      }
		if(disp_status_time_or_error[NO_KEY_PRESS_TIME_STATUS_DISP_INDEX] == STATUS_DISP_ON && \
	     cur_line_disp_data[NO_KEYPRESS_TIMEOUT_LINE_NUM] == NO_KEY_PRESS_TIMEOUT_DISP)
	   {
		  Goto_XY_LCD_Disp(NO_KEYPRESS_TIMEOUT_LINE_NUM, NUM_COL1);	  
		  Data_Str_Disp_LCD(line_blank_disp);
          cur_line_disp_data[NO_KEYPRESS_TIMEOUT_LINE_NUM] = BLANK_LINE_DISP;	 
       }    
	       switch(pressed_sw)
		  {
			  case DEC_SW_CODE:
			     if(set_ledtime == 0)
                   set_ledtime = WRAP_SET_TIME;
                 else                   
                    --set_ledtime;
                 Goto_XY_LCD_Input(LED_SEC_ENTRY_LINE_NUM, NUM_COL1);  
                 Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2,set_ledtime);                   
              break; 
              case INC_SW_CODE:
			     if(set_ledtime >= WRAP_SET_TIME )
                    set_ledtime = 0;        
 	             else       		 
                   ++set_ledtime;
                 Goto_XY_LCD_Input(LED_SEC_ENTRY_LINE_NUM, NUM_COL1);  
                 Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2,set_ledtime);
                 break;				 
			  case ENTER_SW_CODE:
			    Write_LCD_Command(0x01);  //clear screen
			    if(set_ledtime >= MIN_SET_LED_TIME)
                {
                  Write_LCD_Command(0x0C);  //display on, cursor off and blinking off 
                  LCD_Const_Disp();
                  Led_Init(LED1_FSM_OFF);
				  Stop_Timer1();
				  Run_Timer1(TMR1_MODE_LED_FSM);
                }
                else
                {
                  Data_Str_Disp_LCD(error_msg_disp);
                  Goto_XY_LCD_Disp(ERROR_MIN_SEC_LINE_NUM,NUM_COL1); 
                  Data_Str_Disp_LCD(min_time_msg_disp);
                  Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, MIN_SET_LED_TIME);
                }  
                inc_sw_enable_flag = STATE_NO;
				dec_sw_enable_flag = STATE_NO;
				enter_sw_enable_flag = STATE_NO;
				reset_sw_enable_flag = STATE_YES;				
              break;
            case RESET_SW_CODE:
			  /* process for reset sw operations when within long press timeout error occurs, reset sw is released */
               Reset_Process();
			   reset_sw_enable_flag = STATE_NO;
               break;
             default:			 
               Error_or_Warning_Proc("05.01", ERROR_OCCURED, ERR_SW_CODE);			 
               /* error: invalid sw code received */			 			   
	     }		 
	}
	if(count_long_press_key_timeout < MAX_COUNT_LONG_PRESSKEY_TIMEOUT)
       timeout_long_pressed_key_flag = STATE_NO;
    else 
      timeout_long_pressed_key_flag = STATE_YES;	
}	
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 33   
-*------------------------------------------------------------*/
/* process to to do when a error or warning has occured */
void Error_or_Warning_Proc(const char *error_trace, const unsigned int warn_or_error_format, const unsigned int warning_or_error_data)
{
	 error_or_warning_code |= warning_or_error_data; 
     INTERNAL_ERROR_LED_PIN = LED_ON;	
	 
	 if(disp_status_time_or_error[ERROR_STATUS_DISP_INDEX] == STATUS_DISP_ON )
	 {
        Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, NUM_COL1);
		Data_Str_Disp_LCD(error_trace);		
		Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, start_col_error_code);
		Data_Num_Disp_LCD(DISP_FLAG_HEX_DIGIT4, error_or_warning_code);		
	 }
	switch(warn_or_error_format)
	{
		case WARNING_OCCURED:	
         if(disp_status_time_or_error[ERROR_STATUS_DISP_INDEX] == STATUS_DISP_ON )
	     { 
		    Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, start_col_error_line_msg);			   
	        Data_Str_Disp_LCD(warning_msg_disp);
			cur_line_disp_data[ERROR_LINE_NUM] = WARNING_DISP;	
            internal_error_state = WARNING_OCCURED;			
		 }	
		 /*warning occured, process to do  */
        break;
		case ERROR_OCCURED:
		  if(disp_status_time_or_error[ERROR_STATUS_DISP_INDEX] == STATUS_DISP_ON )
	      { 
		    Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, start_col_error_line_msg);		   
	        Data_Str_Disp_LCD(error_line_msg_disp);
			cur_line_disp_data[ERROR_LINE_NUM] = ERROR_DISP;
			internal_error_state = ERROR_OCCURED;	
		  }	
		  /*error occured, process to do  */
		break;
        case FATAL_OCCURED:	            
		if(disp_status_time_or_error[ERROR_STATUS_DISP_INDEX] == STATUS_DISP_ON )
	     { 
		    Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, start_col_error_line_msg);			   
	        Data_Str_Disp_LCD(fatal_msg_disp);
			internal_error_state = FATAL_OCCURED;	
			cur_line_disp_data[ERROR_LINE_NUM] = FATAL_DISP;
		 }	  
		 /* fatal error occured, process to do  */ 
		break;
        default:
         ;
         /* warning invalid error or warning format*/			    
	}
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 26  
-*------------------------------------------------------------*/
void Data_Num_Disp_LCD(const unsigned int lcd_datanum_disp_format, const unsigned long lcd_disp_data_int)
{
    unsigned int tens_thousand_digit,thousands_digit, hundreds_digit,tens_digit, unit_digit;
    unsigned long num = lcd_disp_data_int;
    char num_data[] ={'0','1','2','3','4','5','6','7','8','9'};  
	char hex_data[] ={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'}; 
    switch(lcd_datanum_disp_format)
	{
	  case DISP_FLAG_NUM_DIGIT5: 
		  num =  lcd_disp_data_int % 100000;
		  tens_thousand_digit = (unsigned int)(num / (unsigned long)(10000));
          Write_LCD_Data(num_data[tens_thousand_digit]);
	  case DISP_FLAG_NUM_DIGIT4:
	      num = lcd_disp_data_int % 10000;
	      thousands_digit = (unsigned int)(num / (unsigned long)(1000));
	      Write_LCD_Data(num_data[thousands_digit]); 
	  case DISP_FLAG_NUM_DIGIT3: 
		  num = lcd_disp_data_int % 1000;
	      hundreds_digit = (unsigned int) (num / (unsigned long) (100));
	      Write_LCD_Data(num_data[hundreds_digit]);
	  case DISP_FLAG_NUM_DIGIT2:
          num = lcd_disp_data_int % 100;
          tens_digit = (unsigned int) (num / 10);
          Write_LCD_Data(num_data[tens_digit]); 		  
	  case DISP_FLAG_NUM_DIGIT1:
	     unit_digit = (unsigned int) (lcd_disp_data_int % 10);
         Write_LCD_Data(num_data[unit_digit]); 
	  break;
	  case DISP_FLAG_HEX_DIGIT4:
	      /*  ( 16 * 16 * 16 *16 )  = 0 as divide by zero warning */
	      //num = lcd_disp_data_int % ( 16 * 16 * 16 *16 );
          thousands_digit = (num / (16 * 16 * 16));
	      Write_LCD_Data(hex_data[thousands_digit]);
	  case DISP_FLAG_HEX_DIGIT3:
	      num = lcd_disp_data_int %(unsigned long)(16 * 16 * 16);
	      hundreds_digit = (unsigned int) (num / (unsigned long) (16 * 16));
	      Write_LCD_Data(hex_data[hundreds_digit]);
	  case DISP_FLAG_HEX_DIGIT2:
	      num = lcd_disp_data_int %(unsigned long)(16 * 16);
          tens_digit = (unsigned int) (num / 16);
          Write_LCD_Data(hex_data[tens_digit]);
	  case DISP_FLAG_HEX_DIGIT1: 
	      unit_digit = (unsigned int) (lcd_disp_data_int % 16);
          Write_LCD_Data(hex_data[unit_digit]);    
	  break;
	  default:
	    // Error_or_Warning_Proc("26.01", WARNING_OCCURED, ERR_LCD_DISP_NUM_FORMAT_CODE);
		     /* Warning invalid lcd_disp flag */
	    ;
	}   	
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 17  
-*------------------------------------------------------------*/
void Prescale_Timer1()
{
   if(T1CKPS0 == 1)
   {
      prescale_shift_timer1 |= 0x01;           
   }
   if(T1CKPS1 == 1)
   {
     prescale_shift_timer1 |= 0x02;
   }  
   prescale_timer1 = prescale_timer1  << prescale_shift_timer1;                                                      
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 33   
-*------------------------------------------------------------*/
void LCD_Init()
{
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x38);
    Write_LCD_Command(0x01);
    Write_LCD_Command(0x0E); //insert cursor on at cur_input_lcd_loc
	//Write_LCD_Command(0x0C);
    Write_LCD_Command(0x06);                                       
}      

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 33   
-*------------------------------------------------------------*/
void LCD_Const_Disp()
{
  Goto_XY_LCD_Disp(LED1_STATUS_LINE_NUM, NUM_COL1);
  Data_Str_Disp_LCD("LED1 ");
  Goto_XY_LCD_Disp(LED1_STATUS_LINE_NUM,LED_SEC_MSG_DISP_COL_NUM);
  Data_Str_Disp_LCD(secs_msg_disp);
  Goto_XY_LCD_Disp(LED2_STATUS_LINE_NUM, NUM_COL1);
  Data_Str_Disp_LCD("LED2 "); 
  Goto_XY_LCD_Disp(LED2_STATUS_LINE_NUM, LED_SEC_MSG_DISP_COL_NUM);
  Data_Str_Disp_LCD(secs_msg_disp);        
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 33   
-*------------------------------------------------------------*/
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num)
{
	/* max 4 lines and 20 columns */
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1, error_disp_start_loc; 
	lcd_avail_loc_within_limit = STATE_YES;
	
   if(start_line_num <= CONFIGURE_MAX_NUM_LINES && start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
      switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE4;
		   break;		 
	 }	
      cur_disp_lcd_loc = cur_disp_lcd_loc + start_col_lcd;
      Write_LCD_Command(cur_disp_lcd_loc);       
   }
   else
   {
	   /* error due to invalid lcd DISP loc  */
	     lcd_avail_loc_within_limit = STATE_NO;		
		 Error_or_Warning_Proc("29.01", FATAL_OCCURED, ERR_CUR_DISP_LOC_CODE);        		
   }	   
} 
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 43   
-*------------------------------------------------------------*/
void Goto_XY_LCD_Disp_Err(const unsigned int start_line_num, const unsigned int start_col_num)
{
	/* max 4 lines and 20 columns */
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1, error_disp_start_loc; 
	lcd_avail_loc_within_limit = STATE_YES;
	
   if(start_line_num <= MAX_AVAIL_NUM_LINES && start_col_num <= MAX_AVAIL_NUM_COLS )
   {
      switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE4;
		   break;		 
	 }	
      cur_disp_lcd_loc = cur_disp_lcd_loc + start_col_lcd;
      Write_LCD_Command(cur_disp_lcd_loc);       
   }
   else
   {
	   /* ERROR: loc exceeds max avail loc in lcd*/
   }
}  
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 30   
-*------------------------------------------------------------*/ 
void Goto_XY_LCD_Input(unsigned int start_line_num,unsigned int start_col_num)
{
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1; 
	
	/* max 4 lines and 20 columns */
	lcd_avail_loc_within_limit = STATE_YES;
	if( start_line_num <= CONFIGURE_MAX_NUM_LINES &&  start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
     switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_input_lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   cur_input_lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   cur_input_lcd_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   cur_input_lcd_loc = BEGIN_LOC_LINE4;
		   break; 		  
	 }
	 cur_input_lcd_loc = cur_input_lcd_loc + start_col_lcd;
    Write_LCD_Command(cur_input_lcd_loc); 	 	   
  }
  else
  {
	   /* error due to invalid Lcd loc  */	
	   lcd_avail_loc_within_limit = STATE_NO;
	   Error_or_Warning_Proc("30.01", FATAL_OCCURED, ERR_CUR_INPUT_LOC_CODE);
	  
  }	  
} 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 33   
-*------------------------------------------------------------*/
void Led_Init(unsigned int led_init_state)
{
   num_sec = 0;  
   led1_fsm_state = led_init_state; 
   switch(led_init_state)
   {
    case LED1_FSM_OFF:
      Led1_off();
      break;
     case LED1_FSM_ON:
      Led1_on();
      break;
   }  
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 33   
-*------------------------------------------------------------*/
void Led1_off()
{
   LED1_PIN =LED_OFF;
   LED2_PIN =LED_ON;
   Goto_XY_LCD_Disp(LED1_STATUS_LINE_NUM, LED_STATE_COL_NUM);
   Data_Str_Disp_LCD(led_off_msg_disp);
   Goto_XY_LCD_Disp(LED1_STATUS_LINE_NUM, LED_TIME_LEFT_COL_NUM);
   Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, set_ledtime - num_sec);
   Goto_XY_LCD_Disp(LED2_STATUS_LINE_NUM, LED_TIME_LEFT_COL_NUM);
   Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, set_ledtime - num_sec);
   Goto_XY_LCD_Disp(LED2_STATUS_LINE_NUM, LED_STATE_COL_NUM);
   Data_Str_Disp_LCD(led_on_msg_disp);
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 33   
-*------------------------------------------------------------*/
void Led1_on()
{
     LED1_PIN = LED_ON;
      LED2_PIN = LED_OFF;
      Goto_XY_LCD_Disp(LED1_STATUS_LINE_NUM, LED_STATE_COL_NUM);
      Data_Str_Disp_LCD(led_on_msg_disp);
      Goto_XY_LCD_Disp(LED1_STATUS_LINE_NUM, LED_TIME_LEFT_COL_NUM);
      Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2,set_ledtime - num_sec);
      Goto_XY_LCD_Disp(LED2_STATUS_LINE_NUM, LED_TIME_LEFT_COL_NUM);
      Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, set_ledtime - num_sec);
      Goto_XY_LCD_Disp(LED2_STATUS_LINE_NUM, LED_STATE_COL_NUM);
      Data_Str_Disp_LCD(led_off_msg_disp); 
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 33   
-*------------------------------------------------------------*/
void Reset_Process()
{
   Write_LCD_Command(0x01);  //clear screen
   Write_LCD_Command(0x0F);  //display on, cursor on and blinking on
   
   Stop_Timer1();   
   no_press_key_flag = STATE_NO; 
   long_pressed_key_flag= STATE_NO;
   Goto_XY_LCD_Disp(LED_SEC_MSG_LINE_NUM, NUM_COL1);
   Data_Str_Disp_LCD(time_set_msg_disp); 
   Goto_XY_LCD_Input(LED_SEC_ENTRY_LINE_NUM,NUM_COL1);
   num_calls_timer1 = 0;   
   set_ledtime =0;
  time_left_no_key_press = MAX_TIMEOUT_NO_KEY_PRESS;
  time_left_long_press_key = MAX_TIMEOUT_LONG_PRESS_KEY;
   
   NO_KEY_PRESS_LED_PIN =LED_OFF;
   LONG_PRESS_KEY_LED_PIN = LED_OFF;  
   LED1_PIN = LED_OFF;
   LED2_PIN = LED_OFF; 
   need_input_flag = STATE_YES;
   inc_sw_enable_flag = STATE_YES;
   dec_sw_enable_flag = STATE_YES;
   enter_sw_enable_flag = STATE_YES;
   reset_sw_enable_flag = STATE_NO;
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 20   
-*------------------------------------------------------------*/
void Init_Const_Data()
{
	/* in var defination only const expression will be used for var initialzation,
	so in var definition, strlen() cannot be used for var initialzation */
	
    time_msg_disp_len = strlen(time_msg_disp);
    count_msg_disp_len = strlen(count_msg_disp);
	long_press_timeout_msg_disp_len = strlen(timeout_long_press_msg_disp); 
    /*start_col_time_long_press_msg_disp = 2 = 1(cur_pressed_key_or_sw) + 1 (next loc) */	  
	start_col_long_press_timeout_msg_disp = sizeof(char) + 1; 
    start_col_long_press_time_msg_disp = long_press_timeout_msg_disp_len + start_col_long_press_timeout_msg_disp;
	/* loc for long press time msg disp = time_long_press_disp_len
    + 2( char of cur_pressed_key_or_sw(1) + col starts from 1 for us but for uC col starts from 0 so 1 is added) */
	start_col_long_press_time_disp = start_col_long_press_time_msg_disp + time_msg_disp_len;
	 /* count msg disp at loc = start loc of disp_loc_long_press_time + 2(2 space for display 2 digit time)  */
	start_col_long_press_count_msg_disp = start_col_long_press_time_disp + 2;
    start_col_long_press_count_disp = start_col_long_press_count_msg_disp + count_msg_disp_len; 
	
	 start_col_no_key_time_msg_disp = strlen(timeout_no_key_msg_disp) + 1;
	 start_col_no_key_time_msg_disp, start_col_no_key_time_disp = strlen(timeout_no_key_msg_disp) + 1 + strlen(time_msg_disp);
	 
	 start_col_error_msg_disp =  NUM_CHARS_TRACE_CODE + 1;	 
	 start_col_error_code =  start_col_error_msg_disp + strlen(error_msg_disp) ; 	 
	
	 // 1 (next loc)
	 start_col_reason_timeout_msg_disp = strlen(key_timeout_msg_disp) + NUM_COL1; 
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 9  
-*------------------------------------------------------------*/
void Disp_Status_Fsm()
{
	 Write_LCD_Command(0x01); //clear display    
	 Write_LCD_Command(0x0C);
	   
	   switch(status_disp_fsm)
       {
          case TIMEOUT_LONG_KEY_PRESS:
		     Goto_XY_LCD_Disp(FAILED_SET_TIME_REASON_LINE_NUM, NUM_COL1);
			 Data_Str_Disp_LCD(key_timeout_msg_disp);
		     Goto_XY_LCD_Disp(FAILED_SET_TIME_REASON_LINE_NUM, start_col_reason_timeout_msg_disp);
             Data_Str_Disp_LCD(error_long_key_press_msg_disp);	 
			 		
             break;
	     case TIMEOUT_NO_KEY_PRESS:	
           	Goto_XY_LCD_Disp(FAILED_SET_TIME_REASON_LINE_NUM, NUM_COL1);
			Data_Str_Disp_LCD(key_timeout_msg_disp);	 
		  	Goto_XY_LCD_Disp(FAILED_SET_TIME_REASON_LINE_NUM, start_col_reason_timeout_msg_disp);
			Data_Str_Disp_LCD(error_no_key_press_msg_disp);	
					
			break;
         default:             
            Error_or_Warning_Proc("09.01", FATAL_OCCURED, ERR_DISP_FSM_STATE_CODE);  
           /* error: invalid auth disp status */            	  		   
      }
	
   /* waiting for reset sw input and parameters set for just before reset process */
   cur_line_disp_data[LONG_PRESSKEY_TIMEOUT_LINE_NUM] = BLANK_LINE_DISP;
   cur_line_disp_data[NO_KEYPRESS_TIMEOUT_LINE_NUM] = BLANK_LINE_DISP;
   time_left_long_press_key = MAX_TIMEOUT_LONG_PRESS_KEY;
   time_left_no_key_press = MAX_TIMEOUT_NO_KEY_PRESS;
   count_long_press_key_timeout = 0;
   
   need_input_flag = STATE_NO;   
   inc_sw_enable_flag = STATE_NO;
   dec_sw_enable_flag = STATE_NO;
   enter_sw_enable_flag = STATE_NO;
   reset_sw_enable_flag = STATE_YES;    
   Stop_Timer1();
} 
   

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 23   
-*------------------------------------------------------------*/
  void Write_LCD_Command (unsigned int cmd)
  {
	  unsigned long int  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  
       RW_PIN = 0;
       RS_PIN = 0; 
       LCD_PORT = cmd;
      // LCD_Pulse();
	  EN_PIN = 1;
	  while(time_delay--);
    // Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
      EN_PIN = 0;
	  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  while(time_delay--);
   //  Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
 }
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 24   
-*------------------------------------------------------------*/
 void Write_LCD_Data(const char ch)
{
	unsigned long int  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	// performance degraded if many data is written to LCD, to check if write loc is within avail disp loc
	// if(lcd_avail_loc_within_limit == STATE_YES) 
	{	
      RW_PIN = 0;
      RS_PIN = 1;
      LCD_PORT =ch;
     // LCD_Pulse();
      EN_PIN = 1;
	  while(time_delay--);
    // Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
     EN_PIN = 0;
	 time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  while(time_delay--);
   //  Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);	 
	}
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 25   
-*------------------------------------------------------------*/

void Data_Str_Disp_LCD(const char *char_ptr)
{ 
       while(*char_ptr)
       {
            Write_LCD_Data(*(char_ptr++));
       }
     
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 27  
-*------------------------------------------------------------*/
void Delay_Time_ByCount( unsigned int time_delay)
{
       while(time_delay--);
}
