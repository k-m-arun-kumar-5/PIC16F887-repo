/**************************************************************************
   FILE          :    intp_event_Handle.c
 
   PURPOSE       :  interrupt Event Handler Library
 
   AUTHOR        :  K.M.Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #include "main.h"
 #include "port.h"
 #include "lcd.h"
 #include "uart.h"
 #include "timer.h"
 #include "io_conf.h"
 #include "appl_conf.h"
 
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void External_Interrupt_Occured_Appl_Proc()
{	
    EXTR_INTP_LED = LED_ON;
	#ifdef TRACE
	  UART_Transmit_Str("EXTR INTP LED is ON \r");
	#endif  
	__delay_ms(REQ_TIME_EXTR_INTP_LED_ON_IN_MILLI_SEC);
	EXTR_INTP_LED = LED_OFF;
    #ifdef TRACE
	  UART_Transmit_Str("EXTR INTP LED is OFF \r");
	#endif 	
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void Timer1_Req_Time_Expiry_Appl_Proc()
{	
    switch(timer1_last_run_state_before_stop)
	{
		case TMR1_NORMAL_LED_OFF_STATE:
		   NORMAL_LED = LED_ON;
		   #ifdef TRACE
		     UART_Transmit_Str("NORMAL LED is ON \r");
		   #endif
		   Timer1_Run(TMR1_NORMAL_LED_ON_STATE,REQ_TIME_NORMAL_LED_CHANGE_STATE_IN_MILLI_SEC, TMR1_INTP_SERVICE,TMR1_GATE_CTRL_DISABLE, TMR1_INPUT_CLK_PRESCALE_8, TMR1_LP_OSC_DISABLE, TMR1_CLK_SRC_INTR_OSC); 	   
		   /* if below statements are inserted, then Timer1_Run( with TMR1_INTP_SERVICE ),before complete executing below statemets, will overflow (TMR1IF ==1 is true), causing
              errors in operation and stack underflow  */
		   /* NORMAL_LED = LED_ON;		   
		     UART_Transmit_Str("NORMAL LED is ON \r"); */
		   
		break;
		case TMR1_NORMAL_LED_ON_STATE:
		   NORMAL_LED = LED_OFF;
           #ifdef TRACE
		     UART_Transmit_Str("NORMAL LED is OFF \r");
		   #endif
		   Timer1_Run(TMR1_NORMAL_LED_OFF_STATE, REQ_TIME_NORMAL_LED_CHANGE_STATE_IN_MILLI_SEC, TMR1_INTP_SERVICE,TMR1_GATE_CTRL_DISABLE, TMR1_INPUT_CLK_PRESCALE_8, TMR1_LP_OSC_DISABLE, TMR1_CLK_SRC_INTR_OSC); 		   		   
		   /* if below statements are inserted, then Timer1_Run( with TMR1_INTP_SERVICE ),before complete executing below statemets, will overflow (TMR1IF ==1 is true), causing
              errors in operation and stack underflow  */
		  /* NORMAL_LED = LED_OFF;           
		     UART_Transmit_Str("NORMAL LED is OFF \r"); */
		  
		break;
		default:
		  ;		
	}	
}


/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
