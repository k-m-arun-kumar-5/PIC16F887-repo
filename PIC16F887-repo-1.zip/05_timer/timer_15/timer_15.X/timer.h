/**************************************************************************
   FILE          :    timer.h
 
   PURPOSE       :    timer library Header
 
   AUTHOR        :   K.M.Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _TIMER_H
 #define _TIMER_H
 
 #include "appl_conf.h"
 
 /* ---------------------- macro defination ------------------------------------------------ */
 
  
/* ---------------------- data type defination --------------------------------------------- */

typedef enum {
	TMR1_INVALID_SERVICE, TMR1_INTP_SERVICE, TMR1_POLLING_SERVICE
} timer1_service_types;
 
 typedef enum {
	 TMR1_GATE_CTRL_DISABLE = 0b00000000,         //Timer1 Gate control disable
	 TMR1_GATE_CTRL_ACTIVE_HIGH = 0b11000000,     //Timer1 Gate control enabled, and Timer1 gate is active-high (Timer1 counts when gate is high and timer 1 pauses when gate is low)
	 TMR1_GATE_CTRL_ACTIVE_LOW = 0b01000000     //Timer1 Gate control enabled, and Timer1 gate is active-low (Timer1 counts when gate is low and timer 1 pauses when gate is high)
 } timer1_gate_control_types;
 
 typedef enum {
   TMR1_CLK_SRC_INTR_OSC = 0b00000000,         // Timer1 Clock Source as Internal clock (FOSC/4)
   TMR1_CLK_SRC_EXTR_SYNC = 0b00000010,        // Timer1 Clock Source as External clock from T1CKI pin (on the rising edge) and Synchronize external clock input 
   TMR1_CLK_SRC_EXTR_NO_SYNC = 0b00000110      // Timer1 Clock Source as External clock from T1CKI pin (on the rising edge) and dont Synchronize external clock input     
 } timer1_clock_sources;
 
typedef enum { 
   TMR1_LP_OSC_ENABLE = 0b00001000,     // LP(low power) oscillator is enabled for Timer1 clock
   TMR1_LP_OSC_DISABLE = 0b00000000     // LP(low power) oscillator is off for Timer1 clock
 } timer1_LP_osc_control_types; 
 
 typedef enum { 
   TMR1_INPUT_CLK_PRESCALE_8 = 0b00110000, //Timer1 Input Clock 1:8 Prescale Value from Timer1 Clock Source
   TMR1_INPUT_CLK_PRESCALE_4 = 0b00100000, //Timer1 Input Clock 1:4 Prescale Value from Timer1 Clock Source
   TMR1_INPUT_CLK_PRESCALE_2 = 0b00010000, //Timer1 Input Clock 1:2 Prescale Value from Timer1 Clock Source
   TMR1_INPUT_CLK_PRESCALE_1 = 0b00000000  //Timer1 Input Clock 1:1 Prescale Value from Timer1 Clock Source
 } timer1_input_clock_prescaler_types; 
 
 /* -------------------- public variable declaration --------------------------------------- */
 
extern unsigned int timer1_prescale, timer1_prescale_shift, timer1_elapsed_num_update;
extern unsigned long int  timer1_init_val, timer1_elapsed_num_overflow_1_update, timer1_1_update, timer1_max_num_overflow, timer1_req_time_max_update;
extern unsigned long int timer1_req_time_delay_in_milli_sec;
extern timer1_run_states timer1_cur_run_state, timer1_last_run_state_before_stop;
 extern timer1_service_types timer1_cur_service_type;

 /* -------------------- public prototype declaration --------------------------------------- */
 
void Timer1_Run(const timer1_run_states set_timer1_run_mode, const unsigned long int set_req_time_delay_in_milli_sec, const timer1_service_types set_timer1_service, const timer1_gate_control_types set_gate_control_type, \
  const timer1_input_clock_prescaler_types set_timer1_input_clock_prescaler_type, const timer1_LP_osc_control_types set_timer1_LP_osc_control_type, const timer1_clock_sources set_timer1_clock_source  );
void Timer1_Stop();
void Timer1_Prescale();
void Timer1_Load_Init_Val_Calc(const unsigned long int set_timer1_tick_in_milli_sec);

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
