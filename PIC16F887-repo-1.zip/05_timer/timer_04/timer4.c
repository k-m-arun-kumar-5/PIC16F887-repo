/* ********************************************************************
FILE                   : timer4.c

PROGRAM DESCRIPTION    :  initially, using INC_SW to increment time, DEC_SW to decrement time, 
  and ENTER_SW to enter the configured time in seconds and start Timer. Use RESET_SW to reset. 
  Corresponding Time configure should be displayed in LCD. LED ON and LED OFF time are equal duration.
  Once configured time, INC_SW, DEC_SW and ENTER_SW should not affect LED flashing.
  RESET_SW should stop timer and allow to configure the time duration in seconds.
  Start the LED flashing and and using timer0, periodically flash LED1 OFF 
 and LED2 ON for configured time in sec and LED1 ON and LED2 OFF for configured time in seconds 
 and display LED status in LCD with remaining time left in Led status. 

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : fix issue of timer to get precise time using timer. Use PIC16F887-repo->05_timer->timer17.X->timer.c as base code to get precise time using timer.

NOTE                  : 
 
USED:              
                      Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
                      IDE :  MPLAB X IDE v4.01 with MPLAB XC8 C Compiler.      			 
                   CADD: Simulated in Proteus 8.0 Professional                         
                       
CHANGE LOGS           : 

*****************************************************************************/   
#ifdef HI_TECH_COMPILER
  #include <pic.h>
  __CONFIG(0X2CE4);
#else // XC8 compiler
  #include <xc.h>
#endif
#include <string.h>
#define LED1_PIN               					RA0
#define LED2_PIN 								RA1
#define NO_KEY_PRESS_LED_PIN                    RA6
#define LONG_PRESS_KEY_LED_PIN                  RA7
#define INC_SW                                  RD3
#define DEC_SW                                  RD4
#define ENTER_SW                                RD5
#define RESET_SW                                RD6
#define MAX_PRESSED_KEY_COUNT                  (100000UL)
#define MAX_NO_KEY_PRESS_COUNT                 (100000UL)
#define MIN_SET_LED_TIME                        (02) 
#define WRAP_SET_TIME                           (99)
#define RS_PIN                                	RD0
#define RW_PIN                                 	RD1
#define EN_PIN                                	RD2
#define LCD_PORT                               PORTC
 
#define FIRST_LINE                        (0x80)
#define SECOND_LINE                       (0xC0)
#define TICK_MS  (2UL) // TIMER0 expires every 2ms
#define TIME_UNIT (1000UL)
#define OSC_PER_INST (4)
#define UPDATE_TIME (1000UL)/TICK_MS //UPDATE_TIME configured for 1 sec
#define _XTAL_FREQ   (4000000UL)
#define INC (unsigned int)((unsigned long)(_XTAL_FREQ * TICK_MS) / (unsigned long)(OSC_PER_INST * TIME_UNIT))

#define LED1_FSM_OFF    (1)
#define LED1_FSM_ON     (2)
#define OFF         (0)
#define ON          (1)
//#define LED1_ON_TIME    2 // 2 sec on time
//#define LED1_OFF_TIME   2 // 2 sec off time                    


void delay_time(unsigned int);
void pulse ();
void lcd_command (unsigned int);
void lcd_data(char);
void data_str(const char * );
void data_2digit(unsigned int);

void lcd_init();
void Led_Init(unsigned int);
void Goto_XY_LCD(unsigned int line,unsigned int col);
void LCD_Const_Disp();
unsigned int prescale_timer0 =  0x2, prescale_shift= 0,num_sec = 0;
unsigned long int num_calls = 0;
unsigned int led1_fsm_state = LED1_FSM_OFF;
const char led_on_disp[] = " ON", led_off_disp[] = "OFF";
unsigned int cur_loc = FIRST_LINE, set_ledtime=0;

char timer_on_flag = 'n', no_press_key_flag = 'y', long_pressed_key_flag= 'n';
unsigned long int no_key_press_count = MAX_NO_KEY_PRESS_COUNT;
unsigned  long int pressed_key_count = MAX_PRESSED_KEY_COUNT;
const char time_set_disp[]= {"INC/DEC Time"}, error_disp[]={"ERROR:"}, min_time_disp[]={"Min Time: "};
void Led1_on();
void Led1_off();
void Prescale_Timer();     
void Timer0_Tick();
void Fsm_Led();
void Disp_LED_Status();
void Reset_Process();
void Run_Timer0();
void main()
{
   TRISA = 0x00;
   PORTA = 0x00;
   TRISB = 0x00;
   PORTB = 0x00;
   TRISC = 0x00;
   PORTC = 0x00;
   TRISD = 0x78;
   PORTD = 0x00;
   ANSEL= 0X00;
   ANSELH=0X00;
   lcd_init();
   Reset_Process();
   
   for(;;)
   {
     if(timer_on_flag != 'y' )
     {
        if(--no_key_press_count == 0)
        {
          NO_KEY_PRESS_LED_PIN = ON;
          no_press_key_flag = 'y';             
        }  
     }
     
     if(timer_on_flag !='y' && INC_SW == 1)
     { 
        no_key_press_count = MAX_NO_KEY_PRESS_COUNT; 
        while(INC_SW == 1 && (--pressed_key_count !=0));
          if(pressed_key_count ==0)
          {
             LONG_PRESS_KEY_LED_PIN = ON;
             long_pressed_key_flag ='y';
          }
          if(long_pressed_key_flag !='y')
          {
             if(set_ledtime >= WRAP_SET_TIME )
               set_ledtime = 0;        
 	     else       		 
               ++set_ledtime;
             Goto_XY_LCD(1,0);  
             data_2digit(set_ledtime);  
          }                              
     }
     if(timer_on_flag !='y' && DEC_SW == 1)
     { 
        no_key_press_count = MAX_NO_KEY_PRESS_COUNT;
        while(DEC_SW == 1 && (--pressed_key_count !=0));
          if(pressed_key_count ==0)
          {
             LONG_PRESS_KEY_LED_PIN = ON;
             long_pressed_key_flag ='y';
          }
          if(long_pressed_key_flag !='y')
          {
             if(set_ledtime == 0)
                 set_ledtime = WRAP_SET_TIME;
              else                   
                --set_ledtime;
             Goto_XY_LCD(1,0);  
             data_2digit(set_ledtime);  
          }                              
     }
     if(timer_on_flag !='y' && ENTER_SW == 1)
     {
       no_key_press_count = MAX_NO_KEY_PRESS_COUNT;
       while(ENTER_SW == 1 && (--pressed_key_count !=0));
       if(pressed_key_count ==0)
       {
           LONG_PRESS_KEY_LED_PIN = ON;
           long_pressed_key_flag ='y';
       }
       if(long_pressed_key_flag !='y')
       {
          lcd_command(0x01);  //clear screen
          cur_loc = FIRST_LINE;                 
          if(set_ledtime >= MIN_SET_LED_TIME)
          {
            timer_on_flag ='y';
            lcd_command(0x0C);  //display on, cursor off and blinking off 
            LCD_Const_Disp();
            Run_Timer0();
            Led_Init(LED1_FSM_OFF);
         }
         else
         {
           data_str(error_disp);
           Goto_XY_LCD(1,0); 
           data_str(min_time_disp);
           data_2digit(MIN_SET_LED_TIME);
         }                              
       }
     }
     if(RESET_SW == 1)
     {
       no_key_press_count = MAX_NO_KEY_PRESS_COUNT;
       while(RESET_SW == 1 && (--pressed_key_count !=0));
       if(pressed_key_count ==0)
       {
           LONG_PRESS_KEY_LED_PIN = ON;
           long_pressed_key_flag ='y';
       }
       if(long_pressed_key_flag !='y')      
        Reset_Process();                                
     }                            
     if(timer_on_flag == 'y')
     {
       Timer0_Tick();
     }  
  }
}
void Run_Timer0()
{
	T0CS  = 0; // Internal Clock
   PSA = 0 ;//PRESCALE SET for timer 0
   PS0 = 0; //prescaler 1:8 
   PS1 = 1;
   PS2 = 0;
   prescale_timer0 =  0x02;
   prescale_shift= 0;
   Prescale_Timer();
   TMR0= 256 - (INC/prescale_timer0);   
}
void Timer0_Tick()
{ 
     while(T0IF == 0);
     T0IF = 0;
     TMR0= 256 - (INC/prescale_timer0);
     if(++num_calls >= UPDATE_TIME)
     {
        Fsm_Led();
        num_calls = 0;        
     }         
} 
/* Every 1 second Fsm_Led() is called*/                                                                                                                                                                                                                                                                                                                      
void Fsm_Led()
{
    switch(led1_fsm_state)
    {
      case LED1_FSM_OFF:
      ++num_sec;                       
      Led1_off();
      if(num_sec >= set_ledtime )  //set_ledtime = LED1 off TIME
      {
        num_sec = 0;
        led1_fsm_state =LED1_FSM_ON;
        Led1_on();               
      }
      break;
      case LED1_FSM_ON:
       ++num_sec;                  
      Led1_on();
      if(num_sec >= set_ledtime ) //set_ledtime = LED1 ON TIME
      {
        num_sec = 0;
        led1_fsm_state =LED1_FSM_OFF; 
        Led1_off();                 
      }
      break; 
    }               
}

void Prescale_Timer()
{
   if(PS0 == 1)
   {
      prescale_shift |= 0x01;           
   }
   if(PS1 == 1)
   {
     prescale_shift |= 0x02;
   }  
   if(PS2 == 1)
   {
     prescale_shift |= 0x04;
   } 
   prescale_timer0 = prescale_timer0  << prescale_shift;                                                       
}
void lcd_init()
{
    lcd_command(0x30);
    lcd_command(0x30);
    lcd_command(0x30);
    lcd_command(0x38);
    lcd_command(0x01);	
    lcd_command(0x0C);
    lcd_command(0x06);                                       
}     

void pulse()
{
        EN_PIN = ON;
        delay_time(100);
        EN_PIN = OFF;
        delay_time(100);
}
  void lcd_command (unsigned int cmd)
 {
         RW_PIN = OFF;
         RS_PIN = OFF; 
         LCD_PORT = cmd;
         pulse();
 }
 void lcd_data(char ch)
{
     RW_PIN = OFF;
     RS_PIN = ON;
     LCD_PORT =ch;
     pulse();
} 
void data_str(const char *char_ptr)
{ 
       while(*char_ptr)
       {
           lcd_data(*(char_ptr++));
       }
}
void data_2digit(unsigned int data_int)
{
    unsigned int tens_digit, unit_digit,num;
    char num_data[] ={'0','1','2','3','4','5','6','7','8','9'};  
	num = data_int %100;
    unit_digit = data_int % 10;
    tens_digit = num / 10;
    lcd_data(num_data[tens_digit]);
   // lcd_data(tens_digit + 30); // num in ascii code   
    lcd_data(num_data[unit_digit]); 
   // lcd_data(unit_digit + 30); // num in ascii code                                 
}
void delay_time(unsigned int time_delay)
{
    while(time_delay--);
} 
void Goto_XY_LCD(unsigned int line,unsigned int col)
{
   if(line < 2 && col < 16 )
   {
    cur_loc = FIRST_LINE | line << 6;
    cur_loc = cur_loc + col;
    lcd_command(cur_loc);
   }
}
void LCD_Const_Disp()
{
  Goto_XY_LCD(0,0);
  data_str("LED1 ");
  Goto_XY_LCD(0,12);
  data_str("Secs");
  Goto_XY_LCD(1,0);
  data_str("LED2 "); 
  Goto_XY_LCD(1,12);
  data_str("Secs");        
}
void Led_Init(unsigned int led_init_state)
{
   num_sec = 0;  
   led1_fsm_state = led_init_state; 
   switch(led_init_state)
   {
    case LED1_FSM_OFF:
      Led1_off();
      break;
     case LED1_FSM_ON:
      Led1_on();
      break;
   }  
}
void Led1_off()
{
   LED1_PIN =OFF;
   LED2_PIN =ON;
   Goto_XY_LCD(0,5);
   data_str(led_off_disp);
   Goto_XY_LCD(0,9);
   data_2digit(set_ledtime - num_sec);
   Goto_XY_LCD(1,9);
   data_2digit(set_ledtime - num_sec);
   Goto_XY_LCD(1,5);
   data_str(led_on_disp);
}
void Led1_on()
{
     LED1_PIN =ON;
      LED2_PIN =OFF;
      Goto_XY_LCD(0,5);
      data_str(led_on_disp);
      Goto_XY_LCD(0,9);
      data_2digit(set_ledtime - num_sec);
      Goto_XY_LCD(1,9);
      data_2digit(set_ledtime - num_sec);
      Goto_XY_LCD(1,5);
      data_str(led_off_disp); 
}
void Timer_Init()
{
   T0CS = 0; // Internal Clock
   PSA = 0 ;//PRESCALE SET for timer 0
   PS0 = 0; //prescaler 1:8 
   PS1 = 1;
   PS2 = 0;
   Prescale_Timer();
   TMR0= 256 - (INC/prescale_timer0); 
   PORTB = 256 - (INC/prescale_timer0); 
}
 
void Reset_Process()
{
   lcd_command(0x01);  //clear screen
   lcd_command(0x0F);  //display on, cursor on and blinking on
   timer_on_flag = 'n'; 
   no_press_key_flag = 'y'; 
   long_pressed_key_flag= 'n';
   //Goto_XY_LCD(0,0);
   cur_loc = FIRST_LINE;
   data_str(time_set_disp); 
   Goto_XY_LCD(1,0);
   num_calls = 0;   
   prescale_shift= 0; 
   prescale_timer0 =0x2;
   set_ledtime =0;
   no_key_press_count = MAX_NO_KEY_PRESS_COUNT; 
   pressed_key_count = MAX_PRESSED_KEY_COUNT;
   NO_KEY_PRESS_LED_PIN =OFF;
   LONG_PRESS_KEY_LED_PIN = OFF;  
   LED1_PIN = OFF;
   LED2_PIN = OFF;     
}
