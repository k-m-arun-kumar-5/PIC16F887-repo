/**************************************************************************
   FILE          :    appl_conf.h
 
   PURPOSE       :   main application configuration Header
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _APPL_CONF_H
 #define _APPL_CONF_H 
 
/*------------------------------- LCD disp conf ------------------------------------------*/
#define PULSE_MEASURE_MSG_LINE_NUM        (1U)
#define PULSE_MEASURE_DISP_LINE_NUM       (2U)

/* -------------------------------Timer state conf ---------------------------------------*/

#define TMR1_SYSTEM_PERIOD_STATE         (0)
#define TMR1_STATE0_SERVICE_TYPE          TMR1_COMPARE_SERVICE | TMR1_INTP_SERVICE
#define TMR1_STATE0_GATE_CTRL_TYPE        TMR1_GATE_CTRL_DISABLE
#define TMR1_STATE0_CLK_TYPE              TMR1_CLK_SRC_INTR_OSC
#define TMR1_STATE0_LP_OSC_ENABLE_TYPE    TMR1_LP_OSC_DISABLE

/*valid value 1,2,4,8 */
#define TMR1_STATE0_PRESCALE              (2) //Timer1 Input Clock 1:2 Prescale Value from Timer1 Clock Source

/* ------------------------------- application conf --------------------------------------*/

#define LED1_PERIOD              50
#define LED2_PERIOD             100
 
#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
