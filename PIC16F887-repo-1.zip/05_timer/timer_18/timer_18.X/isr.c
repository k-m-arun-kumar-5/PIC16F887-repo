/**************************************************************************
   FILE          :    isr.c
 
   PURPOSE       :   Interrupt Service Routine Library
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #include "main.h"
 #include "port.h"
 #include "io_conf.h"
 #include "timer.h"
 #include "uart.h"
 #include "intp_event_handle.h" 
 
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void interrupt Interrupt_ISR() 
{
	
	if(CCP2IF == 1)     // CCP2 interrupt ISR 
	{
		 CCP2IF = 0;		
		 if(timer1_cur_service_type & 0x04)
	     {
			  /* #ifdef TRACE
	            UART_Transmit_Str("A \r");
	          #endif */
			 Timer1_Compare_Match_Appl_Proc();			
		 }		 
	} 
	
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
