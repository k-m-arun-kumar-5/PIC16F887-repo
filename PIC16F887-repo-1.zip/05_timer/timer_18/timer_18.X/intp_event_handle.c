/**************************************************************************
   FILE          :    intp_event_Handle.c
 
   PURPOSE       :  interrupt Event Handler Library
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
#include "main.h"
#include "timer.h" 
#include "uart.h"
#include "io_conf.h"
#include "appl_conf.h"
#include "intp_event_handle.h"
 extern tmr_client_type tmr_client[];
 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void External_Interrupt_Occured_Appl_Proc()
{	
   
	  
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void Timer1_Req_Time_Expiry_Appl_Proc()
{	
    
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
 void Timer1_Compare_Match_Appl_Proc()
 {
	if(++tmr_client[0].cur_tick >= tmr_client[0].max_tick)  
	{
		tmr_client[0].cur_tick = 0;		
		tmr_client[0].Tmr1_Event_Handler(tmr_client[0].temp_data_ptr, 0);
	}
	if(++tmr_client[1].cur_tick >= tmr_client[1].max_tick)  
	{
		tmr_client[1].cur_tick = 0;
		tmr_client[1].Tmr1_Event_Handler(tmr_client[1].temp_data_ptr, 0);
	} 
 }
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
