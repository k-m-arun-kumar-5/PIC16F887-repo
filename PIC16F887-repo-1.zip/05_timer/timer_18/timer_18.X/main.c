/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : when START_SW is valid pressed on, pulse is counted by using counter mode in timer 1, then press on and release PULSE_SW to generate a pulse and 
                         after a specific time duration by _delay_ms() from moment START_SW was valid pressed on, read pulse count is measured by counter mode in timer 1. 
						 Use RESET_SW to reset the process.                       									 
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :  fix issue of timer to get precise time using timer. Use PIC_codes_16f887->05_timer->timer17.X->timer.c as base code to get precise time using timer. 

NOTE                  :                   								
                        
                       
CHANGE LOGS           : 

*****************************************************************************/
 // PIC16F887 Configuration Bit Settings
// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.
// 'C' source line config statements

// CONFIG1
//#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config FOSC = HS        // Oscillator Selection bits (HS oscillator: High-speed crystal/resonator on RA6/OSC2/CLKOUT and RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = ON       // Power-up Timer Enable bit (PWRT enabled)
#pragma config MCLRE = ON       // RE3/MCLR pin function select bit (RE3/MCLR pin function is MCLR)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = ON        // Internal External Switchover bit (Internal/External Switchover mode is enabled)
#pragma config FCMEN = ON       // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is enabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off) 

#include "main.h"
#include "port.h"
#include "lcd.h"
#include "timer.h"
#include "uart.h"
#include "io_conf.h"
#include "appl_conf.h"

#define LED1_FSM_ON              (1)
#define LED1_FSM_OFF             (0)
#define LED2_FSM_ON              (1)
#define LED2_FSM_OFF             (0)

value_types to_disp;

unsigned int led1_cur_fsm = LED1_FSM_OFF, led2_cur_fsm = LED2_FSM_OFF ;

static void Led1_Event_Handler(void *, unsigned long int );
static void Led2_Event_Handler(void *, unsigned long int );

tmr_client_type tmr_client[2] = {{0, LED1_PERIOD, Led1_Event_Handler, &led1_cur_fsm }, {0, LED2_PERIOD, Led2_Event_Handler, &led2_cur_fsm }}; 

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void main()
{
   PORTA = 0x00;	
   LED1_TRIS = 0;
   LED2_TRIS = 0; 
    
   ANSEL = 0x00;
   ANSELH = 0x00; 
   
   CCP2CON = 0x0A;
   CCPR2 = 1000; 
   UART_Init(); 
   LCD_Init();  
   
   Timer1_Run(TMR1_SYSTEM_PERIOD_STATE, 0);  
   while(1)
   {
	   
	   	
   }   
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Write_Bit

DESCRIPTION     : write bit valve to data's bit, without affecting other bits of data .
                . 0 is the least bit pos and 7 is the most bit pos 

INPUT          : 

OUTPUT         : none

NOTE           : 
-*------------------------------------------------------------*/
void Write_Bit_in_Data(unsigned int *data, const unsigned int bit_pos, const unsigned int set_bit_val )
{
     if (set_bit_val == 1)
       {
          Set_Bit_in_Data(data, bit_pos);
          return;
       }
       Clear_Bit_in_Data(data, bit_pos ); 
}

/*------------------------------------------------------------*-
FUNCTION NAME  : 

DESCRIPTION     :  

INPUT          : 

OUTPUT         : none

NOTE           : 
-*------------------------------------------------------------*/
static void Led1_Event_Handler(void *data_ptr, unsigned long int data)
{
	unsigned int *led1_temp_data_ptr = (unsigned int *)data_ptr;
	
  	switch(*led1_temp_data_ptr)
	{
		case LED1_FSM_OFF:
		   LED1_PIN = LED_ON;
		   *led1_temp_data_ptr = LED1_FSM_ON;
		break;
        case LED1_FSM_ON:
            LED1_PIN = LED_OFF;
		   *led1_temp_data_ptr = LED1_FSM_OFF;
		break;	
	}     
}

/*------------------------------------------------------------*-
FUNCTION NAME  : 

DESCRIPTION     :  

INPUT          : 

OUTPUT         : none

NOTE           : 
-*------------------------------------------------------------*/
static void Led2_Event_Handler(void *data_ptr, unsigned long int data)
{
     unsigned int *led2_temp_data_ptr = (unsigned int *)data_ptr;
	
  	switch(*led2_temp_data_ptr)
	{
		case LED2_FSM_OFF:
		   LED2_PIN = LED_ON;
		   *led2_temp_data_ptr = LED2_FSM_ON;
		break;
        case LED2_FSM_ON:
            LED2_PIN = LED_OFF;
		   *led2_temp_data_ptr = LED2_FSM_OFF;
		break;	
	}     	
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
