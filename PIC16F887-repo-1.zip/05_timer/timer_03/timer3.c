/* */
 
 /* ********************************************************************
FILE                   : timer3.c

PROGRAM DESCRIPTION    : using timer0, periodically flash LED1 OFF and LED2 ON for 2 sec
 and LED1 ON and LED2 OFF for 2 seconds and display LED status in LCD 
 with remaining time left in Led status 
 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : fix issue of timer to get precise time using timer. Use PIC16F887-repo->05_timer->timer17.X->timer.c as base code to get precise time using timer.

NOTE                  : 
 
USED:              
                      Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
                      IDE :  MPLAB X IDE v4.01 with MPLAB XC8 C Compiler.      			 
                   CADD: Simulated in Proteus 8.0 Professional                         
                       
CHANGE LOGS           : 

*****************************************************************************/ 
#include <pic.h>
#define LED1_PIN RA0
#define LED2_PIN RA1
#define RS_PIN                                RD0
#define RW_PIN                                 RD1
#define EN_PIN                                 RD2
#define LCD_PORT                          PORTC
#define FIRST_LINE                        (0x80)
#define SECOND_LINE                       (0xC0)
#define TICK_MS  (2UL) // TIMER0 expires every 2ms
#define TIME_UNIT (1000UL)
#define OSC_PER_INST (4)
#define UPDATE_TIME (1000UL)/TICK_MS //UPDATE_TIME for 1 sec
#define _XTAL_FREQ   (4000000UL)
#define INC (unsigned int)((unsigned long)(_XTAL_FREQ * TICK_MS) / (unsigned long)(OSC_PER_INST * TIME_UNIT))

#define LED1_FSM_OFF    1
#define LED1_FSM_ON     2
#define LED1_ON_TIME    2 // 2 sec on time
#define LED1_OFF_TIME   2 // 2 sec off time                     
__CONFIG(0X2CE4);

void delay_time(unsigned int);
void pulse ();
void lcd_command (unsigned int);
void lcd_data(char);
void data_str(const char * );
void data_2digit(unsigned int);
void lcd_init();
void Led_Init(unsigned int);
void Goto_XY_LCD(unsigned int line,unsigned int col);
void LCD_Const_Disp();
unsigned int prescale_timer0 =  0x2, prescale_shift= 0,num_sec = 0;
unsigned long int num_calls = 0;
unsigned int led1_fsm_state = LED1_FSM_OFF;
const char led_on_disp[] = " ON", led_off_disp[] = "OFF";
unsigned int cur_loc = FIRST_LINE;
void Led1_on();
void Led1_off();
void Prescale_Timer();     
void Timer0_Tick();
void Fsm_Led();
void Disp_LED_Status();
void Run_Timer0();
void main()
{
   TRISA = 0x00;
   PORTA = 0x00;
   TRISB = 0x00;
   PORTB = 0x00;
   TRISC = 0x00;
   PORTC = 0x00;
   TRISD = 0x00;
   PORTD = 0x00;
   
   ANSEL=0X00;
   ANSELH=0X00;
   lcd_init();
   Run_Timer0();
   LCD_Const_Disp();
   
   Led_Init(LED1_FSM_OFF);
   for(;;)
   {
     Timer0_Tick();
  } 
}
void Run_Timer0()
{
	T0CS  = 0; // Internal Clock
   PSA = 0 ;//PRESCALE SET for timer 0
   PS0 = 0; //prescaler 1:8 
   PS1 = 1;
   PS2 = 0;
   prescale_timer0 =  0x02;
   prescale_shift= 0;
   Prescale_Timer();
   TMR0= 256 - (INC/prescale_timer0);   
}
void Timer0_Tick()
{
     while(T0IF == 0);
     T0IF = 0;
     TMR0= 256 - (INC/prescale_timer0);
     if(++num_calls >= UPDATE_TIME)
     {
        Fsm_Led();
        num_calls = 0;        
     }       
} 
/* Every 1 second Fsm_Led() is called*/                                                                                                                                                                                                                                                                                                                      
void Fsm_Led()
{
    switch(led1_fsm_state)
    {
      case LED1_FSM_OFF:
      ++num_sec;                       
      Led1_off();
      if(num_sec >= LED1_OFF_TIME )
      {
        num_sec = 0;
        led1_fsm_state =LED1_FSM_ON;
        Led1_on();               
      }
      break;
      case LED1_FSM_ON:
       ++num_sec;                  
      Led1_on();
      if(num_sec >= LED1_ON_TIME )
      {
        num_sec = 0;
        led1_fsm_state =LED1_FSM_OFF; 
        Led1_off();                 
      }
      break; 
    }               
}

void Prescale_Timer()
{
   if(PS0 == 1)
   {
      prescale_shift |= 0x01;           
   }
   if(PS1 == 1)
   {
     prescale_shift |= 0x02;
   }  
   if(PS2 == 1)
   {
     prescale_shift |= 0x04;
   } 
   prescale_timer0 = prescale_timer0  << prescale_shift;
  /* PORTC = prescale_timer0 % 256;  
   PORTD = (prescale_timer0 /256)% 256; */                                                      
}
void lcd_init()
{
    lcd_command(0x30);
    lcd_command(0x30);
    lcd_command(0x30);
    lcd_command(0x38);
    lcd_command(0x01);	
    lcd_command(0x0C);
    lcd_command(0x06);                                       
}     

void pulse()
{
        EN_PIN = 1;
        delay_time(100);
         EN_PIN = 0;
        delay_time(100);
}
  void lcd_command (unsigned int cmd)
 {
         RW_PIN = 0;
         RS_PIN = 0; 
         LCD_PORT = cmd;
         pulse();
 }
 void lcd_data(char ch)
{
     RW_PIN = 0;
     RS_PIN = 1;
     LCD_PORT =ch;
     pulse();
} 
void data_str(const char *char_ptr)
{ 
       while(*char_ptr)
       {
           lcd_data(*(char_ptr++));
       }
}
void data_2digit(unsigned int data_int)
{
    unsigned int tens_digit, unit_digit,num;
    char num_data[] ={'0','1','2','3','4','5','6','7','8','9'};  
	num = data_int %100;
    unit_digit = data_int % 10;
    tens_digit = num / 10;
    lcd_data(num_data[tens_digit]);
   // lcd_data(tens_digit + 30); // num in ascii code   
    lcd_data(num_data[unit_digit]); 
   // lcd_data(unit_digit + 30); // num in ascii code                                 
}
void delay_time(unsigned int time_delay)
{
    while(time_delay--);
} 
void Goto_XY_LCD(unsigned int line,unsigned int col)
{
   if(line < 2 && col < 16 )
   {
    cur_loc = FIRST_LINE | line << 6;
    cur_loc = cur_loc + col;
    lcd_command(cur_loc);
   }
}
void LCD_Const_Disp()
{
  Goto_XY_LCD(0,0);
  data_str("LED1 ");
  Goto_XY_LCD(0,12);
  data_str("Secs");
  Goto_XY_LCD(1,0);
  data_str("LED2 "); 
  Goto_XY_LCD(1,12);
  data_str("Secs");        
}
void Led_Init(unsigned int led_init_state)
{
   num_sec = 0;
   led1_fsm_state = led_init_state;  
   switch(led_init_state)
   {
    case LED1_FSM_OFF:
      Led1_off();
      break;
     case LED1_FSM_ON:
      Led1_on();
      break;
   }  
}
void Led1_off()
{
   LED1_PIN =0;
   LED2_PIN =1;
   Goto_XY_LCD(0,5);
   data_str(led_off_disp);
   Goto_XY_LCD(0,9);
   data_2digit(LED1_OFF_TIME - num_sec);
   Goto_XY_LCD(1,9);
   data_2digit(LED1_OFF_TIME - num_sec);
   Goto_XY_LCD(1,5);
   data_str(led_on_disp);
}
void Led1_on()
{
     LED1_PIN =1;
      LED2_PIN =0;
      Goto_XY_LCD(0,5);
      data_str(led_on_disp);
      Goto_XY_LCD(0,9);
      data_2digit(LED1_ON_TIME - num_sec);
      Goto_XY_LCD(1,9);
      data_2digit(LED1_ON_TIME - num_sec);
      Goto_XY_LCD(1,5);
      data_str(led_off_disp); 
}
                     
