/**************************************************************************
   FILE          :    module_conf.h
 
   PURPOSE       :   module enable configuration
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #ifndef _MODULE_CONF_H
 #define _MODULE_CONF_H
 
 #define TIMER1_MOD_ENABLE                      (01)
 #define TIMER2_MOD_ENABLE                      (02) 
 #define TIMER0_MOD_ENABLE                      (03)
 #define LCD_MOD_ENABLE                         (04)
 #define KEYPAD_MOD_ENABLE                      (05)
 #define CAPTURE_MOD_ENABLE                     (06)
 #define COMPARE_MOD_ENABLE                     (07)
 #define PWM_MOD_ENABLE                         (08)
 #define USART_MOD_ENABLE                       (09)
 #define ADC_MOD_ENABLE                         (10)
 #define GSM_MOD_ENABLE                         (11)
 #define COMPARATOR1_MOD_ENABLE                 (12)
 #define COMPARATOR2_MOD_ENABLE                 (13)
 #define SPI_MOD_ENABLE                         (14)
 #define I2C_MOD_ENABLE                         (15) 
 #define WATCHDOG_TIMER_MOD_ENABLE              (16)
 #endif
