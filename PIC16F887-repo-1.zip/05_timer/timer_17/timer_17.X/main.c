/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : when START_SW is valid pressed on, pulse is counted by using counter mode in timer 1, then press on and release PULSE_SW to generate a pulse and 
                         after a specific time duration by _delay_ms() from moment START_SW was valid pressed on, read pulse count is measured by counter mode in timer 1. 
						 Use RESET_SW to reset the process.                       									 
	 
AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  :                   								
                        
                       
CHANGE LOGS           : 

*****************************************************************************/
 // PIC16F887 Configuration Bit Settings
// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.
// 'C' source line config statements

// CONFIG1
//#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config FOSC = HS        // Oscillator Selection bits (HS oscillator: High-speed crystal/resonator on RA6/OSC2/CLKOUT and RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = ON       // Power-up Timer Enable bit (PWRT enabled)
#pragma config MCLRE = ON       // RE3/MCLR pin function select bit (RE3/MCLR pin function is MCLR)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = ON        // Internal External Switchover bit (Internal/External Switchover mode is enabled)
#pragma config FCMEN = ON       // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is enabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off) 

#include "main.h"
#include "port.h"
#include "io_conf.h"
#include "appl_conf.h"
#include "lcd.h"
#include "timer.h"
#include "uart.h"


char start_sw_enable_flag = STATE_YES_IN_CHAR, reset_sw_enable_flag = STATE_NO_IN_CHAR;
value_types to_disp;
static void Count_Pulse();
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void main()
{
		
   TRISAbits.TRISA0 = 1;
   TRISAbits.TRISA1 = 1;
   TRISAbits.TRISA4 = 0;
  
   ANSEL = 0x00;
   ANSELH = 0x00; 
   
   UART_Init(); 
   LCD_Init();  
     
   while(1)
   {
	   if(start_sw_enable_flag == STATE_YES_IN_CHAR && START_SW == 1)
	   {
		   __delay_ms(50);
		   if(START_SW == 1)
		   {
			   while(START_SW == 1);
			   start_sw_enable_flag = STATE_NO_IN_CHAR;
			   #ifdef TRACE
			      UART_Transmit_Str("Start pulse count measure \r");
			   #endif
			   Count_Pulse();
		   }
	   }
	   if(reset_sw_enable_flag == STATE_YES_IN_CHAR && RESET_SW == 1)
	   {
		   __delay_ms(50);
		   if(RESET_SW == 1)
		   {
			   while(RESET_SW == 1);
			   #ifdef TRACE
			      UART_Transmit_Str("reset pulse count measure \r");
			   #endif
			   start_sw_enable_flag = STATE_YES_IN_CHAR;
			   reset_sw_enable_flag = STATE_NO_IN_CHAR;
			   Write_LCD_Command(0x01);
		   }
	   }
	   	
   }   
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
static void Count_Pulse()
{	
   /* used to test if timer1_cur_service_type = TMR1_COUNTER_INTP_SERVICE and if timer1 overflow occured, then timer1 overflow interrupt must be generated */	
   // measure_pulse_lower_count = 0xFFFAul;	
    tmr1_measure_pulse_lower_count = 0;
	tmr1_measure_pulse_upper_count = 0;
	PULSE_MEASURE_OVER_LED = LED_OFF;
	
	#ifdef TRACE
		 UART_Transmit_Str("PULSE_MEASURE_OVER_LED is OFF \r");
    #endif
     
	Timer1_Run(TMR1_PULSES_MEASURE_STATE, 0);
    
    __delay_ms(REQ_TIME_PULSES_MEASURE_IN_SEC * TIME_UNIT_1_SEC_IN_MILLI_SEC);  
	
	PULSE_MEASURE_OVER_LED = LED_ON;
	
	#ifdef TRACE
		 UART_Transmit_Str("PULSE_MEASURE_OVER_LED is ON \r");
    #endif
	Timer1_Stop();
	tmr1_measure_pulse_lower_count = TMR1;	
	
	Goto_XY_LCD_Disp(PULSE_MEASURE_MSG_LINE_NUM, NUM_COL1);
	LCD_Disp_Str("Pulse Count");
	Goto_XY_LCD_Disp(PULSE_MEASURE_DISP_LINE_NUM, NUM_COL1);
    to_disp.unsigned_val.value_long = tmr1_measure_pulse_upper_count;    
	LCD_Disp_Num(DISP_HEX_DIGIT4, to_disp); 
    to_disp.unsigned_val.value_long = tmr1_measure_pulse_lower_count;    
	LCD_Disp_Num(DISP_HEX_DIGIT4, to_disp);	
    
    #ifdef TRACE 
      UART_Transmit_Str("Pulse Count : 0x");
      to_disp.unsigned_val.value_long = tmr1_measure_pulse_upper_count;   
	  UART_Transmit_Num(DISP_HEX_DIGIT4, to_disp);
      to_disp.unsigned_val.value_long = tmr1_measure_pulse_lower_count; 
      UART_Transmit_Num(DISP_HEX_DIGIT4, to_disp);
      UART_Transmit_Char('\r');
    #endif
	
	reset_sw_enable_flag = STATE_YES_IN_CHAR;
}
/*------------------------------------------------------------*-
FUNCTION NAME  : Write_Bit

DESCRIPTION     : write bit valve to data's bit, without affecting other bits of data .
                . 0 is the least bit pos and 7 is the most bit pos 

INPUT          : 

OUTPUT         : none

NOTE           : 
-*------------------------------------------------------------*/
void Write_Bit_in_Data(unsigned int *data, const unsigned int bit_pos, const unsigned int set_bit_val )
{
     if (set_bit_val == 1)
       {
          Set_Bit_in_Data(data, bit_pos);
          return;
       }
       Clear_Bit_in_Data(data, bit_pos ); 
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
