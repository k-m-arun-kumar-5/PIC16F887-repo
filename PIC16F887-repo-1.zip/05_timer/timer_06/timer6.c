/* ********************************************************************
FILE                   : timer6.c

PROGRAM DESCRIPTION    :  using timer1 and external clock for timer1, periodically flash LED1 OFF and LED2 ON for 5 sec
 and LED1 ON and LED2 OFF for 5 seconds and display LED status in LCD 
 with remaining time left in Led status. Using Gate, pause the time count and continue time count

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : fix issue of timer to get precise time using timer. Use PIC16F887-repo->05_timer->timer17.X->timer.c as base code to get precise time using timer.

NOTE                  : 
                       
CHANGE LOGS           : 

*****************************************************************************/   
#include <pic.h>
#define LED1_PIN                     RB0
#define LED2_PIN                     RB1
#define RS_PIN                       RE0
#define RW_PIN                       RE1
#define EN_PIN                       RE2
#define LCD_PORT                     PORTD
#define FIRST_LINE                   (0x80)
#define SECOND_LINE                  (0xC0)
#define OFF                         (0)
#define ON                          (1)  
#define TICK_MS  (50UL) // TIMER1 expires every 5ms
#define TIME_UNIT (1000UL)
#define OSC_PER_INST (4)
#define UPDATE_TIME (1000UL)/TICK_MS //UPDATE_TIME configured for 1 sec
#define _XTAL_FREQ   (4000000UL)
#define EXTERNAL_TIMER1_CLOCK_FREQ   (1000000UL)
#define INC (unsigned int)((unsigned long)(EXTERNAL_TIMER1_CLOCK_FREQ  * TICK_MS) / (unsigned long)(TIME_UNIT))
#define LED1_FSM_OFF    (1)
#define LED1_FSM_ON     (2)
#define LED1_ON_TIME    (5) // 5 sec on time
#define LED1_OFF_TIME   (5) // 5 sec off time                     
__CONFIG(0X2CE4);

void delay_time(unsigned int);
void pulse ();
void lcd_command (unsigned int);
void lcd_data(char);
void data_str(const char * );
void data_2digit(unsigned int);
void lcd_init();
void Led_Init(unsigned int);
void Goto_XY_LCD(unsigned int line,unsigned int col);
void LCD_Const_Disp();
unsigned int prescale_timer1 =  0x1, prescale_shift= 0,num_sec = 0;
unsigned int timer1_init = 0;
unsigned long int num_calls = 0;
unsigned int led1_fsm_state = LED1_FSM_OFF;
const char led_on_disp[] = " ON", led_off_disp[] = "OFF";
unsigned int cur_loc = FIRST_LINE;
void Led1_on();
void Led1_off();
void Prescale_Timer();     
void Timer1_Tick();
void Fsm_Led();
void Disp_LED_Status();
void Run_Timer1();
void main()
{
   TRISA = 0x00;
   PORTA = 0x00;
   TRISB = 0x00;
   PORTB = 0x00;
   TRISC = 0x00;
   PORTC = 0x00;
   TRISD = 0x00;
   PORTD = 0x00;
   TRISE = 0x00; 
   PORTE = 0x00;
   ANSEL=0X00;
   ANSELH=0X00;
  
   lcd_init();
   LCD_Const_Disp();
   Led_Init(LED1_FSM_OFF);   
       
   for(;;)
   {
     Timer1_Tick();
  } 
}
void Run_Timer1()
{
	/*EXTERNAL timer1 clock  with 1:1 prescale,Synchronize external clock input,
 Timer1 counts when gate is high and Timer1 counting is controlled by the Timer1 Gate function */
   T1CON =0xC3; 
   prescale_timer1 =  0x1;
   prescale_shift= 0;
   Prescale_Timer();
   timer1_init = 65536 - (INC/prescale_timer1); 
   TMR1H = timer1_init / 256;
   TMR1L = timer1_init % 256; 
}
void Timer1_Tick()
{
     while(TMR1IF == 0);
     TMR1IF = 0;
     timer1_init = 65536 - (INC/prescale_timer1); 
     TMR1H = timer1_init / 256;
     TMR1L = timer1_init % 256; 
     if(++num_calls >= UPDATE_TIME)
     {
        Fsm_Led();
        num_calls = 0;        
     }       
} 
/* Every 1 second Fsm_Led() is called*/                                                                                                                                                                                                                                                                                                                      
void Fsm_Led()
{
    switch(led1_fsm_state)
    {
      case LED1_FSM_OFF:
      ++num_sec;                       
      Led1_off();
      if(num_sec >= LED1_OFF_TIME )
      {
        num_sec = 0;
        led1_fsm_state =LED1_FSM_ON;
        Led1_on();               
      }
      break;
      case LED1_FSM_ON:
       ++num_sec;                  
      Led1_on();
      if(num_sec >= LED1_ON_TIME )
      {
        num_sec = 0;
        led1_fsm_state =LED1_FSM_OFF; 
        Led1_off();                 
      }
      break; 
    }               
}

void Prescale_Timer()
{
   if(T1CKPS0 == 1)
   {
      prescale_shift |= 0x01;           
   }
   if(T1CKPS1 == 1)
   {
     prescale_shift |= 0x02;
   }  
   prescale_timer1 = prescale_timer1  << prescale_shift;                                                      
}
void lcd_init()
{
    lcd_command(0x30);
    lcd_command(0x30);
    lcd_command(0x30);
    lcd_command(0x38);
    lcd_command(0x01);	
    lcd_command(0x0C);
    lcd_command(0x06);                                       
}     

void pulse()
{
        EN_PIN = ON;
        delay_time(100);
         EN_PIN = OFF;
        delay_time(100);
}
  void lcd_command (unsigned int cmd)
 {
         RW_PIN = OFF;
         RS_PIN = OFF; 
         LCD_PORT = cmd;
         pulse();
 }
 void lcd_data(char ch)
{
     RW_PIN = OFF;
     RS_PIN = ON;
     LCD_PORT =ch;
     pulse();
} 
void data_str(const char *char_ptr)
{ 
       while(*char_ptr)
       {
           lcd_data(*(char_ptr++));
       }
}
void data_2digit(unsigned int data_int)
{
    unsigned int tens_digit, unit_digit,num;
    char num_data[] ={'0','1','2','3','4','5','6','7','8','9'};  
	num = data_int % 100;
    unit_digit = data_int % 10;
    tens_digit = num / 10;
    lcd_data(num_data[tens_digit]);
   // lcd_data(tens_digit + 30); // num in ascii code   
    lcd_data(num_data[unit_digit]); 
   // lcd_data(unit_digit + 30); // num in ascii code                                 
}
void delay_time(unsigned int time_delay)
{
    while(time_delay--);
} 
void Goto_XY_LCD(unsigned int line,unsigned int col)
{
   if(line < 2 && col < 16 )
   {
    cur_loc = FIRST_LINE | line << 6;
    cur_loc = cur_loc + col;
    lcd_command(cur_loc);
   }
}
void LCD_Const_Disp()
{
  Goto_XY_LCD(0,0);
  data_str("LED1 ");
  Goto_XY_LCD(0,12);
  data_str("Secs");
  Goto_XY_LCD(1,0);
  data_str("LED2 "); 
  Goto_XY_LCD(1,12);
  data_str("Secs");        
}
void Led_Init(unsigned int led_init_state)
{
   num_sec = 0;
   led1_fsm_state = led_init_state;  
   switch(led_init_state)
   {
    case LED1_FSM_OFF:
      Led1_off();
      break;
     case LED1_FSM_ON:
      Led1_on();
      break;
   }  
}
void Led1_off()
{
   LED1_PIN =OFF;
   LED2_PIN =ON;
   Goto_XY_LCD(0,5);
   data_str(led_off_disp);
   Goto_XY_LCD(0,9);
   data_2digit(LED1_OFF_TIME - num_sec);
   Goto_XY_LCD(1,9);
   data_2digit(LED1_OFF_TIME - num_sec);
   Goto_XY_LCD(1,5);
   data_str(led_on_disp);
}
void Led1_on()
{
     LED1_PIN =ON;
      LED2_PIN =OFF;
      Goto_XY_LCD(0,5);
      data_str(led_on_disp);
      Goto_XY_LCD(0,9);
      data_2digit(LED1_ON_TIME - num_sec);
      Goto_XY_LCD(1,9);
      data_2digit(LED1_ON_TIME - num_sec);
      Goto_XY_LCD(1,5);
      data_str(led_off_disp); 
}
