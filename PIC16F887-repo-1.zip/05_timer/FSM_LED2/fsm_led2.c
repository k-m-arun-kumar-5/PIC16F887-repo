/* ********************************************************************
FILE                   : fsm_led2.c

PROGRAM DESCRIPTION    :  LED display pattern

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : fix issue of timer to get precise time using timer. Use PIC16F887-repo->05_timer->timer17.X->timer.c as base code to get precise time using timer.

NOTE                  : 
 
USED:              
                      Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                   HW : Tested OK in PIC development board by www.alselectro.com with LCD as JHD162A
		    Programmer: PICkit 3          
                       
CHANGE LOGS           : 

*****************************************************************************/ 
#include <pic.h>
#define LED_PIN                                              RA0
#define SW_LED_ON                                       RA1
#define SW_LED_OFF                                     RA2
#define SW_PRESSED                                    (1)
#define SW_NOT_PRESSED                         (0)

#define TICK_MSEC                                         (2UL)    // TIMER0 expires every 2ms
#define TIME_UNIT_SEC_TO_MSEC            (1000UL)
#define OSC_PER_INST                                     (4u)
#define UPDATE_TIME                                   (1000UL)/TICK_MSEC    //UPDATE_TIME for 1 sec
#define INC (unsigned int)   (((_XTAL_FREQ / (OSC_PER_INST * TIME_UNIT_SEC_TO_MSEC )) *  TICK_MSEC))

#define LED_FSM_ON                (1U)
#define LED_FSM_OFF               (2U)
#define  REQ_LED_ON_TIME          (10U)
#define  REQ_LED_OFF_TIME         (10U) 
#define _XTAL_FREQ            (4000000)
__CONFIG(0x2ce4);

void Led_Init(unsigned int);
void Led_On();
void Led_Off();
void Prescale_Timer0();     
void Timer0_Tick();
void Fsm_Led();
void Disp_LED_Status();
void Run_Timer0();
void  Startup_Led_On();
void  Startup_Led_Off();
unsigned int prescale_timer0 =  0x02, prescale_shift= 0, num_sec = 0,timer0_init_val= 0 ;
unsigned long int num_calls = 0;
unsigned int led_fsm_state = LED_FSM_ON;

void main()
{
	
   TRISA = 0x06;
   
   ANSEL=0X00;
   ANSELH=0X00;
   // 2 FOR TIMER 0 CYCLE REQ for sync 
   // timer0_init_val = 256 - (INC/prescale_timer0) + 2 ;
   //for _XTAL_FREQ = 4000000 and prescale_timer0 = 8
   timer0_init_val = 8;
   __delay_ms(300);
   Led_Init(LED_FSM_ON);
   Run_Timer0();
   
   for(;;)
   {
     Timer0_Tick();
  } 
}
void Run_Timer0()
{
   //T0IF = 0;
   T0CS  = 0; // Internal Clock
   PSA = 0 ;//PRESCALE SET for timer 0
   PS0 = 0; //prescaler 1:8 
   PS1 = 1;
   PS2 = 0;
  
   Prescale_Timer0();
   TMR0= timer0_init_val;  
  
}
void Timer0_Tick()
{
     while(T0IF == 0);   
	 // 2 FOR TIMER 0 CYCLE REQ for sync 
    // TMR0= 256 - (INC/prescale_timer0) + 2 ;
	// 
	 T0IF = 0;
	 TMR0 = timer0_init_val; 
     if(++num_calls >= UPDATE_TIME)
     {
        Fsm_Led();
        num_calls = 0;        
     } 
	
} 
/* Every 1 second Fsm_Led() is called*/                                                                                                                                                                                                                                                                                                                      
void Fsm_Led()
{
    switch(led_fsm_state)
    {
      case LED_FSM_ON:
      ++num_sec;                       
     if(SW_LED_OFF == SW_PRESSED )  
      {
		  __delay_ms(50);
		  if(SW_LED_OFF ==SW_PRESSED ) 
		  {
             while(SW_LED_OFF ==SW_PRESSED);
             Startup_Led_Off();         
             break;
		  }
     }
      if(num_sec >=REQ_LED_ON_TIME  )
      {
            Startup_Led_Off();   
            break;		
      }
	  Led_On(); 
      break;
      case LED_FSM_OFF:
       ++num_sec;                  
     if(SW_LED_ON ==SW_PRESSED )  
     {
		 __delay_ms(50);
		 if(SW_LED_ON ==SW_PRESSED)
		 {
            while(SW_LED_ON ==SW_PRESSED);
            Startup_Led_On();
            break;
		 }
     }    
      if(num_sec >= REQ_LED_OFF_TIME )
      {
        Startup_Led_On();
     	break;	 
      }
	 Led_Off();    
        break; 
    }               
}
void  Startup_Led_Off()
{
         num_sec = 0;
         led_fsm_state =LED_FSM_OFF;	
         Led_Off();   
}
void  Startup_Led_On()
{
         num_sec = 0;
         led_fsm_state =LED_FSM_ON;	
         Led_On();   
}
void Prescale_Timer0()
{ 
   prescale_timer0 =  0x02;
   prescale_shift= 0;
	
   if(PS0 == 1)
   {
      prescale_shift |= 0x01;           
   }
   if(PS1 == 1)
   {
     prescale_shift |= 0x02;
   }  
   if(PS2 == 1)
   {
     prescale_shift |= 0x04;
   } 
   prescale_timer0 = prescale_timer0  << prescale_shift;
                                                     
}

 void Led_Off()
{
     LED_PIN  = 0;
}

void Led_On()
{
    LED_PIN =1;
}
void Led_Init(unsigned int init_led_fsm)
{
    switch(init_led_fsm)
   {
        case LED_FSM_ON:
        case LED_FSM_OFF:
          led_fsm_state = init_led_fsm;
          num_sec = 0;
          break; 
    } 
}
