/* ********************************************************************
FILE                   : timer1.c

PROGRAM DESCRIPTION    :  using timer0, periodically flash LED1 OFF and LED2 ON for 2 sec
 and LED1 ON and LED2 OFF for 2 seconds 

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : fix issue of timer to get precise time using timer. Use PIC16F887-repo->05_timer->timer17.X->timer.c as base code to get precise time using timer.

NOTE                  : 
 
USED:              
                      Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
                      IDE :  MPLAB X IDE v4.01 with MPLAB XC8 C Compiler.      			 
                   CADD: Simulated in Proteus 8.0 Professional                         
                       
CHANGE LOGS           : 

*****************************************************************************/ 
#include <pic.h>
#define LED1_PIN RA0
#define LED2_PIN RA1
#define TICK_MS  (2UL) // TIMER0 expires every 2ms
#define TIME_UNIT (1000UL)
#define OSC_PER_INST (4)

#define UPDATE_TIME (1000UL)/TICK_MS //UPDATE_TIME for 1 sec
#define _XTAL_FREQ   (4000000UL)
#define INC (unsigned int)((unsigned long)(_XTAL_FREQ * TICK_MS) / (unsigned long)(OSC_PER_INST * TIME_UNIT))
#define LED1_FSM_OFF    1
#define LED1_FSM_ON     2
#define LED1_ON_TIME    2 // 2 sec on time
#define LED1_OFF_TIME   2 // 2 sec off time                     
__CONFIG(0X2CE4);
unsigned int prescale_timer0 =  0x2, prescale_shift= 0,num_sec = 0;
unsigned long int num_calls = 0;
unsigned int led1_fsm_state = LED1_FSM_OFF;
void Prescale_Timer();     
void Timer0_Tick();
void Fsm_Led();
void Run_Timer0();
void main()
{
   TRISA = 0x00;
   PORTA = 0x00;
   TRISB = 0x00;
   PORTB = 0x00;
   TRISC = 0x00;
   PORTC = 0x00;
   TRISD = 0x00;
   PORTD = 0x00;
   
   ANSEL=0X00;
   ANSELH=0X00;
   
   for(;;)
   {
     Timer0_Tick();
  } 
}
void Run_Timer0()
{
   T0CS  = 0; // Internal Clock
   PSA = 0 ;//PRESCALE SET for timer 0
   PS0 = 0; //prescaler 1:8 
   PS1 = 1;
   PS2 = 0;
   prescale_timer0 =  0x02;
   prescale_shift= 0;
   Prescale_Timer();
   TMR0= 256 - (INC/prescale_timer0); 
   PORTB = 256 - (INC/prescale_timer0);
}
void Timer0_Tick()
{
     while(T0IF == 0);
     T0IF = 0;
     TMR0= 256 - (INC/prescale_timer0);
     if(++num_calls >= UPDATE_TIME)
     {
        Fsm_Led();
        num_calls = 0;        
     }       
} 
/* Every 1 second Fsm_Led() is called*/                                                                                                                                                                                                                                                                                                                      
void Fsm_Led()
{
    switch(led1_fsm_state)
    {
      case LED1_FSM_OFF:                   
      LED1_PIN =0;
      LED2_PIN =1;
      if(++num_sec >= LED1_OFF_TIME )
      {
        num_sec = 0;
        led1_fsm_state =LED1_FSM_ON; 
      }
      break;
      case LED1_FSM_ON:                   
      LED1_PIN =1;
      LED2_PIN =0;
      if(++num_sec >= LED1_ON_TIME )
      {
        num_sec = 0;
        led1_fsm_state =LED1_FSM_OFF; 
      }
      break; 
    }              
}

void Prescale_Timer()
{
   if(PS0 == 1)
   {
      prescale_shift |= 0x01;           
   }
   if(PS1 == 1)
   {
     prescale_shift |= 0x02;
   }  
   if(PS2 == 1)
   {
     prescale_shift |= 0x04;
   } 
   prescale_timer0 = prescale_timer0  << prescale_shift;
   PORTC = prescale_timer0 % 256;  
   PORTD = (prescale_timer0 /256)% 256;                                                       
}                                 
