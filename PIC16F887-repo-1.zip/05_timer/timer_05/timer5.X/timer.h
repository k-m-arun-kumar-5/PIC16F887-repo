/**************************************************************************
   FILE          :    timer.h
 
   PURPOSE       :    timer library Header
 
   AUTHOR        :     K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _TIMER_H
 #define _TIMER_H
 
/* ---------------------- macro defination ------------------------------------------------ */  
#define TMR1_STOP_STATE                    (0xFF)
 
#define TMR1_INVALID_SERVICE         (4)
#define TMR1_TIMER_INTP_SERVICE      (3)
#define TMR1_TIMER_POLLING_SERVICE   (2)
#define TMR1_COUNTER_INTP_SERVICE    (1)
#define TMR1_COUNTER_POLLING_SERVICE (0)
 
#define	 TMR1_GATE_CTRL_DISABLE       (0)     //Timer1 Gate control disable
#define  TMR1_GATE_CTRL_ACTIVE_HIGH   (3)     // Timer1 Gate control enabled, as Timer1 counting is controlled by the Timer1 Gate function and Timer1 gate is active-high (Timer1 counts when gate is high and timer 1 pauses when gate is low)
#define  TMR1_GATE_CTRL_ACTIVE_LOW    (1)     //Timer1 Gate control enabled, and Timer1 gate is active-high (Timer1 counts when gate is high and timer 1 pauses when gate is low)

#define   TMR1_CLK_SRC_INTR_OSC          (0)     // Timer1 Clock Source as Internal clock (FOSC/4)
#define   TMR1_CLK_SRC_EXTR_CLK_NO_SYNC  (3)     // Timer1 Clock Source as External clock from T1CKI pin (on the rising edge) and dont Synchronize external clock input     
#define   TMR1_CLK_SRC_EXTR_CLK_SYNC     (1)     // Timer1 Clock Source as External clock from T1CKI pin (on the rising edge) and Synchronize external clock input 
   

#define  TMR1_LP_OSC_ENABLE   (1)     // LP(low power) oscillator is enabled for Timer1 clock
#define  TMR1_LP_OSC_DISABLE   (0)    // LP(low power) oscillator is off for Timer1 clock
 
#define  TMR1_INPUT_CLK_PRESCALE_8     (3)    //Timer1 Input Clock 1:8 Prescale Value from Timer1 Clock Source
#define  TMR1_INPUT_CLK_PRESCALE_4     (2)    //Timer1 Input Clock 1:4 Prescale Value from Timer1 Clock Source
#define  TMR1_INPUT_CLK_PRESCALE_2     (1)    //Timer1 Input Clock 1:2 Prescale Value from Timer1 Clock Source
#define  TMR1_INPUT_CLK_PRESCALE_1     (0)    //Timer1 Input Clock 1:1 Prescale Value from Timer1 Clock Source

/* ---------------------- data type defination --------------------------------------------- */
typedef struct {
	unsigned long int timer1_req_time_delay_in_milli_sec;
    unsigned int timer1_service_type: 3;
	unsigned int timer1_gate_ctrl_type: 2;
	unsigned int timer1_input_clk_type: 2;
	unsigned int timer1_lp_osc_enable_ctrl: 1;
	unsigned int timer1_input_clk_prescaler: 2;    	
} tmr1_data_types;
	
 /* -------------------- public variable declaration --------------------------------------- */
 
extern unsigned int timer1_prescale, timer1_prescale_shift, timer1_elapsed_num_update;
extern unsigned long int  timer1_init_val, timer1_elapsed_num_overflow_1_update, timer1_1_update, timer1_max_num_overflow, timer1_req_time_max_update;
extern unsigned int  timer1_cur_run_state, timer1_last_run_state_before_stop;
extern unsigned int timer1_cur_service_type;
extern volatile unsigned long measure_pulse_lower_count, measure_pulse_upper_count;
extern tmr1_data_types  tmr1_datas[];

 /* -------------------- public prototype declaration --------------------------------------- */
 
void Timer1_Run(const unsigned int set_timer1_run_state, const unsigned long int set_req_time_delay_in_milli_sec );
void  Timer1_Conf_Parameters(unsigned int set_timer1_run_state, unsigned long int set_timer1_req_time_delay_in_milli_sec );
void Timer1_Stop();
void Timer1_Prescale();
void Timer1_Load_Init_Val_Calc(const unsigned long int set_req_time_delay_in_milli_sec);

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
