/**************************************************************************
   FILE          :    appl_conf.h
 
   PURPOSE       :   main application configuration Header
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _APPL_CONF_H
 #define _APPL_CONF_H 
 
/*------------------------------- LCD disp conf ------------------------------------------*/


/* -------------------------------Timer state conf ---------------------------------------*/

#define TMR1_GATE_WITH_LCD_STATE           (0)

/* ------------------------------- application conf --------------------------------------*/

#define LED1_ON_TIME_IN_SEC         (5) // 5 sec on time
#define LED1_OFF_TIME_IN_SEC        (5) // 5 sec off time  

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
