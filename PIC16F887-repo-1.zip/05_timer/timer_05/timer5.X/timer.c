/**************************************************************************
   FILE          :    timer.c
 
   PURPOSE       :   Timer Library
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :  fix issue of timer to get precise time using timer. Use PIC16F887-repo->05_timer->timer17.X->timer.c as base code to get precise time using timer. 
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #include "main.h"
 #include "timer.h"
 #include "io_conf.h"
#include "uart.h"

unsigned int timer1_prescale = 1, timer1_prescale_shift= 0, timer1_elapsed_num_update = 0 ;
unsigned long int  timer1_init_val = 0, timer1_elapsed_num_overflow_1_update = 0, timer1_1_update = 0, timer1_max_num_overflow =0, timer1_req_time_max_update = 0, timer1_req_time_delay_in_milli_sec;
unsigned int  timer1_cur_run_state= TMR1_STOP_STATE, timer1_last_run_state_before_stop = TMR1_STOP_STATE, timer1_cur_service_type;
tmr1_data_types  tmr1_datas[1];
volatile unsigned long measure_pulse_lower_count, measure_pulse_upper_count;

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void  Timer1_Conf_Parameters(unsigned int set_timer1_run_state, unsigned long int set_timer1_req_time_delay_in_milli_sec )
{
	tmr1_datas[set_timer1_run_state ].timer1_req_time_delay_in_milli_sec = set_timer1_req_time_delay_in_milli_sec;
	tmr1_datas[set_timer1_run_state ].timer1_service_type = TMR1_TIMER_POLLING_SERVICE;
	tmr1_datas[set_timer1_run_state ].timer1_gate_ctrl_type = TMR1_GATE_CTRL_ACTIVE_LOW;
	tmr1_datas[set_timer1_run_state ].timer1_input_clk_type = TMR1_CLK_SRC_INTR_OSC;
	tmr1_datas[set_timer1_run_state ].timer1_lp_osc_enable_ctrl = TMR1_LP_OSC_DISABLE;
	tmr1_datas[set_timer1_run_state].timer1_input_clk_prescaler = TMR1_INPUT_CLK_PRESCALE_8; 
}

 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Timer1_Run(const unsigned int set_timer1_run_state, const unsigned long int set_req_time_delay_in_milli_sec )
{
      Timer1_Stop();
	  
	  Timer1_Conf_Parameters(set_timer1_run_state, set_req_time_delay_in_milli_sec);
	  
      if(tmr1_datas[set_timer1_run_state ].timer1_service_type & 0x04)
	  {
		  //set_timer1_service  = TMR1_INVALID_SERVICE
		  return;
	  }		  
	  timer1_cur_run_state = timer1_last_run_state_before_stop = set_timer1_run_state;
       	  
	  T1CON =  (tmr1_datas[set_timer1_run_state ].timer1_gate_ctrl_type << 6)  | tmr1_datas[set_timer1_run_state ].timer1_input_clk_type << 1 | \
     	(tmr1_datas[set_timer1_run_state ].timer1_lp_osc_enable_ctrl << 3) |  (tmr1_datas[set_timer1_run_state ].timer1_input_clk_prescaler <<4) ; 
	  Timer1_Prescale(); 
	  
	  #ifdef TRACE
	     to_disp.unsigned_val.val_in_bytes.value_byte[0] = T1CON;
         UART_Transmit_Str("T1CON config : 0x");
         UART_Transmit_Num(DISP_HEX_DIGIT2, to_disp );
	     UART_Transmit_Char('\r');                                  	  
      #endif
	  
	   timer1_cur_service_type = tmr1_datas[set_timer1_run_state ].timer1_service_type;
	   
	   if(timer1_cur_service_type & 0x02)
	   {
		   //timer1 is in timer mode
		   if(((tmr1_datas[timer1_cur_run_state ].timer1_input_clk_type & 1) || (T1CON & 0x02)) == 0x00)
		   {
	            //Timer1 Clock Source is internal clock
				
				#ifdef TRACE
	              UART_Transmit_Str("tmr1 in timer mode \r"); 
	            #endif
				
				Timer1_Load_Init_Val_Calc(set_req_time_delay_in_milli_sec); 	
	       }
           else
		   {
			  #ifdef TRACE_ERROR
				   UART_Transmit_Str("ERR: tmr1 is timer but clk source is not internal \r");
			  #endif
			  
			  timer1_cur_service_type = TMR1_INVALID_SERVICE;
			  return;
		   }	
	   }
	   else
	   {
		   //timer1 is in counter mode
		   if((tmr1_datas[set_timer1_run_state ].timer1_input_clk_type & 0x01) & (T1CON & 0x02)) 
		   {
				//Timer1 Clock Source is external clock  
				if(tmr1_datas[set_timer1_run_state ].timer1_lp_osc_enable_ctrl == TMR1_LP_OSC_ENABLE)
				{	
				    //LP oscillator is enabled for Timer1 clock	
			         TMR1 = measure_pulse_lower_count;
					 
			    	#ifdef TRACE
	                   to_disp.unsigned_val.val_in_bytes.value_byte[0] = TMR1;
	                   UART_Transmit_Str("tmr1 in counter mode, TMR1 = 0x"); 
					   UART_Transmit_Num(DISP_HEX_DIGIT4, to_disp);
	                   UART_Transmit_Char('\r');  
	                #endif
				}
				else
				{
					#ifdef TRACE_ERROR
				      UART_Transmit_Str("ERR: tmr1 is counter but LP osc is disabled \r");
				    #endif
					
					timer1_cur_service_type = TMR1_INVALID_SERVICE;
				    return;
				}
		   }
		   else
		   {
				#ifdef TRACE_ERROR
				   UART_Transmit_Str("ERR: tmr1 is counter but clk source is not external \r");
				#endif
				
				timer1_cur_service_type = TMR1_INVALID_SERVICE;
				return;
		   }
	   }
	   
	      if(timer1_cur_service_type & 0x01)
	      {
		      //timer1 service is interrupt
		       TMR1IF = 0;   		 
               PIE1bits.TMR1IE = 1; //Enables the Timer1 overflow interrupt 
		       INTCONbits.PEIE = 1;  //Enables all unmasked peripherals interrupts   
               INTCONbits.GIE = 1;  //Enables all unmasked interrupts 
	  
               #ifdef TRACE
	              UART_Transmit_Str("TMR1IE, PEIE & GIE are enabled, interrupt service \r"); 
	           #endif		   
	      }
	      else
	      {
		     //timer1 service is polling and disable the Timer1 overflow interrupt 
		     PIE1bits.TMR1IE = 0; 
			
		     #ifdef TRACE
	            UART_Transmit_Str("TMR1IE is disabled, polling service \r"); 
	         #endif
	      }       
	  
	  TMR1IF = 0;
      T1CONbits.TMR1ON = 1 ; //Enables Timer1 and timer1 runs
}   
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Timer1_Stop()
{
	if(timer1_cur_run_state != TMR1_STOP_STATE)
	{
	   T1CONbits.TMR1ON = 0 ; //stops Timer1.
	   PIE1bits.TMR1IE = 0; //disable the Timer1 overflow interrupt 
	   TMR1IF = 0;
	   timer1_cur_run_state = TMR1_STOP_STATE;
	   timer1_cur_service_type = TMR1_INVALID_SERVICE;
	   
	   //Commited due to stack overflow
	  /* #ifdef TRACE 
	     UART_Transmit_Str("Timer1 is stopped \r");
	   #endif */	 
	}   
}	
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Timer1_Prescale()
{
	unsigned int i;
	
   timer1_prescale = 1;
   timer1_prescale_shift= 0;
   if(T1CKPS0 == 1)
   {
      timer1_prescale_shift |= 0x01;           
   }
   if(T1CKPS1 == 1)
   {
     timer1_prescale_shift |= 0x02;
   }
   for(i = 1; i <= timer1_prescale_shift; ++i)
   {
      timer1_prescale *= 2;
   }  
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : http://picguides.com/beginner/timers.php
                 yet to calculate timer1_adjust_init_val to include timer1 overflow instructions executed delay 
				 from TMR1IF == 1 till instruction to reload TMR1 register to get almost precise time delay

Func ID        : 21   
-*------------------------------------------------------------*/
void Timer1_Load_Init_Val_Calc(const unsigned long int set_req_time_delay_in_milli_sec)
{
	unsigned long int inc_timer1;
	unsigned int timer1_adjust_init_val;
	unsigned long int set_timer1_tick_in_milli_sec = TIMER1_TICK_IN_MILLI_SEC;
	unsigned long int set_timer1_req_time_1_update_in_milli_sec = TIMER1_REQ_TIME_1_UPDATE_REACHED_IN_MILLI_SEC;
	unsigned long int timer1_remainder; 
	
/*	#ifdef TRACE
      to_disp.unsigned_val.val_in_bytes.value_byte[0] = timer1_prescale;
       UART_Transmit_Str("Timer1 Prescaler : ");
       UART_Transmit_Num(DISP_UNSIGN_NUM_DIGIT2, to_disp );
	   UART_Transmit_Char('\r');		
    #endif */
	
      timer1_elapsed_num_overflow_1_update = 0;
	  timer1_1_update = set_timer1_req_time_1_update_in_milli_sec /set_timer1_tick_in_milli_sec;
      timer1_remainder = set_req_time_delay_in_milli_sec % set_timer1_req_time_1_update_in_milli_sec;	  
	  if( timer1_remainder == 0)
	  {
		  //set_req_time_delay_in_milli_sec is in multiples of  set_timer1_req_time_1_update_in_milli_sec
		  timer1_req_time_delay_in_milli_sec = set_req_time_delay_in_milli_sec;		  	 
	  }
	  else
	  {
		  //set_req_time_delay_in_milli_sec is not in multiples of  set_timer1_req_time_1_update_in_milli_sec
		  #if TIMER1_SET_TIME_DELAY_IN_MULTIPLE == TIMER1_PRESET_TIME_DELAY_IN_MULTIPLE
		    //timer1_req_time_delay_in_milli_sec is previous valid req_time_delay_in_milli_sec, which is multiple of set_timer1_req_time_1_update_in_milli_sec
		     timer1_req_time_delay_in_milli_sec = set_req_time_delay_in_milli_sec - timer1_remainder;
		  #else //TIMER1_SET_TIME_DELAY_IN_MULTIPLE == TIMER1_POSTSET_TIME_DELAY_IN_MULTIPLE
		     //timer1_req_time_delay_in_milli_sec is next valid req_time_delay_in_milli_sec, which is multiple of set_timer1_req_time_1_update_in_milli_sec
             timer1_req_time_delay_in_milli_sec = set_req_time_delay_in_milli_sec - timer1_reminder + set_timer1_req_time_1_update_in_milli_sec ;	
          #endif	
	  }
	  timer1_req_time_max_update = timer1_req_time_delay_in_milli_sec / set_timer1_req_time_1_update_in_milli_sec;
	  
	  #ifdef TRACE
	     to_disp.unsigned_val.value_long = timer1_req_time_delay_in_milli_sec;
	     UART_Transmit_Str("Timer1 start running set for expiry : ");
         UART_Transmit_Num(DISP_UNSIGN_NUM_DIGIT5, to_disp ); 
	     UART_Transmit_Str(" millisecs \r"); 
      #endif		  
	
    /* for timer1, TMR1 = (65536 - ((timerPeriod_in_sec * Fosc_in_Hertz)/(4*prescaler)) + 2),  where 2 = sync time req is 2 Timer Clock cycle */
    // inc_timer1  =      (unsigned long)((unsigned long)(_XTAL_FREQ * set_timer1_tick_in_milli_sec ) / (unsigned long)(OSC_PER_INST * TIME_UNIT_1_SEC_IN_MILLI_SEC  )) 
	inc_timer1 = (_XTAL_FREQ / (OSC_PER_INST * TIME_UNIT_1_SEC_IN_MILLI_SEC)) * set_timer1_tick_in_milli_sec; // for 1000ul = 4MHz / (4 * 1000), when _XTAL_FREQ  = 4MHz  
    timer1_init_val = (65535 - (inc_timer1/timer1_prescale)) + 1 + 2; 
    TMR1 = timer1_init_val;
     
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
