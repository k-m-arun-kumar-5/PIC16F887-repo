/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : using timer1, periodically flash LED1 OFF and LED2 ON for 5 sec
 and LED1 ON and LED2 OFF for 5 seconds and display LED status in LCD 
 with remaining time left in Led status. Using Gate, pause the time count and continue time count                      									 
	 
AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : fix issue of timer to get precise time using timer. Use PIC_codes_16f887->05_timer->timer17.X->timer.c as base code to get precise time using timer. 

NOTE                  :                   								
                        
                       
CHANGE LOGS           : 

*****************************************************************************/
 // PIC16F887 Configuration Bit Settings
// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.
// 'C' source line config statements

// CONFIG1
//#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config FOSC = HS        // Oscillator Selection bits (HS oscillator: High-speed crystal/resonator on RA6/OSC2/CLKOUT and RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = ON       // Power-up Timer Enable bit (PWRT enabled)
#pragma config MCLRE = ON       // RE3/MCLR pin function select bit (RE3/MCLR pin function is MCLR)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = ON        // Internal External Switchover bit (Internal/External Switchover mode is enabled)
#pragma config FCMEN = ON       // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is enabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off) 

#include "main.h"
#include "port.h"
#include "io_conf.h"
#include "appl_conf.h"
#include "lcd.h"
#include "timer.h"
#include "uart.h"

#define LED1_FSM_OFF         (1)
#define LED1_FSM_ON          (2)

value_types to_disp;
unsigned int led1_fsm_state = LED1_FSM_OFF, num_sec;
const char led_on_disp[] = " ON", led_off_disp[] = "OFF";

void Led1_on();
void Led1_off();
void Timer1_Tick();
void Fsm_Led();
void LCD_Const_Disp();
void Led_Init(unsigned int led_init_state);
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void main()
{
	TRISAbits.TRISA0 = 0;
	TRISAbits.TRISA1 = 0;
	
	ANSEL=0X00;
    ANSELH=0X00;

    UART_Init();
    LCD_Init();
    LCD_Const_Disp();
    Led_Init(LED1_FSM_OFF);
    Timer1_Run(TMR1_GATE_WITH_LCD_STATE, TIMER1_REQ_TIME_1_UPDATE_REACHED_IN_MILLI_SEC );
    while(1)
   {
	     while(TMR1IF == 0);
         TMR1IF = 0;
		 if(timer1_cur_service_type & 0x02)
	     {
			 //timer1 is in timer mode
		 	  TMR1 = timer1_init_val;             
		      //timer1 overflow for every TIMER1_TICK_IN_MILLI_SEC ie timer1_elapsed_num_overflow_1_update var is incremented for every TIMER1_TICK_IN_MILLI_SEC elapsed
              if(++timer1_elapsed_num_overflow_1_update >= timer1_1_update) 
              {
			    if(++timer1_elapsed_num_update >= timer1_req_time_max_update)
			    {
				    Fsm_Led();  
					timer1_elapsed_num_update = 0;                   
			    }
                timer1_elapsed_num_overflow_1_update = 0;  			  
             }
		 }
		 else
		 {
			 //timer1 is in counter mode
			 ++measure_pulse_upper_count;
			 
            /*  #ifdef TRACE
	                UART_Transmit_Str("Timer1 overflow : 0x");
					UART_Transmit_Num(DISP_FLAG_HEX_DIGIT4, measure_pulse_upper_count);
                    UART_Transmit_Num(DISP_FLAG_HEX_DIGIT4, TMR1);
                    UART_Transmit_Char('\r');
              #endif */			 
		 }        
   } 
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
/* Every 1 second Fsm_Led() is called*/                                                                                                                                                                                                                                                                                                                      
void Fsm_Led()
{
	switch(led1_fsm_state)
    {
      case LED1_FSM_OFF:
      ++num_sec;                       
     
      if(num_sec >=LED1_OFF_TIME_IN_SEC  )
      {
        num_sec = 0;
        led1_fsm_state =LED1_FSM_ON;
        Led1_on(); 
        break;		
      }
	   Led1_off();
      break;
      case LED1_FSM_ON:
       ++num_sec;                  
    
      if(num_sec >= LED1_ON_TIME_IN_SEC )
      {
        num_sec = 0;
        led1_fsm_state =LED1_FSM_OFF; 
        Led1_off();
        break;		
      }
	   Led1_on();
      break; 
    }     	
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void LCD_Const_Disp()
{
  Goto_XY_LCD_Disp(1,1);
  LCD_Disp_Str("LED1 ");
  Goto_XY_LCD_Disp(1,13);
  LCD_Disp_Str("Secs");
  Goto_XY_LCD_Disp(2,1);
  LCD_Disp_Str("LED2 "); 
  Goto_XY_LCD_Disp(2,13);
  LCD_Disp_Str("Secs");        
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void Led_Init(unsigned int led_init_state)
{
   led1_fsm_state = led_init_state;  
   switch(led_init_state)
   {
    case LED1_FSM_OFF:
      Led1_off();
      break;
     case LED1_FSM_ON:
      Led1_on();
      break;
   }  
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void Led1_off()
{
   LED1_PIN = LED_OFF;
   LED2_PIN = LED_ON;
   Goto_XY_LCD_Disp(1,6);
   LCD_Disp_Str(led_off_disp);
   Goto_XY_LCD_Disp(1,10);
   to_disp.unsigned_val.val_in_bytes.value_byte[0] = LED1_OFF_TIME_IN_SEC - num_sec;
   LCD_Disp_Num(DISP_UNSIGN_NUM_DIGIT2, to_disp );
   Goto_XY_LCD_Disp(2,10);
   to_disp.unsigned_val.val_in_bytes.value_byte[0] = LED1_OFF_TIME_IN_SEC - num_sec;
   LCD_Disp_Num(DISP_UNSIGN_NUM_DIGIT2, to_disp );
   Goto_XY_LCD_Disp(2,6);
   LCD_Disp_Str(led_on_disp);
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void Led1_on()
{
      LED1_PIN =LED_ON;
      LED2_PIN =LED_OFF;
      Goto_XY_LCD_Disp(1,6);
      LCD_Disp_Str(led_on_disp);
      Goto_XY_LCD_Disp(1,10);
      to_disp.unsigned_val.val_in_bytes.value_byte[0] = LED1_ON_TIME_IN_SEC - num_sec;
      LCD_Disp_Num(DISP_UNSIGN_NUM_DIGIT2, to_disp );
      Goto_XY_LCD_Disp(2,10);
      to_disp.unsigned_val.val_in_bytes.value_byte[0] = LED1_ON_TIME_IN_SEC - num_sec;
      LCD_Disp_Num(DISP_UNSIGN_NUM_DIGIT2, to_disp ); 
      Goto_XY_LCD_Disp(2,6);
      LCD_Disp_Str(led_off_disp); 
}
/*------------------------------------------------------------*-
FUNCTION NAME  : Write_Bit

DESCRIPTION     : write bit valve to data's bit, without affecting other bits of data .
                . 0 is the least bit pos and 7 is the most bit pos 

INPUT          : 

OUTPUT         : none

NOTE           : 
-*------------------------------------------------------------*/
void Write_Bit_in_Data(unsigned int *data, const unsigned int bit_pos, const unsigned int set_bit_val )
{
     if (set_bit_val == 1)
       {
          Set_Bit_in_Data(data, bit_pos);
          return;
       }
       Clear_Bit_in_Data(data, bit_pos ); 
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
