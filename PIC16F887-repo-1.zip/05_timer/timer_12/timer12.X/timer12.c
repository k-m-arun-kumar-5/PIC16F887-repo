/* ********************************************************************
FILE                   : timer12.c

PROGRAM DESCRIPTION    :  START_SW is used to start measuring time. STOP_SW is used to stop measuring time and display time interval between stop and start switch operation

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : fix issue of timer to get precise time using timer. Use PIC16F887-repo->05_timer->timer17.X->timer.c as base code to get precise time using timer.

NOTE                  : 
                       
CHANGE LOGS           : 

*****************************************************************************/  

#define HI_TECH_COMPILER
#ifdef HI_TECH_COMPILER
  #include <pic.h>
  __CONFIG(0X2CE4);
#else // XC8 compiler
  #include <xc.h>
#endif
#include "string.h"
#define START_SW                                 RD3
#define STOP_SW                                  RD4

#define RS_PIN                                	RD0
#define RW_PIN                                 	RD1
#define EN_PIN                                	RD2
#define LCD_PORT                               PORTC

#define KEY_PRESSED                              (1) 
#define KEY_NOT_PRESSED                          (0) 
 
 #define DISP_FLAG_NUM_DIGIT1                   (1u)
#define DISP_FLAG_NUM_DIGIT2                   (2u)
#define DISP_FLAG_NUM_DIGIT3                   (3u)
#define DISP_FLAG_NUM_DIGIT4                   (4u)
#define DISP_FLAG_NUM_DIGIT5                   (5u)
#define DISP_FLAG_HEX_DIGIT1                   (6u)
#define DISP_FLAG_HEX_DIGIT2                   (7u)
#define DISP_FLAG_HEX_DIGIT3                   (8u)
#define DISP_FLAG_HEX_DIGIT4                   (9u) 

 /* num cols = num of chars in a line */
#define MAX_COUNT_DELAY_TIME_LCDPULSE     (100U)
#define MAX_AVAIL_NUM_COLS                    (20u)
#define CONFIGURE_MAX_NUM_LINES               (4u)
#define MAX_AVAIL_NUM_LINES                   (4u) 
#define MAX_AVAIL_NUM_CHARS_IN_LCD        (MAX_AVAIL_NUM_COLS * MAX_AVAIL_NUM_LINES) 
#define CONFIGURE_MAX_NUM_COLS             (MAX_AVAIL_NUM_COLS)
#define CONFIGURE_MAX_NUM_CHARS_IN_LCD    (CONFIGURE_MAX_NUM_LINES * CONFIGURE_MAX_NUM_COLS ) 
#define MAX_NUM_CHARS_INPUT_DATA          (MAX_AVAIL_NUM_COLS)  

/* for 20 * 4 LCD disp */                             
#define BEGIN_LOC_LINE1                      (0X80u)
#define BEGIN_LOC_LINE2                      (0xC0u)
#define BEGIN_LOC_LINE3                      (0x94u) 
#define BEGIN_LOC_LINE4                      (0xD4u)
#define END_LOC_LINE1                        (0x93u)
#define END_LOC_LINE2                        (0xD3u)
#define END_LOC_LINE3                        (0xA7u) 
#define END_LOC_LINE4                        (0xE7u)

#define INVALID_DATA               (0u)
#define ALL_LINES                  (0u)
#define NUM_LINE1                  (1u)
#define NUM_LINE2                  (2u)
#define NUM_LINE3                  (3u)
#define NUM_LINE4                  (4u)
#define NUM_COL1                   (1u)

#define TIMER1_TICK_MSEC                (100UL) // TIMER1 expires every 100ms
#define  TIME_UNIT_SEC_TO_MSEC          (1000UL)
#define OSC_PER_INST                  (4)
#define _XTAL_FREQ                    (4000000UL)
//#define INC1 (unsigned int)((unsigned long)(_XTAL_FREQ * TIMER1_TICK_MSEC) / (unsigned long)(OSC_PER_INST * TIME_UNIT_SEC_TO_MSEC))
#define INC1                               (55535UL)
#define MEASURE_TIME_PERIOD                  (500UL) 
#define MEASURE_TIME_FACTOR_PER_SEC          (1000UL/MEASURE_TIME_PERIOD)
//UPDATE_TIME1_NO_KEY_PRESS configured for 500 msec
#define UPDATE_TIME1_MEASURE_TIME           (MEASURE_TIME_PERIOD/TIMER1_TICK_MSEC)

#define STATE_YES     'y'
#define STATE_NO      'n' 

#define MAX_LONG_PRESS_COUNT           (65535UL)

#define OPER_MEASURE_LINE_NUM              NUM_LINE1
#define MEASURED_TIME_LINE_NUM             NUM_LINE2
#define MEASURING_LINE_NUM                 NUM_LINE3 

#define TMR1_OFF_STATE                    (0)
#define TMR1_MEASURE_TIME                 (1U)

void Run_Timer1(const unsigned int );
void Stop_Timer1();
void Prescale_Timer1_Calc();
void Update_Measure_Time_Count();
void Measure_Time();
void Init_Const_Data();
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num);

void Delay_Time_ByCount(unsigned int Delay_Time_Count_count);
void LCD_Pulse();
void Write_LCD_Command (const unsigned int lcd_command);
void Write_LCD_Data(const char lcd_disp_ch);

void Data_Str_Disp_LCD(const char *lcd_disp_str);
void Data_Num_Disp_LCD(const unsigned int lcd_datanum_disp_format, const unsigned long lcd_disp_data_int);
void LCD_Init();
unsigned int prescale_timer1 =  0x01, prescale_shift_timer1= 00, num_sec= 0, timer1_mode = TMR1_OFF_STATE, \
 count_update_meas_time_per_sec = 0, measure_time_in_sec = 0;
unsigned long int num_calls_timer1 = 0, timer1_init = 0, long_press_key_count = MAX_LONG_PRESS_COUNT;
char start_sw_enable_flag = STATE_YES, stop_sw_enable_flag = STATE_NO, measure_in_msec = 0;
unsigned int cur_disp_lcd_loc = BEGIN_LOC_LINE1;
unsigned int start_col_secs_disp, start_col_point_disp , start_col_msec_disp, start_col_secs_msg_disp;

const char measure_time_msg_disp[] = {"Meas:"}, start_meas_msg_disp[] = {"Start Measure "}, measuring_msg_disp[] = {"Measuring ... "}, \
stopped_msg_disp[] = {"Stopped Measure"}, secs_msg_disp[] = {" Secs"};
void main()
{
	 TRISA = 0x00;
     PORTA = 0x00;
     TRISB = 0x00;
     PORTB = 0x00;
     TRISC = 0x00;
     PORTC = 0x00;
     TRISD = 0x78;
     PORTD = 0x00;
     TRISE = 0x00;
     PORTE = 0x00;
   
     ANSEL= 0X00;
     ANSELH=0X00;
     LCD_Init();
	 Init_Const_Data();
	 Goto_XY_LCD_Disp(OPER_MEASURE_LINE_NUM, NUM_COL1);
	 Data_Str_Disp_LCD(start_meas_msg_disp);
	 Goto_XY_LCD_Disp(MEASURING_LINE_NUM, NUM_COL1);
	 Data_Str_Disp_LCD(measure_time_msg_disp);	
	 for(;;)
     {
        if(START_SW == KEY_PRESSED)
        {
	     	 if(start_sw_enable_flag == STATE_YES)
	     	 {	 
	      	     while(START_SW == KEY_PRESSED && --long_press_key_count);
				 Write_LCD_Command(0x01);
                 long_press_key_count = MAX_LONG_PRESS_COUNT;                 
                 start_sw_enable_flag = STATE_NO;
				 stop_sw_enable_flag = STATE_YES;
				 count_update_meas_time_per_sec = 0;
                 measure_time_in_sec = 0;
				 measure_in_msec = 0;				 
            	 Run_Timer1(TMR1_MEASURE_TIME); 
                 Goto_XY_LCD_Disp(OPER_MEASURE_LINE_NUM, NUM_COL1);
	             Data_Str_Disp_LCD(measuring_msg_disp);
				 Goto_XY_LCD_Disp(MEASURING_LINE_NUM, NUM_COL1);
	             Data_Str_Disp_LCD(measure_time_msg_disp);	
             }
	     }
		 if(STOP_SW == KEY_PRESSED)
         {
	     	 if(stop_sw_enable_flag == STATE_YES)
	     	 {	 
	      	     while(STOP_SW == KEY_PRESSED && --long_press_key_count);
                 long_press_key_count = MAX_LONG_PRESS_COUNT;
                 Stop_Timer1();
				 Goto_XY_LCD_Disp(OPER_MEASURE_LINE_NUM, NUM_COL1);
	             Data_Str_Disp_LCD(stopped_msg_disp);	
				 Goto_XY_LCD_Disp(MEASURED_TIME_LINE_NUM, NUM_COL1 );
				 Data_Str_Disp_LCD(measure_time_msg_disp);
				 Goto_XY_LCD_Disp(MEASURED_TIME_LINE_NUM, start_col_secs_disp );
				 Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT3, measure_time_in_sec);
				 Goto_XY_LCD_Disp(MEASURED_TIME_LINE_NUM, start_col_point_disp );
				 Write_LCD_Data('.');
				 measure_in_msec = MEASURE_TIME_PERIOD * count_update_meas_time_per_sec + num_calls_timer1 * TIMER1_TICK_MSEC;
				 Goto_XY_LCD_Disp(MEASURED_TIME_LINE_NUM, start_col_msec_disp );
				 Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT3,measure_in_msec );	
				 Goto_XY_LCD_Disp(MEASURED_TIME_LINE_NUM, start_col_secs_msg_disp );
				 Data_Str_Disp_LCD(secs_msg_disp);
                 start_sw_enable_flag = STATE_YES;
				 stop_sw_enable_flag = STATE_NO;	      		 
             }
	     }
		 if(timer1_mode == TMR1_MEASURE_TIME)
		 {
			 Measure_Time();			 
		 } 
	 }
 }
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 2   
-*------------------------------------------------------------*/
void Measure_Time()
{
      while(TMR1IF == 0);		                
		
		TMR1IF = 0;
		timer1_init = (65535UL) - (INC1/ prescale_timer1); 
        TMR1H = timer1_init / 256UL;
        TMR1L = timer1_init % 256UL; 
		++num_calls_timer1;
        if(num_calls_timer1 >= UPDATE_TIME1_MEASURE_TIME)
        {
		     Update_Measure_Time_Count();                			 
             num_calls_timer1 = 0;        
        }
}
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 2   
-*------------------------------------------------------------*/
void Update_Measure_Time_Count()
{
   if(++count_update_meas_time_per_sec % MEASURE_TIME_FACTOR_PER_SEC == 0 )
   { 
       count_update_meas_time_per_sec = 0;
       ++measure_time_in_sec; 
	   Goto_XY_LCD_Disp(MEASURING_LINE_NUM,start_col_secs_disp );
	   Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT3, measure_time_in_sec);
   }
}   
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 16  
-*------------------------------------------------------------*/
void Stop_Timer1()
{
	if(timer1_mode != TMR1_OFF_STATE)
	{	
	   timer1_mode = TMR1_OFF_STATE;
	   T1CON = 0x80;
	}   
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 33   
-*------------------------------------------------------------*/
void Run_Timer1(const unsigned int set_timer1_mode )
{
  Stop_Timer1();  
  if(timer1_mode == TMR1_OFF_STATE)
  {
	/*internal timer1 clock  with 1:1 prescale,Timer1 counts when gate(T1G) is high 
     Timer1 counting is controlled by the Timer1 Gate function and no gate input is feed
     and enable timer1*/
	 
	  TMR1H = 0;
      TMR1L = 0;
	  TMR1IF = 0;
	  timer1_mode = set_timer1_mode;
	  /* for T1G gate based  timer 1 running control, Timer1 runs when T1G is high. If T1G is low, timer1 pauses counting */
	 // T1CON =0xC5; 

	 /*internal timer1 clock  with 1:1 prescale, gate(T1G) control for Timer1 is disabled  and enable timer1 and timer 1 runs Timer1 runs */
      T1CON =0x85;   
      prescale_timer1 = 0x01;
      prescale_shift_timer1= 0;
      Prescale_Timer1_Calc();
      timer1_init = (65535UL) - (INC1 / prescale_timer1); 
      TMR1H = timer1_init / 256UL;
      TMR1L = timer1_init % 256UL; 
      num_calls_timer1 = 0;  
  }
  else
  {
	  /* dont run the timer1 if timer1 is already running  */
	  /* error: try to run timer1, which is not in off state */
	  ;
  }	  
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 17  
-*------------------------------------------------------------*/
void Prescale_Timer1_Calc()
{
   if(T1CKPS0 == 1)
   {
      prescale_shift_timer1 |= 0x01;           
   }
   if(T1CKPS1 == 1)
   {
     prescale_shift_timer1 |= 0x02;
   }  
   prescale_timer1 = prescale_timer1  << prescale_shift_timer1;   
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 26  
-*------------------------------------------------------------*/
void Data_Num_Disp_LCD(const unsigned int lcd_datanum_disp_format, const unsigned long lcd_disp_data_int)
{
    unsigned int tens_thousand_digit,thousands_digit, hundreds_digit,tens_digit, unit_digit;
    unsigned long num = lcd_disp_data_int;
    char num_data[] ={'0','1','2','3','4','5','6','7','8','9'};  
	char hex_data[] ={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'}; 
    switch(lcd_datanum_disp_format)
	{
	  case DISP_FLAG_NUM_DIGIT5: 
		  num =  lcd_disp_data_int % 100000UL;
		  tens_thousand_digit = (unsigned int)(num / (10000UL));
          Write_LCD_Data(num_data[tens_thousand_digit]);
	  case DISP_FLAG_NUM_DIGIT4:
	      num = lcd_disp_data_int % 10000UL;
	      thousands_digit = (unsigned int)(num / (1000UL));
	      Write_LCD_Data(num_data[thousands_digit]); 
	  case DISP_FLAG_NUM_DIGIT3: 
		  num = lcd_disp_data_int % 1000UL;
	      hundreds_digit = (unsigned int) (num / (100));
	      Write_LCD_Data(num_data[hundreds_digit]);
	  case DISP_FLAG_NUM_DIGIT2:
          num = lcd_disp_data_int % 100;
          tens_digit = (unsigned int) (num / 10);
          Write_LCD_Data(num_data[tens_digit]); 		  
	  case DISP_FLAG_NUM_DIGIT1:
	     unit_digit = (unsigned int) (lcd_disp_data_int % 10);
         Write_LCD_Data(num_data[unit_digit]); 
	  break;
	  case DISP_FLAG_HEX_DIGIT4:
	      /*  ( 16 * 16 * 16 *16 )  = 0 as divide by zero warning */
	      //num = lcd_disp_data_int % ( 16 * 16 * 16 *16 );
          thousands_digit = (num / (16 * 16 * 16));
	      Write_LCD_Data(hex_data[thousands_digit]);
	  case DISP_FLAG_HEX_DIGIT3:
	      num = lcd_disp_data_int %(unsigned long)(16 * 16 * 16);
	      hundreds_digit = (unsigned int) (num / (unsigned long) (16 * 16));
	      Write_LCD_Data(hex_data[hundreds_digit]);
	  case DISP_FLAG_HEX_DIGIT2:
	      num = lcd_disp_data_int %(unsigned long)(16 * 16);
          tens_digit = (unsigned int) (num / 16);
          Write_LCD_Data(hex_data[tens_digit]);
	  case DISP_FLAG_HEX_DIGIT1: 
	      unit_digit = (unsigned int) (lcd_disp_data_int % 16);
          Write_LCD_Data(hex_data[unit_digit]);    
	  break;	  
	}   	
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 33   
-*------------------------------------------------------------*/
void LCD_Init()
{
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x38);
    Write_LCD_Command(0x01);
    Write_LCD_Command(0x0E); //insert cursor on at cur_input_lcd_loc
	//Write_LCD_Command(0x0C);
    Write_LCD_Command(0x06);                                       
}  
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 23   
-*------------------------------------------------------------*/
  void Write_LCD_Command (unsigned int cmd)
  {
	  unsigned long int  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  
       RW_PIN = 0;
       RS_PIN = 0; 
       LCD_PORT = cmd;
      // LCD_Pulse();
	  EN_PIN = 1;
	  while(time_delay--);
    // Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
      EN_PIN = 0;
	  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  while(time_delay--);
   //  Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
 }
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 24   
-*------------------------------------------------------------*/
 void Write_LCD_Data(const char ch)
{
	unsigned long int  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	// performance degraded if many data is written to LCD, to check if write loc is within avail disp loc
	// if(lcd_avail_loc_within_limit == STATE_YES) 
	{	
      RW_PIN = 0;
      RS_PIN = 1;
      LCD_PORT =ch;
     // LCD_Pulse();
      EN_PIN = 1;
	  while(time_delay--);
    // Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
     EN_PIN = 0;
	 time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  while(time_delay--);
   //  Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);	 
	}
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 25   
-*------------------------------------------------------------*/

void Data_Str_Disp_LCD(const char *char_ptr)
{ 
       while(*char_ptr)
       {
            Write_LCD_Data(*(char_ptr++));
       }
     
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 27  
-*------------------------------------------------------------*/
void Delay_Time_ByCount( unsigned int time_delay)
{
       while(time_delay--);
}
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 33   
-*------------------------------------------------------------*/
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num)
{
	/* max 4 lines and 20 columns */
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1, error_disp_start_loc; 
	
	
   if(start_line_num <= CONFIGURE_MAX_NUM_LINES && start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
      switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE4;
		   break;		 
	 }	
      cur_disp_lcd_loc = cur_disp_lcd_loc + start_col_lcd;
      Write_LCD_Command(cur_disp_lcd_loc);       
   }
} 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 33   
-*------------------------------------------------------------*/  
void Init_Const_Data() 
{
	start_col_secs_disp = strlen(measure_time_msg_disp) + 1;
	start_col_point_disp = start_col_secs_disp + 3;
	start_col_msec_disp = start_col_point_disp + 1;
	start_col_secs_msg_disp = start_col_msec_disp + 5;
}	
