/* ********************************************************************
FILE                   : seg9.c

PROGRAM DESCRIPTION    :  WHEN KEYPAD_ENABLE_SW is pressed on then keypad is enabled and if keypad is enabled, then keypad phone with row reference, 
   scan each key for a press and if pressed, then display corresponding num in a 7 seg LED common cathode. If KEYPAD_DISABLE_SW is 
   pressed, then keypad is disabled		 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
             Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                   HW : Tested OK in PIC development board by www.alselectro.com 
		    Programmer: PICkit 3 
                       
CHANGE LOGS           : 

*****************************************************************************/   
   
#include <pic.h>
#define MAX_ROW  4
#define MAX_COL   3
 #define  SEG_LED_PORT       PORTB
#define  KEYPAD_PHONE_COL1  RC0
#define  KEYPAD_PHONE_COL2  RC1
#define  KEYPAD_PHONE_COL3  RC2
#define  KEYPAD_PHONE_ROWA  RC3
#define  KEYPAD_PHONE_ROWB  RC4
#define  KEYPAD_PHONE_ROWC  RC5
#define  KEYPAD_PHONE_ROWD  RC6
#define  UNIT_DIGIT_PIN     RC7 
#define  KEYPAD_ENABLE_SW   RA0 
#define  KEYPAD_DISABLE_SW  RA1 
#define  KEYPAD_ENABLE_LED  RA2

/*#define  SEG_LED_PORT       PORTC
#define  KEYPAD_PHONE_COL1  RA0
#define  KEYPAD_PHONE_COL2  RA1
#define  KEYPAD_PHONE_COL3  RA2
#define  KEYPAD_PHONE_ROWA  RB0
#define  KEYPAD_PHONE_ROWB  RB1
#define  KEYPAD_PHONE_ROWC  RB2
#define  KEYPAD_PHONE_ROWD  RB3
#define  UNIT_DIGIT_PIN     RA3 */
#define _XTAL_FREQ       (4000000)
 __CONFIG(0x2ce4); 
 
#define STATE_YES        'y'
#define STATE_NO         'n'
void main()
{
	 unsigned int i , j, digit[10]  = {0x3F, 0x06, 0x5B, 0x4F,0x66,0x6D, 0x7D, 0x07, 0x7F, 0x6F}; 
	 char keypad_enable_flag = STATE_NO, keypad_enable_sw_flag = STATE_YES, keypad_disable_sw_flag = STATE_NO, first_key_press_flag = STATE_YES ;
	 
	 SEG_LED_PORT = 0x00;
	 TRISB = 0x00; 
       
	   
	   TRISC = 0x07; 
	   PORTC = 0x00; 
	   
	   TRISAbits.TRISA0 = 1;
	   KEYPAD_ENABLE_SW = 0;
	   
	   TRISAbits.TRISA1 = 1;
	   KEYPAD_DISABLE_SW = 0;
	   
	   TRISAbits.TRISA2 = 0;
	   KEYPAD_ENABLE_LED = 0;
	   
	  /* TRISA = 0x07;
	   PORTA = 0x00; 
	   
	   TRISB = 0x00;
	   PORTB = 0x00; 
	   
	   TRISC = 0x00; 
	   SEG_LED_PORT = 0x00; */
		
	   ANSEL = 0x00;
       ANSELH = 0x00;
	   
       __delay_ms(30);
	  UNIT_DIGIT_PIN = 0;
      while(1)
      {
		        if(keypad_enable_sw_flag == STATE_YES && KEYPAD_ENABLE_SW == 1)
				{
					__delay_ms(50);
					if(KEYPAD_ENABLE_SW == 1)
					{
						while(KEYPAD_ENABLE_SW == 1);
						keypad_enable_sw_flag = STATE_NO;
						keypad_enable_flag = STATE_YES;
						first_key_press_flag = STATE_YES;
						KEYPAD_ENABLE_LED = 1;
					}
				}
				if(keypad_enable_sw_flag == STATE_NO  && KEYPAD_DISABLE_SW == 1)
				{
					__delay_ms(50);
					if(KEYPAD_DISABLE_SW == 1)
					{
						while(KEYPAD_DISABLE_SW == 1);
						keypad_enable_flag = STATE_NO;
						keypad_enable_sw_flag = STATE_YES; 
						UNIT_DIGIT_PIN = 0;	
						__delay_ms(500);
						KEYPAD_ENABLE_LED = 0;												
					}					
				}
			    if(keypad_enable_flag == STATE_YES)
				{
                    KEYPAD_PHONE_ROWA = 1;
                    KEYPAD_PHONE_ROWB  = 0;
                    KEYPAD_PHONE_ROWC  = 0;
                    KEYPAD_PHONE_ROWD  = 0; 
                    if( KEYPAD_PHONE_COL1 == 1)
					{
						__delay_ms(50);
						if(KEYPAD_PHONE_COL1 == 1)
						{
							while(KEYPAD_PHONE_COL1 == 1);
							if(first_key_press_flag == STATE_YES)
							{
                                UNIT_DIGIT_PIN = 1;	
							    __delay_ms(500);
							    first_key_press_flag = STATE_NO;
							}
							SEG_LED_PORT   =    digit[1];
							__delay_ms(500);
						}
					}
                   if(KEYPAD_PHONE_COL2 == 1)
					{
						__delay_ms(50);
						if(KEYPAD_PHONE_COL2 == 1)
						{
							while(KEYPAD_PHONE_COL2 == 1);
							if(first_key_press_flag == STATE_YES)
							{
                                UNIT_DIGIT_PIN = 1;	
							    __delay_ms(500);
							    first_key_press_flag = STATE_NO;
							}
							 SEG_LED_PORT   =    digit[2];
							__delay_ms(500);
						}
					}
                    if(KEYPAD_PHONE_COL3 == 1)
					{
						__delay_ms(50);
						if(KEYPAD_PHONE_COL3 == 1)
						{
							while(KEYPAD_PHONE_COL3 == 1);
							if(first_key_press_flag == STATE_YES)
							{
                                UNIT_DIGIT_PIN = 1;	
							    __delay_ms(500);
							    first_key_press_flag = STATE_NO;
							}
							SEG_LED_PORT   =   digit[3];
							__delay_ms(500);
						}
					}  
                    				
                   KEYPAD_PHONE_ROWA = 0;
                   KEYPAD_PHONE_ROWB  = 1;
                   KEYPAD_PHONE_ROWC  = 0;
                   KEYPAD_PHONE_ROWD  = 0; 
                   if( KEYPAD_PHONE_COL1 == 1)
					{
						__delay_ms(50);
						if(KEYPAD_PHONE_COL1 == 1)
						{
							while(KEYPAD_PHONE_COL1 == 1);
							if(first_key_press_flag == STATE_YES)
							{
                                UNIT_DIGIT_PIN = 1;	
							    __delay_ms(500);
							    first_key_press_flag = STATE_NO;
							}
							SEG_LED_PORT   =    digit[4];
							__delay_ms(500);
						}
					}
                   if( KEYPAD_PHONE_COL2 == 1)
					{
						__delay_ms(50);
						if(KEYPAD_PHONE_COL2 == 1)
						{
							while(KEYPAD_PHONE_COL2 == 1);
							if(first_key_press_flag == STATE_YES)
							{
                                UNIT_DIGIT_PIN = 1;	
							    __delay_ms(500);
							    first_key_press_flag = STATE_NO;
							}
							SEG_LED_PORT   =    digit[5];
							__delay_ms(500);
						}
					}
                    if(KEYPAD_PHONE_COL3 == 1)
					{
						__delay_ms(50);
						if(KEYPAD_PHONE_COL3 == 1)
						{
							while(KEYPAD_PHONE_COL3 == 1);
							if(first_key_press_flag == STATE_YES)
							{
                                UNIT_DIGIT_PIN = 1;	
							    __delay_ms(500);
							    first_key_press_flag = STATE_NO;
							}
							SEG_LED_PORT   =   digit[6];
							__delay_ms(500);
						}
					} 
					KEYPAD_PHONE_ROWA = 0;
                    KEYPAD_PHONE_ROWB  = 0;
                    KEYPAD_PHONE_ROWC  = 1;
                    KEYPAD_PHONE_ROWD  = 0; 
                    if(KEYPAD_PHONE_COL1 == 1)
					{
						__delay_ms(50);
						if(KEYPAD_PHONE_COL1 == 1)
						{
							while(KEYPAD_PHONE_COL1 == 1);
							if(first_key_press_flag == STATE_YES)
							{
                                UNIT_DIGIT_PIN = 1;	
							    __delay_ms(500);
							    first_key_press_flag = STATE_NO;
							}
							 SEG_LED_PORT   =    digit[7];
							__delay_ms(500);
						}
					}
                   if(KEYPAD_PHONE_COL2 == 1)
					{
						__delay_ms(50);
						if(KEYPAD_PHONE_COL2 == 1)
						{
							while(KEYPAD_PHONE_COL2 == 1);
							if(first_key_press_flag == STATE_YES)
							{
                                UNIT_DIGIT_PIN = 1;	
							    __delay_ms(500);
							    first_key_press_flag = STATE_NO;
							}
							SEG_LED_PORT   =    digit[8];
							__delay_ms(500);
						}
					}
                    if(KEYPAD_PHONE_COL3 == 1)
					{
						__delay_ms(50);
						if(KEYPAD_PHONE_COL3 == 1)
						{
							while(KEYPAD_PHONE_COL3 == 1);
							if(first_key_press_flag == STATE_YES)
							{
                                UNIT_DIGIT_PIN = 1;	
							    __delay_ms(500);
							    first_key_press_flag = STATE_NO;
							}
							SEG_LED_PORT   =   digit[9];
							__delay_ms(500);
						}
					} 
                  
 
                    KEYPAD_PHONE_ROWA = 0;
                    KEYPAD_PHONE_ROWB  = 0;
                    KEYPAD_PHONE_ROWC  = 0;
                    KEYPAD_PHONE_ROWD  = 1; 
                    if( KEYPAD_PHONE_COL2 == 1)
					{
						__delay_ms(50);
						if(KEYPAD_PHONE_COL2 == 1)
						{
							while(KEYPAD_PHONE_COL2 == 1);
							if(first_key_press_flag == STATE_YES)
							{
                                UNIT_DIGIT_PIN = 1;	
							    __delay_ms(500);
							    first_key_press_flag = STATE_NO;
							}
                            SEG_LED_PORT   =    digit[0];
							__delay_ms(500);
						}
					}
				}
                     
      }
}
