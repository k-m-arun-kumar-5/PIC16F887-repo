  /* ********************************************************************
FILE                   : seg5.c

PROGRAM DESCRIPTION    :  DISPLAY 2 DIGIT num in a 7 segment 2 digit multiplexed common cathode				 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
             Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                   HW : Tested OK in PIC development board by www.alselectro.com 
		    Programmer: PICkit 3 
                       
CHANGE LOGS           : 

*****************************************************************************/

#include <pic.h>
#define SEG_UNIT_DIGIT_PIN    RA0
#define SEG_TENS_DIGIT_PIN     RA1
#define SEVEN_SEG_PORT    PORTC
#define _XTAL_FREQ       (4000000)
__CONFIG(0x2ce4);
void delay_time(unsigned int );

void main()
{
     unsigned int num, unit_digit, tens_digit, digit[]   = {0x3F, 0x06, 0x5B, 0x4F,0x66,0x6D, 0x7D, 0x07, 0x7F, 0x6F};
	 TRISAbits.TRISA0 = 0;		 
	 SEG_UNIT_DIGIT_PIN = 0;
     TRISAbits.TRISA1 = 0;		 
	 SEG_TENS_DIGIT_PIN = 0;
	 TRISC = 0x00;
     SEVEN_SEG_PORT = 0x00;   
    
      ANSEL = 0x00;
      ANSELH = 0x00;
	  __delay_ms(300);
      for(;;)
      {   
              for(num = 0; num < 99; ++num)
              {
                  tens_digit = num / 10;
                  SEG_UNIT_DIGIT_PIN = 0;
				  SEG_TENS_DIGIT_PIN = 1;
				  __delay_ms(100);
                  SEVEN_SEG_PORT  = digit[tens_digit];
				  __delay_ms(500);
				  
				  unit_digit = num %10;
                  SEG_UNIT_DIGIT_PIN = 1;
				  SEG_TENS_DIGIT_PIN = 0;
				  __delay_ms(100);				  
                  SEVEN_SEG_PORT = digit[unit_digit];                   
                  __delay_ms(500);
              }
      }
}
void delay_time(unsigned int time_delay)
{
        while (time_delay--);
}
