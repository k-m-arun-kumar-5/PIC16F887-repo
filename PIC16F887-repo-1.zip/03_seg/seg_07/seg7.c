/* ********************************************************************
FILE                   : seg7.c

PROGRAM DESCRIPTION    :  for every SW_INC press increment display NUMBER, in a cathode7 segment LED 4 digit multiplexed.  
for every SW_DEC press decrement display number, in a cathode 7 segment LED 4 digit multiplexed.			 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
             Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                   HW : Tested OK in PIC development board by www.alselectro.com 
		    Programmer: PICkit 3 
                       
CHANGE LOGS           : 

*****************************************************************************/
#include <pic.h>
#define SW_INC            RA0
#define SW_DEC            RA1
#define UNIT_DIGIT_PIN    RB0
#define TENS_DIGIT_PIN    RB1
#define HUND_DIGIT_PIN    RB2
#define THOS_DIGIT_PIN    RB3
#define SEVEN_SEG_PORT    PORTC
#define _XTAL_FREQ       (4000000)
__CONFIG(0x2ce4);

#define STATE_YES        'y'
#define STATE_NO         'n'

void delay_time(unsigned int );
void display_num(int );

char inc_sw_enable_flag = STATE_YES, dec_sw_enable_flag = STATE_YES;

void main()
{
     unsigned int num =  0 ;
	 
	 TRISAbits.TRISA0 = 1;		 
	 TRISAbits.TRISA1 = 1;		 
	 UNIT_DIGIT_PIN = 0;
	 TRISBbits.TRISB0 = 0;
	 TENS_DIGIT_PIN = 0;	 
	 TRISBbits.TRISB1 = 0;
	 HUND_DIGIT_PIN = 0;
	 TRISBbits.TRISB2 = 0;
	 THOS_DIGIT_PIN = 0;
	 TRISBbits.TRISB3 = 0;
	 TRISC = 0x00;
     SEVEN_SEG_PORT = 0x00;   
     
	 
      ANSEL = 0x00;
      ANSELH = 0x00; 
    
      for(;;)
      {
         if(inc_sw_enable_flag == STATE_YES && SW_INC == 1)
         {
			 __delay_ms(50);
			 if(SW_INC == 1)
			 {
			     while(SW_INC == 1);
                 inc_sw_enable_flag = STATE_NO;
				 dec_sw_enable_flag = STATE_NO;
                 if(num >= 9999)
				 {
                    num  = 0;
				 }
                 else
				 {					 
                     ++num;
				 }				 
                 display_num(num);  
              
			 }        
          }
          if(dec_sw_enable_flag == STATE_YES && SW_DEC == 1)
          {
             __delay_ms(50);
			 if(SW_DEC == 1)
			 {
				 while(SW_DEC == 1);
				 inc_sw_enable_flag = STATE_NO;
				 dec_sw_enable_flag = STATE_NO;
                 if(num <= 0)
				 {
                    num  = 9999;
				 }
				 else 
				 {
                     --num; 
				 }
                  display_num(num);
			 }       
         }   
     }
}
void display_num(int num)
{
        unsigned int unit_digit, tens_digit, hundreds_digit, thousands_digit;
        unsigned int digit[]   = {0x3F, 0x06, 0x5B, 0x4F,0x66,0x6D, 0x7D, 0x07, 0x7F, 0x6F};
       unsigned int trig[] = {0x01, 0x02, 0x04, 0x08};

       thousands_digit    = num / 1000;
      num %= 1000;
         UNIT_DIGIT_PIN = 1;
       TENS_DIGIT_PIN = 1;
        HUND_DIGIT_PIN = 1;
       THOS_DIGIT_PIN = 0;
      /* instead of triggering individial pins of 7 seg 4 digit multiplexed LED as above, 
          below commented line is used to trigger it at same time,if others non trig pins of 7 seg
          does not cause  any side effects  */
        // PORTA |= (0x0F & ~trig[3]);
       SEVEN_SEG_PORT = digit[thousands_digit];   
       __delay_ms(500);
    
         hundreds_digit = num / 100;
        num %= 100;
        UNIT_DIGIT_PIN = 1;
       TENS_DIGIT_PIN = 1;
        HUND_DIGIT_PIN = 0;
       THOS_DIGIT_PIN = 1;
     /* instead of triggering individial pins of 7 seg 4 digit multiplexed LED as above, 
          below commented line is used to trigger it at same time, if others non trig pins of 7 seg
          does not cause  any side effects*/ 
        // PORTA |= (0x0F & ~trig[2]);
       SEVEN_SEG_PORT = digit[hundreds_digit];   
       __delay_ms(500);
 
         tens_digit = num /10;         
        UNIT_DIGIT_PIN = 1;
       TENS_DIGIT_PIN = 0;
        HUND_DIGIT_PIN = 1;
       THOS_DIGIT_PIN = 1;
       /* instead of triggering individial pins of 7 seg 4 digit multiplexed LED as above, 
          below commented line is used to trigger it at same time ,if others non trig pins of 7 seg
          does not cause  any side effects*/
         // PORTA |= (0x0F & ~trig[1]);  
       SEVEN_SEG_PORT = digit[tens_digit];   
       __delay_ms(500);

       unit_digit = num %10;
        UNIT_DIGIT_PIN = 0;
       TENS_DIGIT_PIN = 1;
        HUND_DIGIT_PIN = 1;
       THOS_DIGIT_PIN = 1;
      /* instead of triggering individial pins of 7 seg 4 digit multiplexed LED as above, 
          below commented line is used to trigger it at same time,if others non trig pins of 7 seg
          does not cause  any side effects  */
         // PORTA |= (0x0F & ~trig[0]);
       SEVEN_SEG_PORT = digit[unit_digit];
        __delay_ms(500); 
		
		inc_sw_enable_flag = STATE_YES;
		dec_sw_enable_flag = STATE_YES;
}
void delay_time(unsigned int time_delay)
{
         while (time_delay--);
}
