 /* ********************************************************************
FILE                   : seg6.c

PROGRAM DESCRIPTION    :   for every SW_INC press increment display NUMBER, in two 7 segment LED.  
for every SW_DEC press decrement display number, in two 7 segment LED.	 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
             Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                 
                       
CHANGE LOGS           : 

*****************************************************************************/
#include <pic.h>
#define SEG_UNIT_DIGIT_PIN    RA0
#define SEG_TENS_DIGIT_PIN    RA1
#define SEVEN_SEG_UNIT_PORT   PORTB
#define SEVEN_SEG_TENS_PORT   PORTD
#define SW_INC     RC0
#define SW_DEC     RC1

void delay_time(unsigned int );

void main()
{
     unsigned int unit_digit, tens_digit, digit[]   = {0x3F, 0x06, 0x5B, 0x4F,0x66,0x6D, 0x7D, 0x07, 0x7F, 0x6F};
	 int num = -1;
	 
     TRISAbits.TRISA0 = 0;		 
	 SEG_UNIT_DIGIT_PIN = 0;
     TRISAbits.TRISA1 = 0;		 
	 SEG_TENS_DIGIT_PIN = 0;
	 TRISC = 0x00;
     SEVEN_SEG_PORT = 0x00;  
	 TRISCbits.TRISC0 = 1;
	 SW_INC = 0;
	 TRISCbits.TRISC1 = 1;
	 SW_DEC = 0;
	 
      ANSEL = 0x00;
      ANSELH = 0x00;
      for(;;)
      {
		  SEG_UNIT_DIGIT_PIN = 1;
          SEG_TENS_DIGIT_PIN = 1;   
        if(SW_INC == 1)
        {
			__delay_ms(50);
			if(SW_INC == 1)
			{
			    while(SW_INC == 1); 				
                if(num >= 99)
                    num  = -1; 
                ++num;
                 unit_digit = num %10;
                 SEVEN_SEG_UNIT_PORT = digit[unit_digit];
                 tens_digit = num /10;
                 SEVEN_SEG_TENS_PORT = digit[tens_digit];
			}             
       }
       if(SW_DEC == 1)
       {
           __delay_ms(50);
			if(SW_DEC == 1)
			{
				while(SW_DEC == 1); 
                if(num <= 0)
                    num  =100;  
                --num; 
                unit_digit = num %10;
                SEVEN_SEG_UNIT_PORT = digit[unit_digit];
                tens_digit = num /10;
                SEVEN_SEG_TENS_PORT = digit[tens_digit];
            }        
       }   
   }
}
void delay_time(unsigned int time_delay)
{
        while (time_delay--);
}
