/*   */
     
  /* ********************************************************************
FILE                   : seg4.c

PROGRAM DESCRIPTION    :  DISPLAY increase hexa digit in a 7 segment LED of  common cathode  for every SW_INC press and 
    decrease hexa digit in a 7 segment LED of  common cathode  for every SW_DEC press and display corresponding
     num in 7 seg LED to number of LED pins to glow							 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
             Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                   HW : Tested OK in PIC development board by www.alselectro.com 
		    Programmer: PICkit 3 
                       
CHANGE LOGS           : 

*****************************************************************************/      
#include <pic.h>
#define   SW_INC          RA0
#define   SW_DEC          RA1

#define SEVEN_SEG_PORT    PORTB
#define SEG_UNIT_DIGIT_PIN     RA2
#define LOWER_DIGIT_PORT   PORTC
#define HIGHER_DIGIT_PORT  PORTD
#define _XTAL_FREQ       (4000000)
__CONFIG(0x2ce4);
void    main()
{
         unsigned int digit[]   = {0x3F, 0x06, 0x5B, 0x4F,0x66,0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71};
         int k = -1;
		 
         TRISB = 0x00;
		 SEVEN_SEG_PORT = 0X00;
		 TRISAbits.TRISA2 = 0;
		 SEG_UNIT_DIGIT_PIN = 0;
         TRISAbits.TRISA0 = 1;
		 SW_INC = 0;
		 TRISAbits.TRISA1 = 1;
		 SW_DEC = 0;
         TRISC = 0x00;
		 LOWER_DIGIT_PORT  = 0X00;
		 TRISD = 0x00;
		 HIGHER_DIGIT_PORT = 0x00;
		 
        ANSEL = 0x00;
        ANSELH = 0x00;
    while(1)
    {
		SEG_UNIT_DIGIT_PIN = 1;
        if(SW_INC == 1)
        {
			__delay_ms(50);
			if(SW_INC == 1)
			{
			    while(SW_INC == 1); 
                if(k >= 15)
                    k  = -1; 
                SEVEN_SEG_PORT = digit[++k];
                if(k <= 0)
                {
                    LOWER_DIGIT_PORT = 0x00;
                    HIGHER_DIGIT_PORT = 0x00;
                } 
                if(k  > 0 && k <=8)
                {
                    LOWER_DIGIT_PORT  = LOWER_DIGIT_PORT | ( 0x01<<((k - 1) % 8));                 
                }
                if( k > 8)
                {
                   HIGHER_DIGIT_PORT = HIGHER_DIGIT_PORT | ( 0x01<< ((k - 1) - 8));
                }
			}          
       }
        if(SW_DEC == 1)
        {
           __delay_ms(50);
			if(SW_DEC == 1)
			{
				while(SW_DEC == 1);
  		        if(k <= 0)
                {
                    k  =16;  
                    LOWER_DIGIT_PORT = 0xFF;
                    HIGHER_DIGIT_PORT= 0x7F;
                } 
                SEVEN_SEG_PORT = digit[--k];
                             
                if( k >= 0 && k <8)
                {
                     LOWER_DIGIT_PORT = LOWER_DIGIT_PORT & ~( 0x01<<(k  % 8));
                     HIGHER_DIGIT_PORT= 0x00;
                }  
                if( k >= 8)
                {
                   HIGHER_DIGIT_PORT = HIGHER_DIGIT_PORT & ~( 0x01<< (k  - 8));
                } 
			}         
       }   
    }                                                                              
}
